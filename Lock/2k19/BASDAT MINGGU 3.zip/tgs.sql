create table karyawan(
    nama varchar2(32) not null,
    usia number(2) not null check (usia < 100 and usia > 0),
    alamat varchar2(32) not null,
    no_karyawan number(8) primary key not null
);

create table pesawat(
  kode_pesawat varchar2(12) primary key not null,
  tanggal_pembuatan date not null,
  nama_instansi varchar2(32) not null
  );

create table travel_agent(
  id_agent number(8) primary key not null,
  no_telpon number(16) not null,
  nama_travel varchar2(32) not null,
  booking_id varchar2(16) not null unique
);
create table penumpang(
  id_penumpang number(9) primary key not null,
  kode_pesawat varchar2(12) references pesawat(kode_pesawat),
  alamat varchar2(32) not null,
  usia number(2) not null check (usia < 100 and usia > 0)
);
create table pramugari(
  id_pramugari number(8) primary key not null,
  kode_pesawat varchar2(12) references pesawat(kode_pesawat),
  alamat varchar2(32) not null,
  usia number(2) not null check (usia < 100 and usia > 0)
);
create table pilot(
  id_pilot varchar2(8) primary key not null,
  kode_pesawat varchar2(12) references pesawat(kode_pesawat),
  nama varchar2(16) not null,
  no_penerbangan number(8) not null 
);
create table tiket(
  harga varchar2(12) not null,
  no_tiket number(8) primary key not null,
  id_pen number(9) references penumpang(id_penumpang)
);

create table transactions(
  id_trans number(9) primary key not null,
  isMember varchar2(2) check (isMember = 1 or isMember = 0),
  id_penumpang number(9) references penumpang(id_penumpang)
);

alter table pesawat add (id_penumpang number(9) references penumpang(id_penumpang));

alter table karyawan rename to babu;
alter table pesawat rename to kapal_terbang;
alter table tiket rename to bukti_pembayaran;

alter table transactions add (is_done varchar2(2) not null check (is_done = 0 or is_done = 1));
alter table penumpang add (notlp varchar2(16) not null);

alter table penumpang modify (notlp varchar2(32) unique);
alter table kapal_terbang modify (kode_pesawat varchar2(16));
alter table pilot modify (no_penerbangan unique);

alter table babu drop column nama;
alter table kapal_terbang drop column nama_instansi;
alter table pramugari drop column alamat;
drop table BABU cascade constraint purge;


insert into babu values('Agus Wahyono',45,'Bali 20',001);
insert into babu values('Sri Ture',29,'Pegangsaan 9',002);
insert into babu values('Kura Sir',31,'Nusa 12',003);
insert into babu values('Luka Batin',25,'Kurnia 1',004);
insert into babu values('Tri Sungko',40,'Rawa Pening',005);

insert into kapal_terbang values('SA001',to_date('01 january 2001','DD MM YYYY'),'Silk A200');
insert into kapal_terbang values('AA001',to_date('29 Agustus 2008','DD MM YYYY'),'Asian Z270');
insert into kapal_terbang values('ST001',to_date('3 march 2011','DD MM YYYY'),'Tan 213');
insert into kapal_terbang values('BO007',to_date('5 june 2000','DD MM YYYY'),'Boeing 777');
insert into kapal_terbang values('AB001',to_date('4 july 2017','DD MM YYYY'),'Airbus A380');

insert into travel_agent values(001245,084532698511,'Silk Air');
insert into travel_agent values(001896,087456329874,'Air Asia');
insert into travel_agent values(001456,083159753488,'Sri Tanjung');
insert into travel_agent values(001122,082741963852,'Boeing');
insert into travel_agent values(003456,085412986753,'Airbus');

insert into penumpang values(100001,'AA001','Ngagel 11',19);
insert into penumpang values(100002,'SA001','Semenanjung 72',25);
insert into penumpang values(100003,'BO007','Jakarta 1',30);
insert into penumpang values(100004,'AB001','Mutiara 5,29);
insert into penumpang values(100005,'AA001','Emas 15',40);

insert into pramugari values(215367,'SA001','Nggurui 201',30);
insert into pramugari values(268945,'AA001','Kelaten 20',24);
insert into pramugari values(247821,'BO007','suramadu 5',29);
insert into pramugari values(245981,'AB001','Kuala intan,26);
insert into pramugari values(259684,'ST001','mekar sari',24);

insert into pilot values(995464,'SA001','Dion Kuli',100001);
insert into pilot values(995612,'AA001','Gunawan Bagus',100004);
insert into pilot values(996385,'BO007','Sungkono',100003);
insert into pilot values(994518,'AB001','Jaka Tingkir,100005);
insert into pilot values(998845,'ST001','Djoko Sara',100002);

insert into bukti_pembayaran values('200000',123,100001);
insert into bukti_pembayaran values('500000',195,100004);
insert into bukti_pembayaran values('300000',517,100003);
insert into bukti_pembayaran values('150000',564,100005);
insert into bukti_pembayaran values('250000',486,100002);

insert into transaction values(1653,1,100002);
insert into transaction values(8912,1,100003);
insert into transaction values(9485,0,100004);
insert into transaction values(3512,0,100001);
insert into transaction values(9231,1,100005);

update babu set usia = 20 where no_karyawan = 005;
update bukti_pembayaran set no_tiket = 645 where id_pen=100001;
update transaction set isMember = 1 where id_penumpang=100001;
update babu set usia = 21 where no_karyawan 004;
update bukkti_pembayaran set harga = 400000 where id_pen = 100001;
update kapal_terbang set nama_instansi = 'Asia ZE215' where kode_pesawat = 'AA001';
update travel_agent set no_telpon=08216459833 where id_agent = 001245;
update transaction set id_penumpang='100005' where id_trans=9485;
update pramugari set usia=22 where id_pramugari=215367;
update penumpang set alamat='Dr Soetomo 15' where id_penumpang=100005;
update pilot set nama='Budiman' where id_pilot=996385;

delete from travel_agent where no_telpon = 084532698511
delete from travel_agent where no_telpon = 087456329874
delete from travel_agent where no_telpon = 083159753488
delete from travel_agent where no_telpon = 082741963852
delete from travel_agent where no_telpon = 085412986753

delete from bukti_pembayaran where harga = 500000
delete from bukti_pembayaran where harga = 300000
delete from bukti_pembayaran where harga = 200000
delete from bukti_pembayaran where harga = 150000
delete from bukti_pembayaran where harga = 250000