/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgtry;

import java.util.*;
/**
 *
 * @author adgry
 */
public class Try {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean gameover = false;
        int counter = 0;
        LOGIN[] account = new LOGIN[100];
        Random rand = new Random();
        
        int GOLD = 500;
        int Level = 1;
        int Day = 1;
        int Experience = 0;
        
        
        int aniii = rand.nextInt(((10 - 1) + 1) + 1);
        System.out.println(aniii);
        
        while(!gameover)
        {
            System.out.println("Menu Guest\n" +
                            "=================\n" +
                            "1. Register\n" +
                            "2. Login\n" +
                            "0. Exit");
            int menu = sc.nextInt();
            if(menu == 1)
            {
                // register 
                boolean register = true;
                while(register)
                {
                    String username,password;
                    System.out.print("Masukkan Username : ");
                    username = sc.next();
                    System.out.print("Masukkan Password : ");
                    password = sc.next();
                    System.out.print("Re Enter password : ");
                    String repass = sc.next();
                    if(!password.equals(repass))
                    {
                        System.out.println("Kedua password harus sama");
                    }
                    else
                    {
                        int ada = 0;
                        for(int i=0;i<counter;i++)
                        {
                            if(account[i].getUsername().equals(username))
                            {
                                ada++;
                            }
                        }
                        if (ada < 1)
                        {
                            System.out.println("Account created");
                            account[counter] = new LOGIN(username, password);
                            counter++;
                            register = false;
                        }
                        else
                        {
                            System.out.println("Username sudah ada");
                        }
                    }
                }
            }
            else if (menu == 2)
            {
                String username,password;
                boolean login = false;
                boolean check = false;
                while(!login)
                {
                    System.out.print("Masukkan Username : ");
                    username = sc.next();
                    System.out.print("Masukkan Password : ");
                    password = sc.next();
                    for (int i = 0; i < counter; i++) {
                        if (account[i].getUsername().equals(username) && account[i].getPassword().equals(password)) {
                            check = true;
                        }
                    }
                    if (check) {
                        System.out.println("Logged In");
                        boolean play = true;
                        Map map = new Map();
                        while(play)
                        {
                            map.CetakMap(username, Day, Level, Experience, GOLD);
                            System.out.print("Input x : ");
                            String x = sc.next();
                            System.out.print("Input y : ");
                            String y = sc.next();
                            if(x.equalsIgnoreCase("c")&&y.equalsIgnoreCase("c"))
                            {
                                System.out.println("1. Gold ");
                                System.out.println("2. Level ");
                                System.out.println("3. Day ");
                                int cheat = sc.nextInt();
                                if(cheat == 1)
                                {
                                    System.out.print("Masukkan jumlah gold : ");
                                    GOLD = sc.nextInt();
                                }
                                else if(cheat == 2)
                                {
                                    System.out.println("Masukkan jumlah level : ");
                                    int temp_level = sc.nextInt();
                                }
                                else if(cheat == 3)
                                {
                                    
                                }
                                System.out.println("Gameover");
                                play = !play;
                                login = true;
                            }
                        }
                    }
                    else
                    {
                        System.out.println("Username atau password salah");
                    }
                }
            }
            else if (menu == 0)
            {
                gameover = true;
            }
        }
    }
}
class LOGIN{
    static int jumlah = 0;
    private String username,password;
    LOGIN()
    {
        jumlah++ ;
    }
    LOGIN(String username, String password)
    {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

class Map{
    private String[][] Map = new String[12][17];
    Random rand = new Random();
    ArrayList<Integer> x_rintangan = new ArrayList<>();
    ArrayList<Integer> y_rintangan = new ArrayList<>();
    String[] jenis_rintangan = {"T","t","R","r"};
    private int banyak_pohon;
    
    private String kesusahan_hati = "Niat itu datengnya telat banget , karena udah telat jadinya ga niat :'v #plzHelp";
    
    public Map() {
        banyak_pohon = rand.nextInt((20 - 15) + 1) + 15;
        for (int i = 0; i < banyak_pohon; i++) {
            int temp1 = rand.nextInt((10 - 1) + 1) + 1;
            int temp2 = rand.nextInt((15 - 1) + 1) + 1;
            while((temp1 == 1 && temp2 == 1 )||( temp1 == 1 && temp2 == 15 )|| (temp1 == 2 && temp2 == 15 )|| (temp1 == 10 && temp2 == 1))
            {
                temp1 = rand.nextInt((10 - 1) + 1) + 1;
                temp2 = rand.nextInt((15 - 1) + 1) + 1;
            }
            x_rintangan.add(temp1);
            y_rintangan.add(temp2);
        }
        
        for (int i = 0; i < 12; i++) {
            for (int j = 0; j < 17; j++) {
                if(i == 0 || i == 11 || j == 0 || j == 16)
                {
                    Map[i][j] = "#";
                }
                else
                {
                    Map[i][j] = " ";
                }
            }
        }
        for (int i = 0; i < banyak_pohon; i++) {
            for (int j = 0; j < 10; j++) {
                for (int k = 0; k < 15; k++) {
                    if(i == x_rintangan.get(j) && j == y_rintangan.get(k))
                    {
                        Map[j][k] = jenis_rintangan[rand.nextInt(4)];
                    }
                }
            }
        }
        Map[1][1] = "M";
        Map[1][15] = "S";
        Map[2][15] = "B";
        Map[10][1] = "A";
    }

    public void CetakMap(String username,int Day,int Lvl,int Experience,int Gold)
    {
        System.out.println("Username : " + username);
        System.out.println("Day : " + Day);
        System.out.println("Level : " + Lvl);
        System.out.println("Experience : " + Experience + "/");
        System.out.println("Gold : " + Gold + "G");
        for (int i = 0; i < 12; i++) {
            for (int j = 0; j < 17; j++) {
                System.out.print(Map[i][j]);
            }
            System.out.println();
        }
    }
    public void setMap(String[][] Map) {
        this.Map = Map;
    }
    public void cekMap(int x, int y)
    {
        if(Map[y][x].equals("T"))
        {
            
        }
    }

    @Override
    public String toString() {
        return "Ini curahan hati" + kesusahan_hati;
    }
    
}