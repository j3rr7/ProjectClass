/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t;

import java.util.Scanner;

/**
 *
 * @author adgry
 */
public class T {

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        System.out.print("Masukkan nama : ");
        Storage tan = new Storage();
        String nama = sc.next();
        int maxBeliAyam=0;
        int maxBeliSapi=0;
        boolean gameover = false;
        int day = 1,gold = 100;
        String[] nama_ayam = new String[3];
        String[] nama_sapi = new String[3];
        Character[][] map = new Character[5][5];
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                map[i][j] = '-';
            }
        }
        int x,y;
        int menu = -1;
        while(!gameover)
        {
            System.out.println("Nama :" + nama);
            System.out.println("Day : " +day);
            System.out.println("Gold : " +gold+"G");
            System.out.println("Main menu:");
            System.out.println("1. Beli (benih/hewan)\n"
                    + "2. Lihat ladang\n"
                    + "3. Ke kandang ayam\n"
                    + "4. Ke kandang sapi\n"
                    + "5. Silo\n"
                    + "6. Inventory\n"
                    + "7. Ganti hari\n"
                    + "8. Cheat gold\n"
                    + "0. Exit");
            menu = sc.nextInt();
            if(menu == 0)
            {
                gameover = true;
            }
            else if(menu == 1)
            {
                System.out.println("1. Tanaman");
                System.out.println("2. Hewan");
                System.out.println("Pilihan : ");
                int pilihan = sc.nextInt();
                if(pilihan == 1)
                {
                    int benih;
                    System.out.println("1. Strawberry   |$30");
                    System.out.println("2. Potato       |$15");
                    System.out.println("3. Tunip        |$10");
                    System.out.println("4. Grass        |$5");
                    System.out.println("5. Corn         |$2");
                    System.out.print("Pilihan : ");
                    benih = sc.nextInt();
                    if(benih == 1 && gold >= 30)
                    {
                        gold -= 30;
                        tan.beli_benih(benih);
                    }
                    else if (benih == 2 && gold >=15)
                    {
                        gold -= 15;
                        tan.beli_benih(benih);
                    }
                    else if (benih == 3 && gold >= 10)
                    {
                        gold -= 10;
                        tan.beli_benih(benih);
                    }
                    else if (benih == 4 && gold >= 5)
                    {
                        gold -= 5;
                        tan.beli_benih(benih);
                    }
                    else if (benih == 5 && gold >= 2)
                    {
                        gold -= 2;
                        tan.beli_benih(benih);
                    }
                }
                else if (pilihan == 2)
                {
                    System.out.println("1. AYAM       |$80");
                    System.out.println("2. SAPI       |$250");
                    int hewan = sc.nextInt();
                    if(hewan == 1 && gold >= 80 && maxBeliAyam <= 3)
                    {
                        String temp_nama = sc.next();
                        nama_ayam[maxBeliAyam] = temp_nama;
                        gold -= 80;
                        maxBeliAyam += 1;
                    }
                    else if (hewan == 2 && gold >= 250 && maxBeliSapi <= 3)
                    {
                        String temp_nama = sc.next();
                        nama_sapi[maxBeliSapi] = temp_nama;
                        gold -= 250;
                        maxBeliSapi += 1;
                    }
                }
            }
            else if (menu == 2)
            {
                int menu2 = -1;
                while (menu2 != 0)
                {
                    print(map);
                    System.out.println("1. Tanam");
                    System.out.println("2. Siram");
                    System.out.println("3. Panen");
                    System.out.println("0. Back to Menu");
                    menu2 = sc.nextInt();
                    if(menu2 == 1)
                    {
                        System.out.println("Masukkan x : ");
                        x = sc.nextInt();
                        System.out.println("Masukkan y : ");
                        y = sc.nextInt();
                        System.out.println("Masukkan jenis benih\n"
                                + "1. Strawberry\n"
                                + "2. Potato\n"
                                + "3. Tunip\n"
                                + "4. Grass\n"
                                + "5. Corn");
                        int jenis = sc.nextInt();
                        if(jenis == 1 && tan.getBenih_strawberry() > 0)
                        {
                            tan.setBenih_strawberry();
                            map[y][x] = '.';
                        }
                        else if ( jenis == 2 && tan.getBenih_potato() > 0)
                        {
                            tan.setBenih_potato();
                            map[y][x] = '.';
                        }
                        else if (jenis == 3 && tan.getBenih_tunip() > 0)
                        {
                            tan.setBenih_tunip();
                            map[y][x] = '.';
                        }
                    }
                    else if (menu2 == 2)
                    {
                        System.out.println("Siram : ");
                    }
                    else if (menu2 == 3)
                    {
                        System.out.println("Panen : ");
                    }
                }
            }
            else if (menu == 3)
            {
                int menu3 = -1;
                //kandangayam
                while (menu3 != 0)
                {
                System.out.println("Kandang Ayam");
                for (int i = 0; i < 3; i++) {
                    System.out.println("(" + "status(*/$)" + ")" + "[" + "T/ " + "] " + nama_ayam[i]);
                }
                System.out.println("MENU");
                System.out.println("1. Beri makan");
                System.out.println("2. Ambil telur");
                System.out.println("3. Jual Ayam");
                System.out.println("0. Back to main menu");
                menu3 = sc.nextInt();
                if(menu3 == 1)
                {
                    
                }
                else if (menu3 == 2)
                {
                    
                }
                else if (menu3 == 3 && tan.getAyam() <= 3)
                {
                    gold += 120;
                }
                }
                
            }
            else if (menu == 4)
            {
                int menu4 = -1;
                //kandangsapi
                while (menu4 != 0)
                {
                System.out.println("Kandang Sapi");
                for (int i = 0; i < 3; i++) {
                    System.out.println("(" + "status(V/$)" + ")" + "[" + "M/ " + "]" + nama_sapi[i]);
                }
                System.out.println("MENU");
                System.out.println("1. Beri makan");
                System.out.println("2. Ambil Susu");
                System.out.println("3. Jual Sapi");
                System.out.println("0. Back to main menu");    
                menu4 = sc.nextInt();
                if(menu4 == 1)
                {
                    
                }
                else if (menu4 == 2)
                {
                    
                }
                else if (menu4 == 3 && tan.getSapi() <= 3)
                {
                    gold += 300;
                } 
                }
            }
            else if (menu == 5)
            {
                //silo
                System.out.println("1. Strawberry : "+tan.getBenih_strawberry());
                System.out.println("2. Potato : "+tan.getBenih_potato());
                System.out.println("3. Tunip : "+tan.getBenih_tunip());
                System.out.println("4. Grass : "+tan.getBenih_grass());
                System.out.println("5. Corn : "+tan.getBenih_corn());
                System.out.println("6. Ayam : "+tan.getAyam());
                System.out.println("7. Sapi : "+tan.getSapi());
                System.out.println("Jual : ");
                int jual = sc.nextInt();
            }
            else if (menu == 6)
            {
                //Inventory
            }
            else if (menu == 7)
            {
                day += 1;
            }
            else if (menu == 8)
            {
                System.out.println("Cheat gold : ");
                int cheat = sc.nextInt();
                gold = cheat;
            }
        }
    }
    static void print(Character[][] map)
    {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(map[i][j]);
            }
            System.out.println();
        }
    }
    
}
