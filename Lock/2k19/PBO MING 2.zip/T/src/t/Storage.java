/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t;

/**
 *
 * @author adgry
 */
class Storage {
    private int strawberry,potato,tunip;
    private int benih_strawberry,benih_potato,benih_tunip,benih_grass,benih_corn;
    private int sapi,ayam;

    public Storage() {
        strawberry = 0;
        potato = 0;
        tunip = 0;
        
        benih_strawberry = 0;
        benih_potato = 0;
        benih_tunip = 0;
        benih_grass = 0;
        benih_corn = 0;
        sapi = 0;
        ayam = 0;
    }

    public void beli_benih(int x)
    {
        if (x == 1)
        {
            benih_strawberry += 1;
        }
        else if (x == 2)
        {
            benih_potato += 1;
        }
        else if (x == 3)
        {
            benih_tunip += 1;
        }
        else if (x == 4)
        {
            benih_grass += 1;
        }
        else if (x == 5)
        {
            benih_corn += 1;
        }
    }
    public void beli_hewan(int x)
    {
        if (x == 1)
        {
            ayam += 1;
        }
        else if (x == 2)
        {
            sapi += 1;
        }
    }

    public int getBenih_strawberry() {
        return benih_strawberry;
    }
    public int getBenih_potato() {
        return benih_potato;
    }
    public int getBenih_tunip() {
        return benih_tunip;
    }
    public int getBenih_grass() {
        return benih_grass;
    }
    public int getBenih_corn() {
        return benih_corn;
    }
    public int getSapi() {
        return sapi;
    }
    public int getAyam() {
        return ayam;
    }
    
    public void jualAyam()
    {
        ayam -= 1;
    }
    public void jualSapi()
    {
        sapi -= 1;
    }

    public void setBenih_strawberry() {
        benih_strawberry -= 1;
    }
    public void setBenih_potato() {
        benih_potato -= 1;
    }
    public void setBenih_tunip() {
        benih_tunip -= 1;
    }
    
}
