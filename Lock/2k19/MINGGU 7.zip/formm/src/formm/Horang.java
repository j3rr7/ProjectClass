/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package formm;

/**
 *
 * @author adgry
 */
public class Horang {
    String nama,ukuran,menu;
    int harga,quantity;
    int subtotal;

    public Horang(String nama,String menu, String ukuran, int harga, int quantity, int subtotal) {
        this.nama = nama;
        this.menu = menu;
        this.ukuran = ukuran;
        this.harga = harga;
        this.quantity = quantity;
        this.subtotal = subtotal;
    }

    public String getMenu() {
        return menu;
    }

    public void setMenu(String menu) {
        this.menu = menu;
    }

    public int getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(int subtotal) {
        this.subtotal = subtotal;
    }

    @Override
    public String toString() {
        return menu + " - " + ukuran + " - " + harga + " - x" + quantity + " - " + subtotal + "\n";
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getUkuran() {
        return ukuran;
    }

    public void setUkuran(String ukuran) {
        this.ukuran = ukuran;
    }

    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    
}
