/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package formm;

import java.util.ArrayList;
import javax.swing.DefaultListModel;

/**
 *
 * @author adgry
 */
public class Custumer {
    String idnota,nama;
    int total,bayar,kembali;
    DefaultListModel<String> semuanya_ = new DefaultListModel<>();
    
    //ArrayList<String> arr = new ArrayList<>();
    public Custumer(String idnota, String nama, int total, int bayar, int kembali,DefaultListModel<String> semuanya) {
        this.idnota = idnota;
        this.nama = nama;
        this.total = total;
        this.bayar = bayar;
        this.kembali = kembali;
        for (int i = 0; i < semuanya.size(); i++) {
            String temp = semuanya.get(i).toString();
            semuanya_.addElement(temp);
        }
        //arr.add(semuanya);
    }

    @Override
    public String toString() {
        return "Custumer{" + "idnota=" + idnota + ", nama=" + nama + ", total=" + total + ", bayar=" + bayar + ", kembali=" + kembali + '}';
    }

    public DefaultListModel<String> getSemuanya() {
        return semuanya_;
    }

    public void setSemuanya(DefaultListModel<String> semuanya) {
        this.semuanya_ = semuanya;
    }
    

    public String getIdnota() {
        return idnota;
    }

    public void setIdnota(String idnota) {
        this.idnota = idnota;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getBayar() {
        return bayar;
    }

    public void setBayar(int bayar) {
        this.bayar = bayar;
    }

    public int getKembali() {
        return kembali;
    }

    public void setKembali(int kembali) {
        this.kembali = kembali;
    }


    
}
