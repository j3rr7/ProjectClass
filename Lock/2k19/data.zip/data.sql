--5--


select rpad(menu.nama_menu,29,' ') "NAMA_MENU" , lpad(count(resep.jumlah),12,' ') "Varian Bahan"
from menu, resep 
where menu.id_menu = resep.id_menu
group by menu.nama_menu
having count(resep.jumlah) != (select min(count(resep.jumlah)) from resep
where resep.id_bahan = resep.id_bahan
group by resep.id_menu) and count(resep.jumlah) != (select max(count(resep.jumlah)) from resep
where resep.id_bahan = resep.id_bahan
group by resep.id_menu)
order by count(resep.jumlah);
