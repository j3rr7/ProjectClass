create table karyawan(
    nama varchar(32) not null,
    usia number(2) not null check (usia < 100 and usia > 0),
    alamat varchar(32) not null,
    no_karyawan number(8) primary key not null
);
create table pesawat(
  kode_pesawat varchar(12) primary key not null,
  tanggal_pembuatan varchar(4) not null,
  nama_instansi varchar(32) not null
  );
create table travel_agent(
  id_agent number(8) primary key not null,
  no_telpon number(16) not null,
  nama_travel varchar(32) not null,
  booking_id varchar(16) not null unique
);
create table penumpang(
  id_penumpang number(9) primary key not null,
  kode_pesawat varchar(12) references pesawat(kode_pesawat),
  alamat varchar(32) not null,
  usia number(2) not null check (usia < 100 and usia > 0)
);
create table pramugari(
  id_pramugari number(8) primary key not null,
  kode_pesawat varchar(12) references pesawat(kode_pesawat),
  alamat varchar(32) not null,
  usia number(2) not null check (usia < 100 and usia > 0)
);
create table pilot(
  id_pilot varchar(8) primary key not null,
  kode_pesawat varchar(12) references pesawat(kode_pesawat),
  nama varchar(16) not null,
  no_penerbangan number(8) not null 
);
create table tiket(
  harga varchar(12) not null,
  no_tiket number(8) primary key not null,
  id_pen number(9) references penumpang(id_penumpang)
);

create table transactions(
  id_trans number(9) primary key not null,
  isMember varchar(2) check (isMember = 1 or isMember = 0),
  id_penumpang number(9) references penumpang(id_penumpang)
);

alter table pesawat add (id_penumpang number(9) references penumpang(id_penumpang));

alter table karyawan rename to babu;
alter table pesawat rename to kapal_terbang;
alter table tiket rename to bukti_pembayaran;

alter table transactions add (is_done varchar(2) not null check (is_done = 0 or is_done = 1));
alter table penumpang add (notlp varchar(16) not null);

alter table penumpang modify (notlp varchar(32) unique);
alter table kapal_terbang modify (kode_pesawat varchar(16));
alter table pilot modify (no_penerbangan unique);

alter table babu drop column nama;
alter table kapal_terbang drop column nama_instansi;
alter table pramugari drop column alamat;
drop table BABU cascade constraint purge;
