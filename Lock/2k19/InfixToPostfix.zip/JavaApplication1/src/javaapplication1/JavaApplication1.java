/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import java.util.*;
/**
 *
 * @author adgry
 */
public class JavaApplication1 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Stack<Character> st = new Stack<>();
        System.out.println("Masukkan Input : ");
        String input = sc.next();
        String jawab = "";
//        for(int i = 0; i < input.length(); i++)
//        {
//            char anu = input.charAt(i);
//            st.push(anu);             
//            if(input.charAt(i) >= '0' ||(input.charAt(i) <= '9'))
//                ctr+=input.charAt(i); 
////            else if(input.charAt(i) == '(')
////                st.push('(');
////            else if(input.charAt(i) == ')')
////            {
////                while (!st.isEmpty())
////                {
////                    if(st.peek() != '(')
////                    {
////                        ctr += st.pop();
////                    }
////                    else
////                        st.pop();
////                }
////            }
//            else
//            {
//            }
//        }
            for (int i = 0; i < input.length(); ++i) {
                char ctr = input.charAt(i);
                if (ctr == '(') 
                {
                    st.push('(');
                }
                else if (ctr == ')')
                {
                    Character temp = st.peek();
                    while (temp != '(' && !st.isEmpty()) 
                    {
                        st.pop();
                        jawab += temp;
                        if (!st.isEmpty())
                        {
                            temp = st.peek();
                        }
                    }
                    st.pop();
                }
                else if (ctr == '+' || ctr == '-')
                {
                    if (st.isEmpty())
                    {
                        st.push(ctr);
                    }
                    else
                    {
                        Character temp = st.peek();
                        while (!(st.isEmpty() || temp == '(' || temp == ')'))
                        {
                            temp = st.pop();
                            jawab += temp;
                        }
                        st.push(ctr);
                    }
                }
                else if (ctr == '*' || ctr == '/')
                {
                    if (st.isEmpty()) {
                        st.push(ctr);
                    }
                    else
                    {
                        Character temp = st.peek();
                        while (temp !='(' && temp != '+' && temp != '-' && !st.isEmpty())
                        {
                            temp = st.pop();
                            jawab += temp;
                        }
                        st.push(ctr);
                    }
                    
                }
                else {
                    jawab += ctr;
                }
            }
            while (!st.isEmpty())
            {
                Character temp = st.peek();
                if (temp != '(')
                {
                    st.pop();
                    jawab += temp;
                }
            }
            System.out.println("PostFix adalah : " + jawab);
            
        }
}