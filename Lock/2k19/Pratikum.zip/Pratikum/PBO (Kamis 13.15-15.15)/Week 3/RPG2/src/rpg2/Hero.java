/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author steve
 */
public class Hero {
    Scanner scInt = new Scanner(System.in);
    Random rnd = new Random();
    private int basicAtk, magicAtk, evasion, accuracy, hp, maxhp , mp, maxmp, manacost, chance;
    private int armor, exp, maxexp, golddrop, expdrop, level, sp ;
    private int [] herocost = new int[]{200, 350, 180}, debuf = new int[2];
    private String job; private boolean aktif = false;
    private String[] skill = new String[2];
    private static int jumlahHero, gold;
    
    public Hero(){gold = 800;}
    
    public Hero(int pil){
        level =  1;exp = 0; maxexp = 100; gold -= herocost[pil-1]; jumlahHero++;
        if (pil == 1) {
            job = "Warrior"; armor = 8; level =  1;exp = 0; maxexp = 100;
            basicAtk = 100; magicAtk = 20; evasion = 0; accuracy = 90;
            hp = 520; maxhp = 520; mp = 30; maxmp = 30;
            skill[0] = "Power Break"; skill[1] = "Armor Break"; manacost = 8;
        }else if (pil == 2) {
            job = "Mage"; armor = 2;level =  1;exp = 0; maxexp = 100;
            basicAtk = 30; magicAtk = 200; evasion = 10; accuracy = 75;
            hp = 360; maxhp = 360; mp = 120; maxmp = 120;
            skill[0] = "Magic Ball"; skill[1] = "Magic Boost"; manacost = 4;
        }else if (pil == 3) {
            job = "Range"; armor = 4; level =  1;exp = 0; maxexp = 100;
            basicAtk = 70; magicAtk = 100; evasion = 5; accuracy = 100;
            hp = 610; maxhp = 610; mp = 40; maxmp = 40;
            skill[0] = "Blind Attack";skill[1] = "Silence Attack"; manacost = 5;
        }
    }
    
    public Hero(String a){
        chance = 75;
        if (a.equals("B")) {
            job = "Boss"; armor = 25; expdrop = rnd.nextInt(21)+40; golddrop = 300;
            basicAtk = 80; magicAtk = 20; hp = 2000; maxhp = 2000;accuracy = 100;
            mp = 200; maxmp = 200; skill[0] = "Increase Attack"; manacost = 10;
        }else if (a.equals("w")) {
            job = "Wild Dog"; armor = 15; expdrop = rnd.nextInt(6)+15; golddrop = 120;
            basicAtk = 32; magicAtk = 10; hp = 150; maxhp = 150;accuracy = 100;
            mp = 50; maxmp = 50; skill[0] = "Fire Torch"; manacost = 40;
        } else if(a.equals("m")){
            job = "Magic Monster"; armor = 20; expdrop = rnd.nextInt(6)+20; golddrop = 150;
            basicAtk = 7; magicAtk = 70; hp = 200; maxhp = 200;accuracy = 100;
            mp = 300; maxmp = 300; skill[0] = "Thunder"; manacost = 50;
        }
    }
    public void battle(Hero var, int input, String tentu){
        int chanceLawan = rnd.nextInt(100)+1;
        int chanceSkill = rnd.nextInt(100)+1;
        int chancePlayer = rnd.nextInt(100)+1;
        if (tentu.equals("player")) {
            if (chancePlayer <= accuracy && (this.basicAtk - var.armor) > 0) {
                System.out.println("Player attack enemy");
                var.hp -= (this.basicAtk - var.armor);
            }else{
                System.out.println("Player attack Miss");
            }
        }else if (tentu.equals("enemy")){
            if (chanceLawan-var.evasion <= accuracy || debuf[1] > 0) {
                if (chanceSkill < 75 || mp < manacost) {
                    System.out.println("Enemy attack player");
                    if ((this.basicAtk - var.armor) > 0) {
                        if (input == 3) {
                            var.hp -= ((this.basicAtk - var.armor) * 0.3);
                        }else{
                           var.hp -= (this.basicAtk - var.armor);
                        }
                    }
                } else {
                    useSkill(var, input, "enemy");
                }
            }else{
                System.out.println("Enemy attack Miss");
            }
        }
    }
    
    public void useSkill(Hero var, int input, String tentu){
        int pilihan = 0;
        if (mp >= manacost) {
            if (tentu.equals("player")) {
                do{
                    System.out.println("Pilih Skill");
                    System.out.println("1. " + this.skill[0]);
                    System.out.println("2. " + this.skill[1]);
                    System.out.print("Pilihan: ");
                    pilihan = scInt.nextInt();
                }while (pilihan > 2 || pilihan < 0);
                System.out.println("Player use " + skill[pilihan-1]);
                if (job.equals("Warrior")) {
                    if (pilihan == 1) {
                        var.hp -= this.basicAtk;
                        var.basicAtk *= 0.9;
                        var.magicAtk *= 0.9;
                    }else {
                        var.hp -= this.basicAtk;
                        var.armor = 0;
                    }
                }else if (job.equals("Mage")) {
                    if (pilihan == 1) {
                        var.hp -= this.magicAtk;
                    } else {
                        this.magicAtk += (magicAtk*0.5);
                    }
                }else if (job.equals("Range")) {
                    if (pilihan == 1) {
                        var.accuracy -= (var.accuracy *0.1); 
                        var.debuf[0] += 3;
                    } else {
                        var.debuf[1] += 3;
                    }
                    
                }
            }else if(tentu.equals("enemy")){
                System.out.println(job + " use " + skill[0]);
                if (job.equals("Boss")) {
                    this.basicAtk += 5;
                }else if (job.equals("Wild Dog") || job.equals("Magic Monster")) {
                    if (input == 3) {
                       var.hp -= (this.magicAtk * 0.3); 
                    }else{
                       var.hp -= this.magicAtk;
                    }
                }
            }mp -= manacost;
        }else{System.out.println("Mana tidak cukup");}
    }
    
    public void tambahStats(){
        System.out.println("Jumlah SP: " + sp + "SP");
        System.out.println("1. +300 HP");
        System.out.println("2. +20 MP");
        System.out.println("3. +20 Attack");
        System.out.println("4. +1 Armor");
        System.out.println("5. +3% Evasion");
        System.out.println("6. +2% Akurasi");
        System.out.print("Input: ");
        int mintasp = scInt.nextInt();
        if (sp == 0) { System.out.println("SP tidak cukup");
        }else {
            if (mintasp == 1) {maxhp+= 300;}
            else if (mintasp == 2) {maxmp+=20;
            } else if (mintasp == 3) {basicAtk += 20; magicAtk += 20;
            } else if (mintasp == 4) {armor += 1;
            } else if (mintasp == 5) {evasion += 3;
                    if (evasion > 100) evasion = 100;
            } else if (mintasp == 6) {accuracy += 2;
                    if (accuracy > 100) accuracy = 100;
            }sp--;
        }
    }

    public int getDebuf(int angka) {
        return debuf[angka];
    }

    public void setDebuf(int debuf, int index) {
        this.debuf[index] = debuf;
    }

    public boolean getAktif() {
        return aktif;
    }

    public void setAktif(boolean aktif) {
        this.aktif = aktif;
    }
    
    public int getHerocost(int ke) {
        return herocost[ke];
    }

    public int getLevel() {
        return level;
    }

    public int getExp() {
        return exp;
    }

    public void setExp(int exp) {
        if (exp >= maxexp) {
            level++; sp++; this.exp = (exp - maxexp);
        }else{ this.exp = exp;}
    }

    public int getGolddrop() {
        return golddrop;
    }

    public int getExpdrop() {
        return expdrop;
    }

    public static int getJumlahHero() {
        return jumlahHero;
    }

    public static void setJumlahHero(int jumlahHero) {
        Hero.jumlahHero = jumlahHero;
    }

    public static int getGold() {
        return gold;
    }

    public static void setGold(int gold) {
        Hero.gold = gold;
    }
    
    public int getMaxhp() {
        return maxhp;
    }
    
    public int getMaxmp() {
        return maxmp;
    }

    public int getManacost() {
        return manacost;
    }

    public void setAccuracy(int accuracy) {
        this.accuracy = accuracy;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        if (hp >= maxhp) { this.hp = maxhp;
        }else{ this.hp = hp;}
    }

    public int getMp() {
        return mp;
    }

    public void setMp(int mp) {
        if (mp >= maxmp) { this.mp = maxmp;
        }else { this.mp = mp;}
    }

    public String getJob() {
        return job;
    }
}
