/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author steve
 */
public class RPG2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scInt = new Scanner(System.in);
        ArrayList<Hero> chara = new ArrayList();
        chara.add(new Hero());
        boolean infi = true;
        while(infi == true){
            System.out.println("Gold: " + Hero.getGold());
            System.out.println("1. Start Playing");
            System.out.println("2. Beli Hero (" + Hero.getJumlahHero()+ "/12)" );
            System.out.println("3. Lihat Hero");
            System.out.println("4. Exit");
            System.out.print("Pilihan: ");
            int pilihan  = scInt.nextInt();
            if (pilihan == 1) {
                if (chara.size() > 1) {
                    for (int i = 1; i < chara.size(); i++) {
                        System.out.print(i+". " + chara.get(i).getJob() );
                        System.out.print(" - " + chara.get(i).getLevel() );
                        System.out.println(" - " + chara.get(i).getHp()+"/"+chara.get(i).getMaxhp());
                    }
                    System.out.print("Pilihan: ");
                    int input = scInt.nextInt();
                    chara.get(input).setAktif(true);
                    Start game = new Start(chara);
                } else {
                    System.out.println("Belum punya hero");
                }
            }else if (pilihan == 2) {
                System.out.println("Pilih Hero");
                System.out.println("1. Warrior (200g)");
                System.out.println("2. Mage (350g)");
                System.out.println("3. Range (180g)");
                System.out.print("Input: ");
                int input = scInt.nextInt();
                if (chara.get(0).getGold() >= chara.get(0).getHerocost(input-1) ){
                    if (chara.size() <= 12) {
                        chara.add(new Hero(input));
                        System.out.println("Hero telah ditambahkan");
                    } else {
                        System.out.println("Slot Penuh");
                    }
                } else{
                    System.out.println("Gold tak cukup");
                }
            }else if (pilihan == 3) {
                for (int i = 1; i < chara.size(); i++) {
                    System.out.print(i+". " + chara.get(i).getJob() );
                    System.out.print(" - " + chara.get(i).getLevel() );
                    System.out.println(" - " + chara.get(i).getHp()+"/"+chara.get(i).getMaxhp());
                }
            }else if (pilihan == 4) {
                infi = false;
            }
        }
    }
}
