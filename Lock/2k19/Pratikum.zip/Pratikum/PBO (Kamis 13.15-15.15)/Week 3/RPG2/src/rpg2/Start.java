/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg2;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author steve
 */
public class Start {

    /**
     * @param args the command line arguments
     */
    public Start(ArrayList<Hero> chara){
        // TODO code application logic here
        Scanner scInt = new Scanner(System.in);
        Scanner scStr = new Scanner(System.in);
        Random rnd = new Random();
        String[][] map = new String[32][33];
        int x = 1, y = 1, index = 0;
        Hero player = null  , enemy = null;
        
        for (int i = 1; i < chara.size(); i++) {
            if (chara.get(i).getAktif() == true) {
                player = chara.get(i);
                index = i;
            }
        }
        
        for (int i = 0; i < 32; i++) {
            for (int j = 0; j < 33; j++) {
                if (i == 0 || j == 0 || i == 31 || j == 32) {
                    map[i][j] = "#";
                }else{
                    map[i][j] = " ";
                }
            }
        }
        map[5][31] = "B"; map[16][31] = "B";map[26][31] = "B";
        map[30][5] = "B"; map[30][16] = "B";
        
        boolean infi = true, pindahMap = true, acakLawan = true;
        int batasBawah = 32, batasAtas = 0, batasKiri = 0 , batasKanan = 33;
        int jumlahBoss = 0, simpan_x = x, simpan_y = y;
        
        while(infi == true){
            jumlahBoss = 0;
            for (int i = 0; i < 32; i++) {
                for (int j = 0; j < 33; j++) {
                    if (map[i][j].equals("B")) jumlahBoss++;
                }
            }
            
            map[16][19] = "H";
            if (player.getJob().equals("Warrior")) map[y][x] = "W";
            else if (player.getJob().equals("Mage")) map[y][x] = "M";
            else if (player.getJob().equals("Range")) map[y][x] = "R";
            
            if (y < 11) {batasAtas = 0; batasBawah = 11;}
            else if (y < 21) {batasAtas = 11; batasBawah = 21;}
            else if (y < 32) { batasAtas = 21; batasBawah = 32;}
            
            if (x < 11) { batasKiri = 0; batasKanan = 11;
            }else if (x < 22) { batasKiri = 11; batasKanan = 22;
            }else if (x <33) { batasKiri = 22; batasKanan = 33;}
            
            if ((simpan_x == 10 && x == 11) || (simpan_x == 11 && x == 10) || (simpan_x == 21 && x == 22) || (simpan_x == 22 && x == 21) ||
                (simpan_y == 10 && y == 11) || (simpan_y == 11 && y == 10) || (simpan_y == 20 && y == 21) || (simpan_y == 21 && y == 20)) {
                pindahMap = true;
            }
            
            int acak_x = 0, acak_y = 0;
            if (pindahMap == true) {
                for (int i = batasAtas; i < batasBawah; i++) {
                    for (int j = batasKiri; j < batasKanan; j++) {
                        if (map[i][j].equals("w") || map[i][j].equals("m")) map[i][j] = " ";
                    }
                }
                for (int i = 0; i < 5; i++) {
                    int acak = rnd.nextInt(2)+1;
                    
                   do{
                        acak_x = rnd.nextInt(batasKanan - batasKiri) + batasKiri;
                        acak_y = rnd.nextInt(batasBawah - batasAtas) + batasAtas;
                    } while(acak_x == x || acak_y == y || map[acak_y][acak_x].equals("B") || map[acak_y][acak_x].equals("#")  
                            || map[acak_y][acak_x].equals("w") || map[acak_y][acak_x].equals("m"));
                    if (acak == 1) {
                        map[acak_y][acak_x] = "w";
                    }else if (acak == 2) {
                        map[acak_y][acak_x] = "m";
                    }
                }
            }
            pindahMap = false;
            simpan_x = x; simpan_y = y;
            for (int i = batasAtas; i < batasBawah; i++) {
                for (int j = batasKiri; j < batasKanan; j++) {
                    System.out.print(map[i][j]);
                }System.out.println("");
            }
            String pilihan = "";
            System.out.print("Input: ");
            pilihan = scStr.nextLine();
            
            if (pilihan.equalsIgnoreCase("w")) {
                map[y][x] = " ";
                y--;
                if (map[y][x].equals("#")) {
                    y++;
                }
            } else if (pilihan.equalsIgnoreCase("a")) {
                map[y][x] = " ";
                x--;
                if (map[y][x].equals("#")) {
                    x++;
                }
            } else if (pilihan.equalsIgnoreCase("s")) {
                map[y][x] = " ";
                y++;
                if (map[y][x].equals("#")) {
                    y--;
                }
            } else if (pilihan.equalsIgnoreCase("d")) {
                map[y][x] = " ";
                x++;
                if (map[y][x].equals("#")) {
                    x--;
                }
            } else if (pilihan.equalsIgnoreCase("m")) {
                player.tambahStats();
            } 

            if (map[y][x].equals("B")|| map[y][x].equals("w") || map[y][x].equals("m")){
                enemy = new Hero(map[y][x]);
                int turn = 1; int input = 0;
                do{
                    System.out.println("----------------");
                    System.out.println("Turn " + turn);
                    System.out.println("Lawan (" + enemy.getJob() + ")");
                    System.out.println("HP: " + enemy.getHp() + "/" + enemy.getMaxhp());
                    System.out.println("MP: " + enemy.getMp() + "/" + enemy.getMaxmp());
                    System.out.println("Debuf: " + enemy.getDebuf(0) + " , " + enemy.getDebuf(1));
                    System.out.println("");
                    System.out.println("Player (" + player.getJob() + ")");
                    System.out.println("HP: " + player.getHp() + "/" + player.getMaxhp());
                    System.out.println("MP: " + player.getMp() + "/" + player.getMaxmp());
                    System.out.println("1. Attack");
                    System.out.println("2. Skill");
                    System.out.println("3. Defend");
                    System.out.print("Input: ");
                    do{
                        input = scInt.nextInt();
                        if (input == 1) {
                            player.battle(enemy, input, "player");
                        }else if (input == 2) {
                            player.useSkill(enemy, input, "player");
                        }else if (input == 3) {
                            System.out.println("Player Def");
                        }
                    }while(player.getMp() < player.getManacost() && input == 2);
                    
                    if(enemy.getHp() > 0){
                       enemy.battle(player, input, "enemy");
                    }
                    for (int i = 0; i < 2; i++) {
                        if (enemy.getDebuf(i) > 0) {
                            int debuf = enemy.getDebuf(i);
                            enemy.setDebuf(debuf-1, i);
                        }
                    }
                    turn++;
                    if (turn % 3 == 0) {
                        System.out.println("Player +10 MP");
                        player.setMp(player.getMp()+10);
                    }
                }while(enemy.getHp() > 0 && player.getHp() > 0 );
                if (enemy.getHp() <= 0) {
                    if (!enemy.getJob().equals("Boss") ) {
                        System.out.println("Player win against " + enemy.getJob());
                        
                    }else if(enemy.getJob().equals("Boss") && jumlahBoss == 1){
                        System.out.println("Player win the game");
                        infi = false;
                    }
                    Hero.setGold(Hero.getGold() + enemy.getGolddrop());
                    player.setExp(player.getExp() + enemy.getExpdrop());
                }
                
            }    
            
            if (pilihan.equalsIgnoreCase("g") || player.getHp() <= 0) {
                if (player.getHp() <= 0) {
                    if (chara.size() > 1) {
                        System.out.println("Player Kalah");
                        chara.remove(index);
                        System.out.println("Ganti Hero");
                        x = simpan_x; y = simpan_y;
                        Hero.setJumlahHero(Hero.getJumlahHero() - 1);
                    }
                    System.out.println(chara.size());
                    if(chara.size() == 1) {
                        infi = false;
                    }
                }else if (pilihan.equalsIgnoreCase("g")){
                    chara.set(index, player);
                }
                if(infi == true){
                    String [] banding = new String []{"Warrior", "Mage", "Range"};
                    int mulai = 0;
                    if (player.getJob().equals("Warrior")) mulai = 1; 
                    else if (player.getJob().equals("Mage")) mulai = 2; 
                    else if (player.getJob().equals("Range")) mulai = 0;
                    boolean stop = false, stop1 = false;
                    int ctr = index + 1, simpan = mulai;
                    while(stop == false){
                        stop1 = false;
                        while(stop1 == false){
                            if (ctr == chara.size()) ctr = 1;
                            if (ctr != index && chara.get(ctr).getJob().equals(banding[mulai%3])) {
                                player = chara.get(ctr); index = ctr;
                                index = ctr;
                                stop1 = true; stop = true;
                            }ctr++;
                            if (ctr == index) stop1 = true;
                        }mulai++;
                        if (simpan+3 == mulai) stop = true;
                    }
                }
            }    
            if (map[y][x].equals("H")) {
                player.setHp(player.getMaxhp());
                player.setMp(player.getMaxmp());
            }
        }
    }
    
}
