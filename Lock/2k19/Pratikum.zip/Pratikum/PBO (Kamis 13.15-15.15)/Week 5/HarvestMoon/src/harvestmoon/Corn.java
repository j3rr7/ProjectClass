package harvestmoon;

public class Corn extends Tanaman{
    public Corn() {
        pernahDipanen = false; grow = 15;
        regrow = 4; umur = 0; disiram = false;
        musim = "Summer";hidup = true;
    }
}
