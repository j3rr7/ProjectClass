package harvestmoon;

public class Cucumber extends Tanaman {
    public Cucumber() {
        pernahDipanen = false; grow = 10;
        regrow = 5; umur = 0; disiram = false;
        musim = "Spring";hidup = true;
    }
}
