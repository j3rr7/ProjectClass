package harvestmoon;

public class Onion extends Tanaman{
    public Onion() {
        pernahDipanen = false; grow = 8;
        regrow = 0; umur = 0; disiram = false;
        musim = "Summer";hidup = true;
    }
}
