package harvestmoon;

public class Potato extends Tanaman {
    public Potato() {
        pernahDipanen = false; grow = 8;
        regrow = 0; umur = 0; disiram = false;
        musim = "Spring";hidup = true;
    }
}
