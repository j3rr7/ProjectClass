package harvestmoon;
import java.util.*;

public class HarvestMoon {

    public static void main(String[] args) {
        Scanner scInt = new Scanner(System.in);
        Scanner scStr = new Scanner(System.in);
        String season = "Spring"; Tanaman dummy = new Tanaman();
        ArrayList<Tanaman>[][] map = new ArrayList[10][10];
        int x = 0, y = 0;
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                map[i][j] = new ArrayList<>();
                map[i][j].add(null);
            }
        }
        boolean infi = true; String arahPlayer = "V";
        while(infi){
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 10; j++) {
                    Tanaman isiTanaman = map[i][j].get(map[i][j].size()-1);
                    System.out.print("|");
                    if (i == y && j == x) System.out.print(arahPlayer);
                    else if (isiTanaman == null || dummy.almostGrass(isiTanaman)) System.out.print(" ");
                    else if(dummy.isGrass(isiTanaman)) System.out.print("g");
                    else if(!isiTanaman.hidup) System.out.print("x");
                    else if (isiTanaman instanceof Turnip) {
                        if (isiTanaman.dewasaBelum()) System.out.print("T");
                        else System.out.print("t");
                    }else if (isiTanaman instanceof Potato) {
                        if (isiTanaman.dewasaBelum()) System.out.print("P");
                        else System.out.print("p");
                    }else if (isiTanaman instanceof Cucumber) {
                        if (isiTanaman.dewasaBelum()) System.out.print("C");
                        else System.out.print("c");
                    }else if (isiTanaman instanceof Tomato) {
                        if (isiTanaman.dewasaBelum()) System.out.print("M");
                        else System.out.print("m");
                    }else if (isiTanaman instanceof Corn) {
                        if (isiTanaman.dewasaBelum()) System.out.print("J");
                        else System.out.print("j");
                    }else if (isiTanaman instanceof Onion) {
                        if (isiTanaman.dewasaBelum()) System.out.print("O");
                        else System.out.print("o");
                    }
                    System.out.print("|");
                }System.out.println("");
            }
            System.out.println("Musim: " + season);
            System.out.println("Hari: " + Tanaman.hari);
            System.out.print("Move: ");
            String pilihan = scStr.nextLine();
            
            if (pilihan.equalsIgnoreCase("w")) {
                arahPlayer = "^"; if (y > 0) y--; Tanaman arah = map[y][x].get(map[y][x].size()-1);
                if (arah != null && !arah.bolehTabrak()) y++;
            }else if (pilihan.equalsIgnoreCase("a")) {
                arahPlayer = "<";if (x > 0 ) x--; Tanaman arah = map[y][x].get(map[y][x].size()-1);
                if (arah != null && !arah.bolehTabrak()) x++;
            }else if (pilihan.equalsIgnoreCase("s")) {
                arahPlayer = "V";if (y < 9) y++; Tanaman arah = map[y][x].get(map[y][x].size()-1);
                if (arah != null && !arah.bolehTabrak()) y--;
            }else if (pilihan.equalsIgnoreCase("d")) {
                arahPlayer = ">";if (x < 9) x++; Tanaman arah = map[y][x].get(map[y][x].size()-1);
                if (arah != null && !arah.bolehTabrak()) x--;
            }else if (pilihan.equalsIgnoreCase("si")) {
                dummy.siram(map, arahPlayer, x, y);
            }else if (pilihan.equalsIgnoreCase("t")) {
                System.out.println("1. Turnip");
                System.out.println("2. Potato");
                System.out.println("3. Cucumber");
                System.out.println("4. Tomato");
                System.out.println("5. Corn");
                System.out.println("6. Onion");
                System.out.print("Pilihan: ");
                int pilihTanaman = scInt.nextInt();
                dummy.tanam(x, y, pilihTanaman, map);
            }else if (pilihan.equalsIgnoreCase("g")) {
                Tanaman.hari++;
                if(Tanaman.hari == 25) {
                    if(season.equals("Spring")) season = "Summer";
                    else if(season.equals("Summer")) season = "Spring";
                    Tanaman.hari = 1;
                }
                for (int i = 0; i < 10; i++) {
                    for (int j = 0; j < 10; j++) {
                        if (map[i][j].get(map[i][j].size()-1) != null && map[i][j].get(map[i][j].size()-1).disiram == true) {
                            map[i][j].get(map[i][j].size()-1).umur++; map[i][j].get(map[i][j].size()-1).disiram = false;
                        }
                    }
                }
            }else if (pilihan.equalsIgnoreCase("p")) {
                dummy.panen(arahPlayer, map, x, y);
            }
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 10; j++) {
                    if (map[i][j].get(map[i][j].size()-1) != null) {
                        if(!map[i][j].get(map[i][j].size()-1).musim.equals(season))map[i][j].get(map[i][j].size()-1).hidup = false;
                    }
                }
            }
        }
    }
    
}
