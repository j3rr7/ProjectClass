package harvestmoon;

public class Tomato extends Tanaman{
    public Tomato() {
        pernahDipanen = false; grow = 10;
        regrow = 3; umur = 0; disiram = false;
        musim = "Summer";hidup = true;
    }
}
