package harvestmoon;

import java.util.*;

public class Tanaman {
    protected boolean pernahDipanen, disiram, hidup;
    protected int grow, regrow,umur;
    protected static int hari = 1;
    protected String musim;

    public Tanaman() {
        this.musim = "tidak ada"; disiram = true; hidup = true;
    }
    
    public void siram(ArrayList<Tanaman>[][] map,String arahPlayer, int x, int y){
        if (map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].get(map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].size()-1) == null) {
            map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].add(new Tanaman());
        }else if (map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].get(map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].size()-1) != null) {
            map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].get(map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].size()-1).disiram = true;
        }
    }
    
    public void panen(String arahPlayer, ArrayList<Tanaman>[][] map, int x, int y){
        Tanaman isiTanaman = null;
        isiTanaman = map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].get(map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].size()-1);
        if (isiTanaman.hidup && isiTanaman != null) {
            if(isiTanaman.pernahDipanen){
                if(isiTanaman.umur >= isiTanaman.regrow) {
                    map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].get(map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].size()-1).umur = 0;
                }
            }else {
                if(isiTanaman.umur >= isiTanaman.grow ){
                    if (isiTanaman.regrow == 0 || !isiTanaman.hidup) 
                        map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].remove(map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].size()-1);
                    else  
                    {map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].get(map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].size()-1).umur = 0;
                    map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].get(map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].size()-1).pernahDipanen = true;}
                }
            }
        }else if(!isiTanaman.hidup && !isiTanaman.musim.equals("tidak ada"))map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].remove(map[arahY(arahPlayer, y)][arahX(arahPlayer, x)].size()-1);
        else System.out.println("Panen Gagal");

    }
    
    public int arahX(String arahPlayer, int x){
        if (arahPlayer.equals(">") && x < 9) return x+1;
        else if (arahPlayer.equals("<") && x > 0) return x-1;
        return x;
    }
    
    public int arahY(String arahPlayer, int y){
        if (arahPlayer.equals("V") && y < 9) return y+1;
        else if (arahPlayer.equals("^") && y > 0) return y-1;
        return y;
    }
    
    public void tanam(int x, int y, int pilihTanaman, ArrayList<Tanaman>[][] map){
        for (int i = y-1; i <= y+1; i++) {
            for (int j = x-1; j <= x+1; j++) {
                if (i < 10 && j < 10 && i > -1 && j > -1 ) {
                    if (map[i][j].get(map[i][j].size()-1) == null || almostGrass(map[i][j].get(map[i][j].size()-1))) {
                        if (pilihTanaman == 1) map[i][j].add(new Turnip());
                        else if (pilihTanaman == 2) map[i][j].add(new Potato());
                        else if (pilihTanaman == 3) map[i][j].add(new Cucumber());
                        else if (pilihTanaman == 4) map[i][j].add(new Tomato());
                        else if (pilihTanaman == 5) map[i][j].add(new Corn());
                        else if (pilihTanaman == 6) map[i][j].add(new Onion());
                    }
                    if (map[i][j].size() > 2 && map[i][j].get(map[i][j].size()-2).musim.equals("tidak ada") && map[i][j].get(map[i][j].size()-2).umur == 0 ) {
                        map[i][j].get(map[i][j].size()-1).disiram = map[i][j].get(map[i][j].size()-2).disiram;
                        map[i][j].remove(map[i][j].size()-2);
                    }
                }
            }
        }
    }
    
    public boolean almostGrass(Tanaman tanaman){
        if ((tanaman.musim.equals("tidak ada") && tanaman.umur == 0)) return true;
        else return false;
    }
    
    public boolean isGrass(Tanaman tanaman){
        if(tanaman.musim.equals("tidak ada") && tanaman.umur > 0) return true;
        else return false;
    }
    
    public boolean bolehTabrak(){
        if (this.dewasaBelum() || !this.hidup || (this.musim.equals("tidak ada") && this.umur > 0)) return false;
        else return true;
    }
    
    public boolean dewasaBelum(){
        if(pernahDipanen){
            if(umur < regrow) return false;
            else return true;
        }else {
            if(umur < grow) return false;
            else return true;
        }
    }
}
