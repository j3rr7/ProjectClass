package harvestmoon;

public class Turnip extends Tanaman {

    public Turnip() {
        pernahDipanen = false; grow = 5;
        regrow = 0; umur = 0; disiram = false;
        musim = "Spring"; hidup = true;
    }
}
