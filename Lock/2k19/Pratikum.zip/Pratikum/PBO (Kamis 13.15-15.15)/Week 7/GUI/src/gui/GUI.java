package gui;

public class GUI {

    public static void main(String[] args) {
        new Frame().setVisible(true);
    }
    
}
