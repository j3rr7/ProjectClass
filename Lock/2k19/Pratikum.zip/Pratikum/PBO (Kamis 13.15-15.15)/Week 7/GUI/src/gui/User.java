package gui;

import javax.swing.*;

public class User {
    private String nama;
    private String historyChat;
    private DefaultListModel<String> addFriends = new DefaultListModel();
    private DefaultComboBoxModel<String> reqFriend = new DefaultComboBoxModel();

    public User(String nama) {
        this.nama = nama;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getHistoryChat() {
        return historyChat;
    }

    public void setHistoryChat(String historyChat) {
        this.historyChat = historyChat;
    }

    public DefaultListModel<String> getAddFriends() {
        return addFriends;
    }

    public String getAddFriends(int index) {
        return addFriends.get(index);
    }
    
    public void setAddFriends(User user, int index) {
        if (index == 0) {
            addFriends.addElement(user.getNama());
        }else if(index == 1){
            addFriends.removeElement(user.getNama());
        }
    }

    public DefaultComboBoxModel<String> getReqFriend() {
        return reqFriend;
    }
    
    public void setReqFriend(User user, int index) {
        if (index == 0) {
            reqFriend.addElement(user.getNama());
        }else if(index == 1){
            
        }
        
    }
    @Override
    public String toString() {
        return nama;
    }
}
