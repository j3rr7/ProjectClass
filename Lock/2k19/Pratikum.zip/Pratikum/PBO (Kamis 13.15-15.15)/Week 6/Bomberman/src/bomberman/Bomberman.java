package bomberman;

import java.util.*;

public class Bomberman {
    public static void main(String[] args) {
        Scanner scStr = new Scanner(System.in);
        Random rnd = new Random();
        String[][] map = new String [13][13];
        ArrayList<Enemy> enemy = new ArrayList<>();
        Player player = new Player();
        enemy.add(new Enemy());
        
        for (int i = 0; i < 13; i++) {
            for (int j = 0; j < 13; j++) {
                if (i == 0 || i == 12 || j == 0 || j == 12) {
                    map[i][j] = "*";
                }else if((i%2==0) && (j%2==0)){
                    map[i][j] = "*";
                }else map[i][j] = " ";
            }
        }
        boolean infi = true;
        enemy.get(0).x = 11;enemy.get(0).y = 11;
        
        while(infi){
            player.runeBomb(map); player.runeE(map);
            if(player.umurBomb > 0) map[player.bomb_y][player.bomb_x] = "b";
            for (int i = 0; i < enemy.size(); i++) {
                if(enemy.get(i).umurBomb > 0) map[enemy.get(i).bomb_y][enemy.get(i).bomb_x] = "b";
                map[enemy.get(i).y][enemy.get(i).x] = "M";
            }
            map[player.y][player.x] = "P";
            for (int i = 0; i < 13; i++) {
                for (int j = 0; j < 13; j++) {
                    System.out.print(map[i][j]);
                }System.out.println("");
            }
            
            player.move(map,enemy);
            for (int i = 0; i < enemy.size(); i++) {
                enemy.get(i).explode(map, player);
                player.explode(map, enemy.get(i));
            }
            
            for (int i = 0; i < enemy.size(); i++) {
                if (!enemy.get(i).alive) {
                    enemy.remove(i);
                }
            }
            
            if (!player.alive) {
                infi = false; System.out.println("Game Over");
            }else if(enemy.size() == 0){
                infi = false; System.out.println("You Win");
            }
        }
    }
    
}
