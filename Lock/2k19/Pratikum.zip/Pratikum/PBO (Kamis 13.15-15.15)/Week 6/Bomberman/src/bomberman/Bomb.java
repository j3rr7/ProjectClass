package bomberman;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class Bomb implements main, Comparable<Bomb>, Cloneable{
    Scanner scStr = new Scanner(System.in);
    Random rnd = new Random();
    protected int x, y, langkah, umurBomb, typeBomb = 1, bomb_x = 0, bomb_y = 0, plantedBomb;
    protected boolean canMove = true, alive = true;

    public Bomb() {
        this.umurBomb = 0; typeBomb = 1; bomb_x = 0; bomb_y = 0;
    }
    
    public Bomb clone(){
        try{
            return (Bomb) super.clone();
        }catch (CloneNotSupportedException ex){
            System.out.println(ex.getMessage());
            return this;
        }
    }
    
    public void runeBomb(String[][] map){
        if (langkah%5 == 0 && langkah>0) {
            int rune = rnd.nextInt(3)+1;
            int rnd_y = rnd.nextInt(10)+1;
            int rnd_x = rnd.nextInt(10)+1;
            while(!map[rnd_y][rnd_x].equals(" ")){
                rnd_y = rnd.nextInt(10)+1;
                rnd_x = rnd.nextInt(10)+1;
            }
            if (rune == 1) map[rnd_y][rnd_x] = "4";
            else if(rune == 2)map[rnd_y][rnd_x] = "H";
            else map[rnd_y][rnd_x] = "V";
        }
    }
    
    public void gantiBomb(String[][] map){
        if (map[y][x].equals("4")) typeBomb = 1;
        else if (map[y][x].equals("H")) typeBomb = 2;
        else if (map[y][x].equals("V")) typeBomb = 3;
    }
    
    public void runeE(String[][] map){
        if (langkah %12 == 0 && langkah > 0) {
            int rnd_y = rnd.nextInt(10)+1;
            int rnd_x = rnd.nextInt(10)+1;
            while(!map[rnd_y][rnd_x].equals(" ")){
                rnd_y = rnd.nextInt(10)+1;
                rnd_x = rnd.nextInt(10)+1;
            }map[rnd_y][rnd_x] = "E";
        }
    }
    
    public void pickRuneE(String[][] map, ArrayList<Enemy> enemy) throws CloneNotSupportedException{
        if (map[y][x].equals("E")) {
            if (enemy.size() == 1) {
                Enemy tambahEnemy = (Enemy) enemy.get(0).clone();
                tambahEnemy.setGerak((tambahEnemy.getGerak()+2)%4);
                enemy.add(tambahEnemy);
            }else {
                Enemy tambahEnemy = enemy.get(0);
                for (int j = 1; j < enemy.size(); j++) {
                    if (tambahEnemy.compareTo(enemy.get(j)) == -1){
                        tambahEnemy = (Enemy)enemy.get(j).clone();
                    }
                }
                tambahEnemy.setGerak((tambahEnemy.getGerak()+2)%4);
                enemy.add(tambahEnemy);
            }
        }
    }
    
    public int compareTo(Enemy t) {
        if (this.y > t.y) {return 1;
        }else if(this.y < t.y){return -1;
        }else if(this.y == t.y){
            if(this.x > t.x) return 1;
            else if(this.x < t.x) return -1;
        }
        return 0;
    }
    
    public void explode(String[][] map, Bomb chara){
        if (umurBomb+4 == langkah && umurBomb > 0) {
            if (plantedBomb== 1) {
                for (int i = bomb_y-1; i <= bomb_y+1; i++) {
                    if (i == y && bomb_x == x) alive = false;
                    else if(i == chara.y && bomb_x == chara.x) chara.alive = false;
                }
                for (int i = bomb_x-1; i <= bomb_x+1; i++) {
                    if (i == x && bomb_y == y) alive = false;
                    else if(i == chara.x && bomb_y == chara.y) chara.alive = false;
                }
            }else if(plantedBomb == 2){
                for (int i = bomb_x-2; i <= bomb_x+2; i++) {
                    if (i == x && bomb_y == y) alive = false;
                    else if(i == chara.x && bomb_y == chara.y) chara.alive = false;
                }
            }else if(plantedBomb == 3){
                for (int i = bomb_y-2; i <= bomb_y+2; i++) {
                    if (i == y && bomb_x == x) alive = false;
                    else if(i == chara.y && bomb_x == chara.x) chara.alive = false;
                }
            }
            map[bomb_y][bomb_x] = " ";
            umurBomb = 0; bomb_x = 0; bomb_y = 0;
        }
    }
    public boolean cekMove(){
        if (x%2 == 0 && y%2 == 0)return false;
        return true;
    }
}

class Player extends Bomb{

    public Player() {
        super();x = 1; y = 1; langkah = 0;
    }
    
    public void cheat(ArrayList<Enemy> enemy){
        for (int i = 0; i < enemy.size(); i++) {
            enemy.get(i).canMove = false;
        }
    }

    @Override
    public void move(String[][] map,ArrayList<Enemy> enemy) {
        map[y][x]= " ";
        boolean jalan = false;
        System.out.print("Move: ");
        String input = scStr.nextLine();
        if (input.equalsIgnoreCase("w") && y > 1) {
            y--; 
            if (!cekMove()) y++;
            else {langkah++; jalan = true;}
        }else if (input.equalsIgnoreCase("a") && x>1) {
            x--; 
            if (!cekMove()) x++;
            else {langkah++; jalan = true;}
        }else if (input.equalsIgnoreCase("s") && y < 11) {
            y++; 
            if (!cekMove()) y--;
            else {langkah++; jalan = true;}
        }else if (input.equalsIgnoreCase("d") && x < 11) {
            x++; 
            if (!cekMove()) x--;
            else {langkah++; jalan = true;}
        }else if (input.equalsIgnoreCase("b") && umurBomb == 0) {
            umurBomb = langkah; bomb_x = x; bomb_y = y; plantedBomb = typeBomb;
        }else if (input.equalsIgnoreCase("c")) {
            cheat(enemy);
        }
        gantiBomb(map); try {
            pickRuneE(map, enemy);
        } catch (CloneNotSupportedException ex) {
            Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (jalan) {
            for (int i = 0; i < enemy.size(); i++) {
                enemy.get(i).move(map, enemy);
            }
        }
    }

    @Override
    public int compareTo(Bomb t) {
        return 0;}
}

class Enemy extends Bomb{
    private int gerak = 0, simpanLangkah = 0;
    private String[] step = {"w", "d", "s", "a"};

    public Enemy() {
        super(); langkah = 0;x = 11; y = 11;
    }
    
    public void gantiStep(String[][] map){
        do{
            gerak++;
            if (gerak > 3) {
                gerak = 0;
                String temp = step[2];step[2] = step[3];step[3] = temp;
            }
        }while(map[gerak_y()][gerak_x()].equals("*"));
        simpanLangkah = langkah;
    }
    
    public int gerak_x(){
        if (step[gerak].equalsIgnoreCase("a")) {return x-1;
        }else if (step[gerak].equalsIgnoreCase("d")) {return x+1;
        }return x;
    }
    
    public int gerak_y(){
        if (step[gerak].equalsIgnoreCase("w")) {return y-1;
        }else if (step[gerak].equalsIgnoreCase("s")) {return y+1;
        }return y;
    }
    
    @Override
    public void move(String[][] map, ArrayList<Enemy> enemy) {
        if (map[gerak_y()][gerak_x()].equals("*") || simpanLangkah+5 == langkah) {
            gantiStep(map);
        }
        if (canMove) {
            map[y][x] = " ";
            if (step[gerak].equalsIgnoreCase("w")) {y--; langkah++;
            }else if (step[gerak].equalsIgnoreCase("a")) {x--; langkah++;
            }else if (step[gerak].equalsIgnoreCase("s")) {y++; langkah++;
            }else if (step[gerak].equalsIgnoreCase("d")) {x++; langkah++;
            }
            gantiBomb(map); 
            int besar = enemy.size();
            try {
                pickRuneE(map, enemy);
            } catch (CloneNotSupportedException ex) {
                Logger.getLogger(Enemy.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            if (besar+1 == enemy.size()) {
                enemy.get(enemy.size()-1).x = 11; enemy.get(enemy.size()-1).y = 11;
                enemy.get(enemy.size()-1).gerak += 2;
                enemy.get(enemy.size()-1).gerak %= 4;
            }
            
            if (langkah%6 == 0 && langkah > 0) {
                umurBomb = langkah; bomb_x = x; bomb_y = y; plantedBomb = typeBomb;
            }
        }
    }
    
    public Enemy clone(){ return (Enemy) super.clone();}

    @Override
    public int compareTo(Bomb t) {
        if (this.y > t.y) return 1;
        else if(this.y < t.y) return -1;
        else if(this.y == t.y){
            if(this.x > t.x) return 1;
            else if(this.x < t.x) return -1;
        }
        return 0;
    }

    public int getGerak() {return gerak;}

    public void setGerak(int gerak) {this.gerak = gerak;}
    
}

interface main{
    public void move(String[][]map,ArrayList<Enemy> enemy);
}