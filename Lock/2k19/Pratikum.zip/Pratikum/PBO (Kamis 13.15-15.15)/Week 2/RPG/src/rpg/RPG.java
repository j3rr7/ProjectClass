/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author steve
 */
public class RPG {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scInt = new Scanner(System.in);
        Scanner scStr = new Scanner(System.in);
        Random rnd = new Random();
        String[][] map = new String[12][22];
        int x = 1, y = 1;
        Hero player, enemy;
        
        for (int i = 0; i < 12; i++) {
            for (int j = 0; j < 22; j++) {
                if (i == 0 || j == 0 || i == 11 || j == 21) {
                    map[i][j] = "#";
                } else if (i == 5 && j == 1) {
                    map[i][j] = "H";
                }else if (i == 10 && j == 20) {
                    map[i][j] = "B";
                }else{
                    map[i][j] = " ";
                }
            }
        }
        System.out.println("Pilih Hero");
        System.out.println("1. Warrior");
        System.out.println("2. Mage");
        System.out.println("3. Range");
        System.out.print("Input: ");
        int input = scInt.nextInt();
        player = new Hero(input);
        
        boolean infi = true;
        boolean map1 = true, battle = false;
        int batasBawah = 0, batasAtas = 11;
        int langkah = 0, chance = 0;
        
        while(infi == true){
            map[5][1] = "H";
            map[y][x] = "P";
            if (map1 == true) {
                batasBawah = 0;
                batasAtas = 11;
            } else if(map1 == false){
                batasBawah = 11;
                batasAtas = 22;
            }
            for (int i = 0; i < 12; i++) {
                for (int j = batasBawah; j < batasAtas; j++) {
                    System.out.print(map[i][j]);
                }System.out.println("");
            }
            System.out.println("Langkah: " + langkah);
            String pilihan = "";
            if (player.getHp() <= 0) {
                System.out.println("GAMEOVER");
                pilihan = " ";
                infi = false;
            } else {
                System.out.print("Input: ");
                pilihan = scStr.nextLine();
            }
            if (pilihan.equalsIgnoreCase("w")) {
                map[y][x] = " ";
                y--;
                if (map[y][x].equals("#")|| map[y][x].equals("B")) {
                    y++;
                }else{
                    langkah++;
                }
            } else if (pilihan.equalsIgnoreCase("a")) {
                map[y][x] = " ";
                x--;
                if (map[y][x].equals("#")|| map[y][x].equals("B")) {
                    x++;
                }else{
                    langkah++;
                }
            } else if (pilihan.equalsIgnoreCase("s")) {
                map[y][x] = " ";
                y++;
                if (map[y][x].equals("#")|| map[y][x].equals("B")) {
                    y--;
                }else{
                    langkah++;
                }
            } else if (pilihan.equalsIgnoreCase("d")) {
                map[y][x] = " ";
                x++;
                if (map[y][x].equals("#")|| map[y][x].equals("B")) {
                    x--;
                }else{
                    langkah++;
                }
            } 
            
            if (x > 10) {
                map1 = false;
            }else if (x < 11) {
                map1 = true;
            }
            
            if (langkah > 5) {
                chance = rnd.nextInt(100)+1;
            }
            
            if (chance > 50 || (y == 9 && x == 20)) {
                battle = true;
            }
            
            if (battle == true) {
                if (y == 9 && x == 20) {
                    enemy = new Hero("Boss");
                    System.out.println("BOSS");
                }else {
                    enemy = new Hero("");
                }
                int hpLawan = enemy.getHp(), hpPlayer = player.getHp();
                int turn = 1;
                do{
                    System.out.println("----------------");
                    System.out.println("Turn " + turn);
                    System.out.println("Lawan (" + enemy.getJob() + ")");
                    System.out.println("HP: " + enemy.getHp() + "/" + enemy.getMaxhp());
                    System.out.println("MP: " + enemy.getMp() + "/" + enemy.getMaxmp());
                    System.out.println("");
                    System.out.println("Player (" + player.getJob() + ")");
                    System.out.println("HP: " + player.getHp() + "/" + player.getMaxhp());
                    System.out.println("MP: " + player.getMp() + "/" + player.getMaxmp());
                    System.out.println("1. Attack");
                    System.out.println("2. Skill");
                    System.out.println("3. Defend");
                    System.out.print("Input: ");
                    String job = player.getJob();
                    int simpan = 0;
                    do{
                        input = scInt.nextInt();
                        if (input == 1) {
                            player.battle(enemy, input, "player");
                        }else if (input == 2) {
                            player.useSkill(enemy, input, "player");
                            simpan = turn;
                        }else if (input == 3) {
                            System.out.println("Player Def");
                        }
                    }while(player.getMp() < player.getManacost());
                    
                    if (simpan+3 == turn) {
                        enemy.setAccuracy(100);
                    }
                    if(enemy.getHp() > 0){
                       enemy.battle(player, input, "enemy");
                    }
                    turn++;
                    if (turn % 3 == 0) {
                        System.out.println("Player +10 MP");
                        player.setMp(player.getMp()+10);
                    }
                }while(enemy.getHp() > 0 && player.getHp() > 0 );
                if (enemy.getHp() <= 0 && !enemy.getJob().equals("Boss") ) {
                    System.out.println("Player win against " + enemy.getJob());
                }else if(enemy.getJob().equals("Boss")){
                    System.out.println("Player win the game");
                    infi = false;
                }
                langkah = 0;
                chance = 0;
            }
            battle = false;
            if (x == 1 && y == 4) {
                player.setHp(player.getMaxhp());
                player.setMp(player.getMaxmp());
            }
        }
    }
    
}
