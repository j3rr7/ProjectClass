/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;

import java.util.Random;

/**
 *
 * @author steve
 */
public class Hero {
    Random rnd = new Random();
    private int basicAtk, magicAtk, evasion, accuracy, hp, maxhp , mp, maxmp, manacost, chance;
    private String job;
    private String[] skill = new String[2];
    private static int jumlahHero;
    
    public Hero(int pil){
        if (pil == 1) {
            job = "Warrior";
            basicAtk = 100; magicAtk = 20; evasion = 0; accuracy = 90;
            hp = 520; maxhp = 520; mp = 30; maxmp = 30;
            skill[0] = "Power Break"; skill[1] = "Armor Break"; manacost = 8;
        }else if (pil == 2) {
            job = "Mage";
            basicAtk = 30; magicAtk = 200; evasion = 10; accuracy = 75;
            hp = 360; maxhp = 360; mp = 120; maxmp = 120;
            skill[0] = "Magic Ball"; skill[1] = "Magic Boost"; manacost = 4;
        }else if (pil == 3) {
            job = "Range";
            basicAtk = 70; magicAtk = 100; evasion = 5; accuracy = 100;
            hp = 610; maxhp = 610; mp = 40; maxmp = 40;
            skill[0] = "Blind Attack";skill[1] = "Silence Attack"; manacost = 5;
        }
    }
    
    public Hero(String a){
        chance = 75;
        int acak = rnd.nextInt(2)+1;
        if (a.equals("Boss")) {
            job = "Boss";
            basicAtk = 50; magicAtk = 20; hp = 300; maxhp = 300;accuracy = 100;
            mp = 200; maxmp = 200; skill[0] = "Increase Attack"; manacost = 10;
        }else if (acak == 1) {
            job = "Wild Dog";
            basicAtk = 32; magicAtk = 10; hp = 150; maxhp = 150;accuracy = 100;
            mp = 50; maxmp = 50; skill[0] = "Fire Torch"; manacost = 40;
        } else if(acak == 2){
            job = "Magic Monster";
            basicAtk = 7; magicAtk = 70; hp = 200; maxhp = 200;accuracy = 100;
            mp = 300; maxmp = 300; skill[0] = "Thunder"; manacost = 50;
        }
    }
    public void battle(Hero var, int input, String tentu){
        int chanceLawan = rnd.nextInt(100)+1;
        int chanceSkill = rnd.nextInt(100)+1;
        int chancePlayer = rnd.nextInt(100)+1;
        if (tentu.equals("player")) {
            if (chancePlayer <= accuracy) {
                System.out.println("Player attack enemy");
                var.hp -= this.basicAtk;
            }else{
                System.out.println("Attack Miss");
            }
        }else if (tentu.equals("enemy")){
            if (chanceLawan <= accuracy) {
                if (chanceSkill < 75 || mp < manacost) {
                    System.out.println("Enemy attack player");
                    if (input == 3) {
                       var.hp -= (this.basicAtk * 0.3); 
                    }else{
                       var.hp -= this.basicAtk;
                    }
                } else {
                    useSkill(var, input, "enemy");
                }
            }else{
                System.out.println("Attack Miss");
            }
        }
    }
    
    public void useSkill(Hero var, int input, String tentu){
        if (mp >= manacost) {
            if (tentu.equals("player")) {
                System.out.println("Player use " + skill);
                if (job.equals("Warrior")) {
                    var.hp -= this.basicAtk;
                    var.basicAtk *= 0.9;
                    var.magicAtk *= 0.9;
                }else if (job.equals("Mage")) {
                    var.hp -= this.magicAtk;
                }else if (job.equals("Range")) {
                    var.accuracy -= (var.accuracy *0.1); 
                }
            }else if(tentu.equals("enemy")){
                System.out.println(job + " use " + skill);
                if (job.equals("Boss")) {
                    this.basicAtk += 5;
                }else if (job.equals("Wild Dog") || job.equals("Magic Monster")) {
                    if (input == 3) {
                       var.hp -= (this.magicAtk * 0.3); 
                    }else{
                       var.hp -= this.magicAtk;
                    }
                }
            }
            mp -= manacost;
        }else{
            System.out.println("Mana tidak cukup");
        }
    }

    public int getMaxhp() {
        return maxhp;
    }

    public int getMaxmp() {
        return maxmp;
    }

    public int getManacost() {
        return manacost;
    }

    public void setAccuracy(int accuracy) {
        this.accuracy = accuracy;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        if (hp >= maxhp) {
            this.hp = maxhp;
        }else{
            this.hp = hp;
        }
    }

    public int getMp() {
        return mp;
    }

    public void setMp(int mp) {
        if (mp >= maxmp) {
            this.mp = maxmp;
        }else{
            this.mp = mp;
        }
    }

    public String getJob() {
        return job;
    }

    
}
