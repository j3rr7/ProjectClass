/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package materi.week.pkg2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author B501
 */
public class MateriWeek2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scInt = new Scanner(System.in);
        Scanner scStr = new Scanner(System.in);
        Random rnd = new Random();
        RPG player = new RPG();
        
        System.out.print("Inputan nama: ");
        String nama = scStr.nextLine();
        player.setNama(nama);
        
        System.out.println("Job");
        System.out.println("1. Knight");
        System.out.println("2. Mage");
        System.out.println("3. Archer");
        System.out.print("Pilihan: ");
        int pilihan = scInt.nextInt();
        
        if(pilihan == 1){
            player.setJob("Knight");
            player.setHp(100);
            player.setMaxhp(100);
            int att = rnd.nextInt(6)+10;
            player.setAtk(att);
            player.setAcc(90);
            player.setBonus(25/2);
        }else if (pilihan == 2) {
            player.setJob("Mage");
            player.setHp(80);
            player.setMaxhp(80);
            int att = rnd.nextInt(6)+15;
            player.setAtk(att);
            player.setAcc(80);
            player.setBonus(35/2);
        }else if (pilihan == 3) {
            player.setJob("Knight");
            player.setHp(120);
            player.setMaxhp(120);
            int att = rnd.nextInt(5)+8;
            player.setAtk(att);
            player.setAcc(75);
            player.setBonus(20/2);
        }
        boolean infi = true;
        while(infi == true){
            System.out.println("Name: " + player.getNama());
            System.out.println("Gold: " + player.getGold());
            System.out.println("Menu");
            System.out.println("----");
            System.out.println("1. Battle");
            System.out.println("2. Power up");
            System.out.println("3. Lihat Status");
            System.out.println("4. Rest");
            System.out.println("5. Exit");
            System.out.print("Pilihan: ");
            int input = scInt.nextInt();
            
            if (input == 1) {
                boolean cek = false;;
               String namaLawan = "";
               int hplawan = 0;
               int atklawan = 0;
               int chancelawan = 0;
                do {
                    int lawan = rnd.nextInt(3)+1;
                    if (lawan == 1) {
                        namaLawan = "Knight";
                        atklawan = rnd.nextInt(6)+10;
                        hplawan = 100;
                        chancelawan = 90;
                    }else if (lawan == 2) {
                        namaLawan = "Mage";
                        atklawan = rnd.nextInt(6)+15;
                        hplawan = 80;
                        chancelawan = 80;
                    }else if (lawan == 3) {
                        namaLawan = "Archer";
                        atklawan = rnd.nextInt(5)+8;
                        hplawan = 120;
                        chancelawan = 75;
                    }
                    
                    if (!namaLawan.equals(player.getJob())) {
                        cek = true;
                    }else {
                        namaLawan = "";
                    }
                } while (cek == false);
                int dmgplayer = player.getAtk(), dmglawan = atklawan;
                
                int ctr = 0;
                do{
                    int besar = rnd.nextInt(100)+1;
                    System.out.println("Player("+ player.getNama()+ "-" + player.getJob()+ ")");
                    System.out.println("HP: " + player.getHp() + "/" + player.getMaxhp());
                    System.out.println("Enemy(Bot-" + namaLawan+ ")");
                    System.out.println("HP: " + hplawan);
                    
                    if (ctr%2 == 0) {
                        System.out.print("Player menyerang enemy sebesar ");
                        if (player.getJob().equals("Knight")) {

                            System.out.print(dmgplayer);
                            if (namaLawan.equals("Mage")) {
                                dmgplayer += player.getBonus();
                                System.out.println("(Bonus Damage)");
                            }

                        }else if (player.getJob().equals("Mage")) {
                            if (namaLawan.equals("Archer")) {
                                dmgplayer += player.getBonus();
                                System.out.println("(Bonus Damage)");
                            }
                        }else if(player.getJob().equals("Archer")){
                            if (namaLawan.equals("Knight")) {
                                dmgplayer += player.getBonus();
                                System.out.println("(Bonus Damage)");
                            }
                        }
                        if (besar > player.getAcc()) {
                            System.out.println("Miss");
                        } else {
                            hplawan -= dmgplayer;
                        }
                    } else {
                        System.out.println("Enemy menyerang player");
                        if (besar > chancelawan) {
                            System.out.println("MISS");
                        }else  {
                            player.setHp(player.getHp()-dmglawan);
                        }
                    }
                    ctr++;
                }while(hplawan > 0 && player.getHp() > 0);
                
                if (player.getHp() < 0) {
                    System.out.println("Game over");
                    infi = false;
                }else if (hplawan <= 0) {
                    System.out.println("Player win");
                    int tambahgold = rnd.nextInt(301)+200;
                    player.setGold(player.getGold() + tambahgold);
                }
                
            }else if (input == 2) {
                System.out.println("Menu Power Up");
                System.out.println("1. Power Up Hp");
                System.out.println("2. Power Up Atk");
                System.out.print("Pilihan; ");
                int powerup = scInt.nextInt();
                if (powerup == 1 ) {
                    if (player.getGold() >= 250) {
                        player.setGold(player.getGold() - 250);
                        int tambah = rnd.nextInt(16)+10;
                        player.setMaxhp(player.getMaxhp()+tambah);
                        System.out.println("Hp telah bertambah sebesar " + tambah);
                    } else {
                        System.out.println("Gold tidak mencukupi");
                    }
                }else if (powerup == 2) {
                    if (player.getGold() >= 200) {
                        player.setGold(player.getGold() - 200);
                        int tambah = rnd.nextInt(3)+3;
                        player.setAtk(player.getAtk() + tambah);
                        System.out.println("Atk telah bertambah sebesar " + tambah);
                    } else {
                        System.out.println("Gold tidak mencukupi");
                    }
                }
            }else if (input == 3) {
                System.out.println("Nama: " + player.getNama());
                System.out.println("Class: " + player.getJob());
                System.out.println("HP: " + player.getHp() + " / " + player.getMaxhp());
                System.out.println("Attack: " + player.getAtk());
                System.out.println("Acc: " + player.getAcc() + "%");
            }else if (input == 4) {
                if (player.getGold() >= 100) {
                    player.setHp(player.getMaxhp()) ;
                    player.setGold(player.getGold() - 100);
                }
            }else if (input == 5) {
                infi = false;
            }
        }
        
    }
    
}
