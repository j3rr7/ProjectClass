/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tutor.week.pkg3;

/**
 *
 * @author B501
 */
public class Mahasiswa {
    private String nrp, nama, ttl;
    private static int count;
    
    Mahasiswa(String nrp, String nama, String ttl){
        this.nrp = nrp;
        this.nama = nama;
        this.ttl = ttl;
        Mahasiswa.count++;
    }
    
    public String cetakMahasiswa(){
        return "Nrp: " + this.nrp + " nama: " + this.nama + " ttl: " + this.ttl + " " + count;
    }

    public String getNrp() {
        return nrp;
    }

    public void setNrp(String nrp) {
        this.nrp = nrp;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getTtl() {
        return ttl;
    }

    public void setTtl(String ttl) {
        this.ttl = ttl;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Mahasiswa.count = count;
    }
    
    
}
