/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tutor.week.pkg3;

import java.util.ArrayList;

/**
 *
 * @author B501
 */
public class TutorWeek3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Mahasiswa mhs1 = new Mahasiswa("111", "abc", "Sby, 1 Jan 2018");
        //System.out.println(mhs1.getCount());
        
//        Mahasiswa[] arrMhs = new Mahasiswa[5];
//        for (int i = 0; i < 5; i++) {
//            arrMhs[i] = new Mahasiswa(i +"", "Aaaa", "");
//            System.out.println(arrMhs[i].cetakMahasiswa());
//            System.out.println("===========");
//        }
        Mahasiswa temp = new Mahasiswa("temp", "temp", "temp");
//        System.out.println(Mahasiswa.getCount());

            ArrayList<Mahasiswa> arrLMhs = new ArrayList<>();
            arrLMhs.add(temp);
            for (int i = 0; i < 10; i++) {
                arrLMhs.add(new Mahasiswa("", "", ""));
            }
            
            
            
            for (int i = 0; i < arrLMhs.size(); i++) {
                if (arrLMhs.get(i).equals(temp)) {
                    arrLMhs.remove(i);
                }
            }
            
            for (Mahasiswa x:arrLMhs) {
                System.out.println(x.cetakMahasiswa());
            }
    }
    
}
