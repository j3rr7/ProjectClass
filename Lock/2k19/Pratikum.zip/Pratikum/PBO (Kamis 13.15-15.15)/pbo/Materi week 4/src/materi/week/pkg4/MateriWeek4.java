/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package materi.week.pkg4;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author B501
 */
public class MateriWeek4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scInt = new Scanner(System.in);
        Scanner scStr = new Scanner(System.in);
        User user = new User();
        String username, password;
        ArrayList<Pegawai> pegawai = new ArrayList<>();
        ArrayList<Customer> customer = new ArrayList<>();
        Admin admin = new Admin();
        boolean infi = true;
        while(infi == true){
            System.out.print("Username: ");
            username = scStr.nextLine();
            System.out.print("Password: ");
            password = scStr.nextLine();
            if (username.equals("admin") && password.equals("admin")) {
                boolean infi2 = true;
                do{
                    System.out.println("1. Registrasi Pegawai");
                    System.out.println("2. Registrasi Nomor Meja");
                    System.out.println("3. Lihat Menu");
                    System.out.println("4. Lihat Status");
                    System.out.println("5. Logout");
                    System.out.print("Pilihan: ");
                    int pilihan = scInt.nextInt();
                    if (pilihan == 1) {
                        Pegawai tambahPegawai = new Pegawai();
                        System.out.print("Username: ");
                        username = scStr.nextLine();
                        System.out.print("Password: ");
                        password = scStr.nextLine();
                        //cek username pass
                        boolean kembar = false;
                        if (username.equals("admin")) {
                                kembar = true;
                        }
                        for (int i = 0; i < pegawai.size(); i++) {
                            if (username.equals(pegawai.get(i).getUsername())) {
                                kembar = true;
                            }
                        }
                        if (kembar == true) {
                            System.out.println("Username kembar");
                        }else {
                            System.out.println("Berhasil");
                            tambahPegawai.setUsername(username);
                            tambahPegawai.setPassword(password);
                            pegawai.add(tambahPegawai);
                        }
                    }else if (pilihan == 2) {
                        System.out.print("Nomor Meja: ");
                        Customer tambahCustomer = new Customer();
                        String nomor = scStr.nextLine();
                        boolean kembar = false;
                        for (int i = 0; i < customer.size(); i++) {
                            if (username.equals(customer.get(i).getUsername())) {
                                kembar = true;
                            }
                        }
                        if (kembar == true) {
                            System.out.println("Username kembar");
                        }else {
                            tambahCustomer.setUsername(nomor);
                            tambahCustomer.setPassword("C");
                            customer.add(tambahCustomer);
                        }
                    }else if (pilihan == 3) {
                        System.out.println("Makanan: ");
                        if (admin.hargaMakanan.size() > 0) {
                               for (int i = 0; i < admin.hargaMakanan.size(); i++) {
                                System.out.println((i+1) + ". " + admin.namaMakanan.get(i) + "  " + admin.hargaMakanan.get(i));
                            }
                        }
                        System.out.println("Minuman");
                        if (admin.hargaMinuman.size() > 0) {
                               for (int i = 0; i < admin.hargaMinuman.size(); i++) {
                                System.out.println((i+1) + ". " + admin.namaMinuman.get(i) + "  " + admin.hargaMinuman.get(i));
                            }
                        }
                        System.out.print("Tambah/Hapus: ");
                        String apapun = scStr.nextLine();
                        if (apapun.equalsIgnoreCase("tambah")) {
                            
                        }else if (apapun.equalsIgnoreCase("hapus")){
                            System.out.print("Input:");
                            String hapus = scStr.nextLine();
                        }
                    }else if (pilihan == 4) {
                        for (int i = 0; i < pegawai.size(); i++) {
                            pegawai.get(i).cetak();
                        }
                        for (int i = 0; i < customer.size(); i++) {
                            customer.get(i).cetak();
                        }
                    }else if (pilihan == 5) {
                        infi2 = false;
                    }
                }while(infi2 == true);
            }else {
                boolean kembar1 = false, kembar2 = false;
                int index = 0;
                for (int i = 0; i < pegawai.size(); i++) {
                    if (username.equals(pegawai.get(i).getUsername())) {
                        kembar1 = true;
                        index = i;
                    }
                }
                for (int i = 0; i < customer.size(); i++) {
                    if (username.equals(customer.get(i).getUsername())) {
                        kembar2 = true;
                        index = i;
                    }
                }
                
                if (kembar1 == true ) {
                    Pegawai pegawai_aktif = pegawai.get(index);
                    boolean infi3 = true;
                    do{
                        System.out.println("1.Kasir");
                        System.out.println("2. Logout");
                        System.out.println("Pilihan: ");
                        int pilihan2 = scInt.nextInt();
                        if (pilihan2== 1) {
                            System.out.println("Tampilan list meja: ");
                            for (int i = 0; i < customer.size(); i++) {
                                System.out.println(customer.get(i).getUsername());
                            }
                            System.out.print("Input: ");
                            String input = scStr.nextLine();
                        }else if (pilihan2 == 2) {
                            infi3 = false;
                        }
                   }while(infi3 == true);
                }else if(kembar2 == true){
                    Customer customer_aktif = customer.get(index);
                    boolean infi3 = true;
                    do{
                        System.out.println("1. Pesan");
                        System.out.println("2. Logout");
                        System.out.println("Pilihan: ");
                        int pilihan2 = scInt.nextInt();
                        if (pilihan2== 1) {
                            for (int i = 0; i < admin.hargaMakanan.size(); i++) {
                                System.out.println((i+1) + ". " + admin.namaMakanan.get(i) + admin.hargaMakanan.get(i));
                            }
                            for (int i = admin.hargaMakanan.size(); i < admin.hargaMinuman.size()+admin.hargaMakanan.size(); i++) {
                                System.out.println((i+1) + ". " + admin.namaMinuman.get(i) + admin.hargaMinuman.get(i));
                            }
                            System.out.print("Input: ");
                            int input = scStr.nextInt();
                        }else if (pilihan2 == 2) {
                            infi3 = false;
                        }
                   }while(infi3 == true);
                }
                
            }
        }
        
    }
    
}
