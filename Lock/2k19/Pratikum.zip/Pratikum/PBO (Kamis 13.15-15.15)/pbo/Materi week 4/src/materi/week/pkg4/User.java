/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package materi.week.pkg4;

import java.util.ArrayList;

/**
 *
 * @author B501
 */
public class User {
    private String username, password;
    ArrayList<String> namaMakanan = new ArrayList<>();
    ArrayList<Integer> hargaMakanan = new ArrayList<>();
    ArrayList<String> namaMinuman = new ArrayList<>();
    ArrayList<Integer> hargaMinuman = new ArrayList<>();
    
    public void tambah(String a, int b, String c, int d){
        namaMakanan.add(a);
        hargaMakanan.add(b);
        namaMinuman.add(c);
        hargaMinuman.add(d);
    }
    
    public void cetak(){
        System.out.println("Username: " + this.username);
        System.out.println("Password: " + this.password);
    }
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
}

class Admin extends User{
    
  
}

class Pegawai extends User{
    
}

class Customer extends User{
    private boolean pakai;
    ArrayList<String> pesanan = new ArrayList();

    public boolean isPakai() {
        return pakai;
    }

    public void setPakai(boolean pakai) {
        this.pakai = pakai;
    }
    
    
}
