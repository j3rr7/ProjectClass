/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tutor.week.pkg4;

import java.util.ArrayList;

/**
 *
 * @author B501
 */
public class TutorWeek4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Anjing> arrAnjing = new ArrayList<>();
        ArrayList<Burung> arrBurung = new ArrayList<>();
        Anjing dog = new Anjing("Doggy", 2, "ungu");
        dog.jalan();
        System.out.println(dog.getWarna());
        
    }
    
}
