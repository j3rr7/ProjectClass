/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tutor.week.pkg4;

/**
 *
 * @author B501
 */
public class Hewan {
    private String nama;
    private int jumlah_kaki;

    public Hewan(String nama, int jumlah_kaki) {
        this.nama = nama;
        this.jumlah_kaki = jumlah_kaki;
    }
    
    public void jalan(){
        System.out.println(this.nama + " sedang berjalan");
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getJumlah_kaki() {
        return jumlah_kaki;
    }

    public void setJumlah_kaki(int jumlah_kaki) {
        this.jumlah_kaki = jumlah_kaki;
    }
    
}

class Anjing extends Hewan{
    private String warna;
    public Anjing(String nama, int jumlah_kaki, String warna){
        super(nama, jumlah_kaki);
        this.warna = warna;
    }
    
    public void jalan(){
        System.out.println("hahahaha");
    }

    public String getWarna() {
        return warna;
    }

    public void setWarna(String warna) {
        this.warna = warna;
    }
    
}

class Burung extends Hewan{

    public Burung(String nama, int jumlah_kaki) {
        super(nama, jumlah_kaki);
    }
    
}
