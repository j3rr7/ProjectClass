/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package materi.week.pkg3;

/**
 *
 * @author B501
 */
public class Hewan {
    private String nama;
    private int hargabeli, hargaproduk, hariproduk, makan;
    private int umur;
    
    
    public Hewan(int pilihan, int gold){
        hariproduk = 0;
        makan = 0;
        umur = 0;
        if (pilihan == 1 && gold >= 500) {
            nama = "sapi";
            hargabeli = 500;
            hargaproduk = 100;hariproduk = 0;
        makan = 0;
        umur = 0;
        gold-= 500;
        }else if (pilihan == 2 && gold >= 300) {
            nama = "ayam";
            hargabeli = 300;
            hargaproduk = 50;hariproduk = 0;
        makan = 0;
        umur = 0;
        gold -=300;
        }
    }

    public  int getUmur() {
        return umur;
    }

    public void setUmur(int umur) {
        umur = umur;
    }

    public int getHargaproduk() {
        return hargaproduk;
    }

    public void setHargaproduk(int hargaproduk) {
        this.hargaproduk = hargaproduk;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getHargabeli() {
        return hargabeli;
    }

    public void setHargabeli(int hargabeli) {
        this.hargabeli = hargabeli;
    }

    public int getHariproduk() {
        return hariproduk;
    }

    public void setHariproduk(int hariproduk) {
        this.hariproduk = hariproduk;
    }

    public int getMakan() {
        return makan;
    }

    public void setMakan(int makan) {
        this.makan = makan;
    }
    
    
}
