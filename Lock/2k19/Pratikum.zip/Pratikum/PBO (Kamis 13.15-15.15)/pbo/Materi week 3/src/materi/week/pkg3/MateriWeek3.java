/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package materi.week.pkg3;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author B501
 */
public class MateriWeek3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scInt = new Scanner(System.in);
        Scanner scStr = new Scanner(System.in);
        ArrayList<Tanaman> tanaman = new ArrayList();
        ArrayList<Hewan>hewan = new ArrayList();
        int gold = 500; 
                int hari = 1;
        
        boolean infi = true;
        while(infi == true){
            System.out.println("Gold: " + gold + "G");
            System.out.println("Hari: " + hari);
            System.out.println("Jumlah Tanaman: " + tanaman.size());
            System.out.println("Jumlah Hewan : " + hewan.size());
            System.out.println("1. Ganti Hari");
            System.out.println("2. Beli Bibit");
            System.out.println("3. Siram");
            System.out.println("4. Panen");
            System.out.println("5. Beli Hewan");
            System.out.println("6. Beri Makan Hewan");
            System.out.println("7.Exit");
            System.out.print("Input: ");
            int input = scInt.nextInt();
            if (input == 1) {
                hari++;
                for (int i = 0; i < tanaman.size(); i++) {
                    tanaman.get(i).setUmur(tanaman.get(i).getUmur()+1);
                }
                for (int i = 0; i < hewan.size(); i++) {
                    hewan.get(i).setUmur(hewan.get(i).getUmur()+1);
                }
            }else if (input == 2) {
                System.out.println("1. Turnip - 120g");
                System.out.println("2. Eggplant - 200g");
                System.out.println("3. Potato - 150g");
                System.out.print("Pilihan: ");
                int pilihan = scInt.nextInt();
                tanaman.add(new Tanaman(pilihan , gold));
                if (pilihan == 1 && gold >= 100) {
            
            gold -= 120;
        }else if (pilihan == 2 && gold >= 200) {
            
            gold -= 200;
        }else if (pilihan == 3 && gold >= 150) {
            
            gold -= 150;
        }
            }else if (input == 3) {
                for (int i = 0; i < tanaman.size(); i++) {
                    System.out.println((i+1) + ". " + tanaman.get(i).getNama() + "-" + tanaman.get(i).getUmur());
                }
                int pilihan = scInt.nextInt();
                tanaman.get(pilihan - 1).setUmur(tanaman.get(pilihan - 1).getUmur() + 1);
            }else if (input == 4) {
                for (int i = 0; i < tanaman.size(); i++) {
                    int ctr = 1;
                    if (tanaman.get(i).isPanen() == true) {
                        System.out.println((ctr) + ". " + tanaman.get(i).getNama() + "-" + tanaman.get(i).getUmur());
                        ctr++;
                    }
                    
                }
                    System.out.println("Pilihan: ");
                    int pilihan  = scInt.nextInt();
                    int ctr = 1;
                    
            }else if (input == 5) {
                System.out.println("1. Sapi - 500g");
                System.out.println("2. Ayam - 300g");
                System.out.print("Pilihan: ");
                int pilihan = scInt.nextInt();
                hewan.add(new Hewan(pilihan, gold));
                if (pilihan == 1 && gold >= 500) {
           
                gold-= 500;
        }else if (pilihan == 2 && gold >= 300) {
            
                gold -=300;
        }
            }else if (input == 6) {
                for (int i = 0; i <hewan.size(); i++) {
                    System.out.println((i+1) + hewan.get(i).getNama() + "-" + hewan.get(i).getUmur() );
                }
            }else if (input == 7) {
                infi = false;
            }
            for (int i = 0; i < hewan.size(); i++) {
                if (hari % hewan.get(i).getUmur() == 0 ) {
                    gold += hewan.get(i).getHargaproduk();
                }
            }
            
            for (int i = 0; i < tanaman.size(); i++) {
                if (tanaman.get(i).getUmur() > tanaman.get(i).getHari()) {
                    tanaman.get(i).setPanen(true);
                }
            }
        }
    }
    
}
