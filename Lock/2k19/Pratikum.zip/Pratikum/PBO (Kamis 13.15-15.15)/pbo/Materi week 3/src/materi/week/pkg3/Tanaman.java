/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package materi.week.pkg3;

/**
 *
 * @author B501
 */
public class Tanaman {
    private String nama;
    private int hari, makan, hargajual, hargabeli; 
    private int umur;
    private boolean panen;
    private boolean siram;
    
    
    
    public Tanaman(int pilihan, int gold){
        
        if (pilihan == 1 && gold >= 100) {
            nama = "Turnip"; siram = false;
            hargabeli = 120;
            hargajual = 360;
            makan = 0;
            panen = false;
            hari = 3;
            umur = 0;
            gold -= 120;
        }else if (pilihan == 2 && gold >= 200) {
            nama = "eggplant";
            hargabeli = 200;siram = false;
            hargajual = 550;
            makan = 0;
            panen = false;
            hari = 6;
            umur = 0;
            gold -= 200;
        }else if (pilihan == 3 && gold >= 150) {
            nama = "potato";
            hargabeli = 150;
            hargajual = 480; siram = false;
            makan = 0;
            panen = false;
            hari = 5;
            umur = 0;
            gold -= 150;
        }
    }

    public boolean isSiram() {
        return siram;
    }

    public void setSiram(boolean siram) {
        this.siram = siram;
    }

    public int getHargajual() {
        return hargajual;
    }

    public void setHargajual(int hargajual) {
        this.hargajual = hargajual;
    }

    public int getHargabeli() {
        return hargabeli;
    }

    public void setHargabeli(int hargabeli) {
        this.hargabeli = hargabeli;
    }

    public int getUmur() {
        return umur;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public boolean isPanen() {
        return panen;
    }

    public void setPanen(boolean panen) {
        this.panen = panen;
    }
    

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getHari() {
        return hari;
    }

    public void setHari(int hari) {
        this.hari = hari;
    }

    public int getMakan() {
        return makan;
    }

    public void setMakan(int makan) {
        this.makan = makan;
    }
    
    
}
