/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tutor.polymorph;

import java.util.ArrayList;

/**
 *
 * @author B501
 */
public class TutorPolymorph {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Hewan a = new Anjing();
        a.apa();
        ArrayList<Hewan>[][] arrArrayHewan = new ArrayList[5][5];
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                arrArrayHewan[i][j] = new ArrayList<>();
                if ((i+j)%2 == 0) {
                    arrArrayHewan[i][j].add(new Anjing());
                }else {
                    arrArrayHewan[i][j].add(new Kucing());
                }
            }
        }
        
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                for (int k = 0; k < arrArrayHewan[i][j].size(); k++) {
                    if (arrArrayHewan[i][j].get(k) instanceof Kucing) {
                        System.out.print("K");
                    }else {
                        System.out.print("A");
                    }
                }
            }System.out.println("");
        }
        System.out.println(" Ẍ  Ӧ ");
    }
    
    
}

class Hewan{
    
    public void apa(){
        System.out.println("Superclass");
    }
}

class Anjing extends Hewan {
    
    public void apa(){
        System.out.println("Subclass");
    }
}

class Kucing extends Hewan{
    
}