/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package materi.poly;

import java.util.Scanner;

/**
 *
 * @author B501
 */
public class Pion {
    
    Scanner scInt = new Scanner(System.in);
    protected String[] jenis = new String[3];
    protected int[] jumlah = new int[3];
    protected String[][] simpan = new String[3][3];
    protected int x, y;
    Pion(){}
    
    public void Main(Pion player, String[][] map, int turn){
       int input1 =0, input2 = 0;
       boolean infi = true;
        do{
        for (int i = 0; i < 3; i++) {
            System.out.println( (i+1) +jenis[i] + "----" + jumlah[i]);
        }
        System.out.print("Pilihan pion: ");
        input1 = scInt.nextInt();
        System.out.print("x:");
        x = scInt.nextInt();
        System.out.print("y: ");
        y = scInt.nextInt();
        }while(jumlah[input1-1] == 0 );
        if (map[y][x].equals("_") || cek(player, map[y][x], input1-1)) {
            simpan[y][x] = map[y][x];
            map[y][x] = jenis[input1-1];
            jumlah[input1 - 1]--;
        }
    } 
    public boolean cek(Pion player, String a, int b){
        int banding = 0;
        for (int i = 0; i < 3; i++) {
            if (a.equals(player.jenis[i])) {
                banding = i;
            }
        }
        
        if (banding >= b) {
            return false;
        }else return true;
    }
    
    public void Pindah(Pion player, String[][] map){
        System.out.print("X: ");
        x = scInt.nextInt();
        System.out.print("Y: ");
        y = scInt.nextInt();
        for (int i = 0; i < 3; i++) {
            int simpanx = x, simpany = y;
            if (map[y][x].equals(jenis[i])) {
                System.out.print("x baru: ");
                x = scInt.nextInt();
                System.out.print("y baru: ");
                y = scInt.nextInt();
                map[y][x] = jenis[i];
                map[simpany][simpanx] = simpan[simpany][simpanx];
            }
        }
    }
    
}

class Player1 extends Pion{
    Player1(){
        jenis[0] = "o";
        jenis[1] = "O";
        jenis[2] = "Ӧ";
        jumlah[0] = 3;jumlah[1] = 3;jumlah[2] = 3;
    }
    
}

class Player2 extends Pion{
    Player2(){
        jenis[0] = "x";
        jenis[1] = "X";
        jenis[2] = "Ẍ";
        jumlah[0] = 3;jumlah[1] = 3;jumlah[2] = 3;
    }
}
