/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package materi.poly;

import java.util.*;

/**
 *
 * @author B501
 */
public class MateriPoly {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scInt = new Scanner(System.in);
        Scanner scStr = new Scanner(System.in);
        Pion player1 = new Player1();
        Pion player2 = new Player2();
        String[][] map = new String[4][4];
        for (int i = 1; i < 4; i++) {
            for (int j = 1; j < 4; j++) {
                map[i][j] = "_";
            }
        }
        int turn = 1;
        boolean infi = true;
        while(infi == true){
            for (int i = 1; i <4; i++) {
                for (int j = 1; j < 4; j++) {
                    System.out.print(map[i][j] + "|");
                }System.out.println();
            }
            if (turn % 2 == 1) {
                System.out.println("Giliran: Player 1");
            }else System.out.println("Giliran Player 2");
            
            System.out.println("Menu");
            System.out.println("=========");
            System.out.println("1. Taruh Pion");
            System.out.println("2. Pindah Pion");
            System.out.println("3. Exit");
            System.out.print("pilihan: ");
            int pilihan = scInt.nextInt();
            if (pilihan == 1) {
                int input1 = 0;
                int input2 = 0;
                if (turn % 2 == 1) {
                    player1.Main(player2,map, turn);
                    
                }else if(turn % 2 == 0){
                    player2.Main(player1,map, turn);
                }
            }else if(pilihan == 2){
                if (turn % 2 == 1) {
                    player1.Pindah(player2, map);
                }else if(turn % 2 == 0){
                    player2.Pindah(player1, map);
                }
            }else if(pilihan ==3){
                infi = false;
            }
            turn++;
        }
    }
    
}
