/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tutor2;

import java.util.Scanner;

/**
 *
 * @author B501
 */
public class Tutor2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scInt = new Scanner(System.in);
        Scanner scStr = new Scanner(System.in);
        Monster a = new Monster("a", 10,10);
        Monster b = new Monster("b", 20,20);
        
        System.out.println("1. A serang B");
        System.out.println("2. B serang A");
        System.out.print("pilihan: ");
        int pilihan = scInt.nextInt();
        
        if (pilihan == 1) {
            b.serang(a);
        } else if (pilihan == 2) {
            a.serang(b);
        }
        System.out.println(a.getNama() + " - " + a.getHp() + " - " + a.getDmg());
        System.out.println(b.getNama() + " - " + b.getHp() + " - " + b.getDmg());
    }
    
}
