/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tutor2;

/**
 *
 * @author B501
 */
public class Monster {
    private String nama;
    private int hp, dmg;

    public Monster(String nama, int hp, int dmg) {
        this.nama = nama;
        this.hp = hp;
        this.dmg = dmg;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getDmg() {
        return dmg;
    }

    public void setDmg(int dmg) {
        this.dmg = dmg;
    }
    
    public void serang(Monster target){
        target.hp -= this.dmg;
    }
    
}
