/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package typer.shark;

import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

/**
 *
 * @author steve
 */
public class TyperShark {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scStr = new Scanner(System.in);
        Random rnd = new Random();
        String[][] map = new String[10][20];
        boolean[] cekIsi = new boolean[10];
        Vector<String> inputan = new Vector();
        int y , randomAngka, hp = 100, skor = 0;
        boolean cek = false, infi = true;
        
        for (int i = 0; i < 10; i++) {
            cekIsi[i] = false;
            for (int j = 0; j < 20; j++) {
                if (i == 0 || i == 9 || j == 0 || j == 19) {
                    map[i][j] = "#";
                } else {
                    map[i][j] = " ";
                }   
            }
        }
        int max = 0;
        while(cek == false){
            System.out.print("Masukkan inputan: ");
            String input = scStr.nextLine();
            if (input.equals("-")) {
                cek = true;
            } else {
                inputan.add(input);
                System.out.println("Inputan telah dimasukkan");
            }
            if (max < input.length()) {
                max = input.length();
            }
        }
        int ctr = 0; 
        while(infi == true){
            cek = false;
            boolean tabrak = true;
            while(cek == false && ctr % 2 == 0 && tabrak == true){
                tabrak = false;
                y = rnd.nextInt(8)+1;
                randomAngka = rnd.nextInt(inputan.size());
                String simpan = inputan.get(randomAngka);
                int panjang = simpan.length();
                int ctrPjg = 0;
                if (cekIsi[y] == false) {
                    for (int i = 19-panjang; i < 19; i++) {
                       map[y][i] = simpan.charAt(ctrPjg) + "";     
                       ctrPjg++;
                    }
                    cekIsi[y] = true;
                    cek = true;
                } else {
                    if (map[y][19-panjang].equals(" ") ) {
                        for (int i = 19-panjang; i < 19; i++) {
                            map[y][i] = simpan.charAt(ctrPjg) + "";     
                            ctrPjg++;
                         }
                    }else{
                        tabrak = true;
                    }
                }
            }
            
            
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 20; j++) {
                    System.out.print(map[i][j]);
                }
                System.out.println("");
            }
            System.out.println("HP: " + hp);
            System.out.println("Score: "+ skor);
            System.out.print("Input: ");
            String input = scStr.nextLine();
            boolean ada = false;
            
            for (int i = 0; i < inputan.size(); i++) {
                String simpan = inputan.get(i);
                if (simpan.equals(input)) {
                    ada = true;
                }
            }
            
            if(ada == true){
                for (int i = 1; i < 9; i++) {
                    for (int j = 1; j < 19; j++) {
                        if (map[i][j].equals(input.charAt(0)+"")) {
                            int nilai = j+1;
                            boolean semuaBenar = true;
                            for (int k = 1; k < input.length(); k++) {
                                if (!map[i][nilai].equals(input.charAt(k)+"")) {
                                    semuaBenar = false;
                                }
                                nilai++;
                            }
                            if (semuaBenar == true) {
                                for (int k = j; k < j+input.length(); k++) {
                                    map[i][k] = " ";
                                }
                                skor += 5;
                            }
                        }
                    }
                }    
            }
            
            for (int i = 1; i < 9; i++) {
                if (!map[i][1].equals(" ")) {
                    hp -= 5;
                    String simpan = "";
                    int panjang = max;
                    boolean cekApa = false;
                    
                    while(panjang >= 0 && cekApa == false){
                        for (int j = 1; j < panjang+1; j++) {
                            simpan += map[i][j];
                        }
                        boolean semuaBenar = false;
                        for (int j = 0; j < inputan.size(); j++) {
                            if (simpan.equals(inputan.get(j))) {
                                cekApa = true;
                            }
                        }
                        panjang--;
                        simpan = "";
                    }
                    
                    for (int j = 1; j < panjang+2; j++) {
                        map[i][j] = " ";
                    }
                }
            }
            
            for (int i = 1; i < 9; i++) {
                for (int j = 1; j < 19; j++) {
                    if (map[i][j+1].equals("#")) {
                        map[i][j] = " ";
                    } else {
                        map[i][j] = map[i][j+1];
                    }
                }
            }
            
            for (int i = 1; i < 9; i++) {
                int jum = 0;
                for (int j = 1; j < 19; j++) {
                    if (map[i][j].equals(" ")) {
                        jum++;
                    }
                }
                if (jum == 18) {
                    cekIsi[i] = false;
                }
            }
            
            if(hp <= 0){
                System.out.println("Game Over");
                infi = false;
            }
            ctr++;
        }
    }
}
