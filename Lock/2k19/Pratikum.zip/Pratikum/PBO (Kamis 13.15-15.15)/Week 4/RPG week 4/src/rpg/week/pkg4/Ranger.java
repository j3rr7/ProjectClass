package rpg.week.pkg4;

public class Ranger extends Hero {
    public Ranger(){
        super(); job = "Ranger"; armor = 4; PSArea = 3;
        basicAtk = 70; magicAtk = 100; evasion = 5; accuracy = 100;
        hp = 610; maxhp = 610; mp = 40; maxmp = 40;manacost[1] = 5;
        skill[0] = "Blind Attack";skill[1] = "Silence Attack"; manacost[0] = 5;
        manacost[0] = 10; manacost[1] = 12;
    }

    public void evolve(){
        if (level >= 10) { System.out.println("Hero berevolusi menjadi trooper");
            job = "Trooper"; armor += 2; evasion = 10; accuracy = 100;
            basicAtk = (int)((double) basicAtk*1.2); magicAtk = (int) ((double) magicAtk*1.1);
            maxhp = (int)((double) maxhp*1.1); hp = maxhp; maxmp = (int)((double) maxmp*1.1);
            mp = maxmp;skill[0] = "Blind + Silence Attack"; skill[1] = "Drain";
            manacost[0] = 10; manacost[1] = 12;
        }else System.out.println("Level belum cukup");
    }
        
    @Override
    public void fullBattle(Enemy enemy, boolean PStrike){
        int turn = 1;
        do{
            System.out.println("----------------");
            System.out.println("Turn " + turn);
            enemy.battleStats(); System.out.println("");this.battleStats();
            System.out.println("1. Attack");
            System.out.println("2. Skill");
            System.out.println("3. Defend");
            System.out.print("Input: ");
            int input = 1;
            do{
                input = scInt.nextInt();
                if (input == 1) this.battle(enemy, input);
                else if (input == 2) this.useSkill(enemy, input);
                else if (input == 3) System.out.println("Player Def");
            }while((this.mp < this.manacost[0] || this.mp < this.manacost[1]) && input == 2);
            if(enemy.hp > 0){
                if (PStrike == true && turn > 2) enemy.battle(this, input);
                else if(PStrike == false) enemy.battle(this, input);
            }
            
            for (int i = 0; i < 2; i++) {
                if (enemy.turnDebuf[i] > 0) enemy.turnDebuf[i]--;
            }
            if(this.turnBuff[0] > 0) this.turnBuff[0]--;
            turn++;
            if (turn % 3 == 0) {
                System.out.println("Player +10 MP");this.setMp(mp + 10);
            }
        }while(enemy.hp > 0 && this.hp > 0 );
        if (enemy.hp <= 0) this.setExp(this.exp + enemy.expdrop);
    }
    
    public void battle(Enemy var, int input){
        int chancePlayer = rnd.nextInt(100)+1;
        if (chancePlayer <= accuracy && (this.basicAtk - var.armor) > 0) {
            System.out.println("Player attack enemy");
            var.hp -= (this.basicAtk - var.armor);
        }else System.out.println("Player attack Miss");
    }
    
    public void useSkill(Enemy var, int input){
        int pilihan = 0;
        do{
            System.out.println("Pilih Skill");
            System.out.println("1. " + this.skill[0]);
            System.out.println("2. " + this.skill[1]);
            System.out.print("Pilihan: ");
            pilihan = scInt.nextInt();
        }while (pilihan > 2 || pilihan < 0);
        
        if (mp >= manacost[pilihan-1]) {
            System.out.println("Player use " + skill[pilihan-1]);
            if (job.equals("Ranger")) {
                if (pilihan == 1) {
                    var.accuracy -= (var.accuracy *0.1); 
                    var.turnDebuf[0] += 3;
                } else var.turnDebuf[1] += 3;
            }else if(job.equals("Trooper")){
                if (pilihan == 1) {
                    var.accuracy -= (var.accuracy *0.1); 
                    var.turnDebuf[0] += 3; var.turnDebuf[1] += 3;
                } else {
                    var.hp -= (this.magicAtk - var.armor);
                    this.hp += (this.magicAtk - var.armor); setHp(hp);
                }
            } mp -= manacost[pilihan-1];
        }else System.out.println("Mana tidak cukup");
    }
}
