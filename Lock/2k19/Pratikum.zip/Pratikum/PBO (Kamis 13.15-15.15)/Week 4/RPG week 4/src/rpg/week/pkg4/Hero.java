package rpg.week.pkg4;
import java.util.*;

public class Hero {
    Scanner scInt = new Scanner(System.in);
    Random rnd = new Random();
    protected int basicAtk, magicAtk, evasion, accuracy, hp, maxhp , mp, maxmp, chance;
    protected int armor, exp, maxexp, golddrop, expdrop, level, sp , index, PSArea;
    protected String job; protected static int jumlahHero, gold = 800;
    protected static int [] herocost = new int[]{200, 350, 180};
    protected int [] turnDebuf = new int[2], turnBuff = new int[2], manacost = new int[2];
    protected String[] skill = new String[2];
    protected String[] elemen = {"", "Fire" , "Water", "Thunder", "Ice"}; 
    
    public Hero(){level =  1;exp = 0; maxexp = 100; index = jumlahHero;}
    
    public Hero(String a){chance = 75;}
    
    public void fullBattle(Enemy enemy, boolean PStrike){}
    
    public void battleStats(){
        System.out.println(this.job);
        System.out.println("HP: " + this.hp + "/" + this.maxhp);
        System.out.println("MP: " + this.mp + "/" + this.maxmp);
        System.out.println("Atk (B/M): " + this.basicAtk + "/" + this.magicAtk);
        System.out.println("Armor: " + this.armor);
        System.out.println("Buff: " + this.turnBuff[0]);
        System.out.println("Debuf: " + this.turnDebuf[0] + " , " + this.turnDebuf[1]);
    }

    public void cetakList(int jumlah){
        System.out.print((jumlah+1)+". " + this.job );
        System.out.print(" - " + this.level );
        System.out.println(" - " + this.hp + "/" + this.maxhp);
    }
    
    public void tambahStats(){
        System.out.println("Jumlah SP: " + sp + "SP");
        System.out.println("1. +300 HP");
        System.out.println("2. +20 MP");
        System.out.println("3. +20 Attack");
        System.out.println("4. +1 Armor");
        System.out.println("5. +3% Evasion");
        System.out.println("6. +2% Akurasi");
        System.out.print("Input: ");
        int mintasp = scInt.nextInt();
        if (sp == 0) { System.out.println("SP tidak cukup");
        }else {
            if (mintasp == 1) {maxhp+= 300;
            }else if (mintasp == 2) {maxmp+=20;
            } else if (mintasp == 3) {basicAtk += 20; magicAtk += 20;
            } else if (mintasp == 4) {armor += 1;
            } else if (mintasp == 5) {evasion += 3; setEvasion(evasion);
            } else if (mintasp == 6) {accuracy += 2;setAccuracy(accuracy);
            }sp--;
        }
    }
    
    public void setExp(int exp) {
        if (exp >= maxexp) {level++; sp++; this.exp = (exp - maxexp);
        }else this.exp = exp;
    }
    
    public void setEvasion(int evasion){
        if (evasion > 100) this.evasion = 100;
        else this.evasion = evasion;
    }
    
    public void setAccuracy(int accuracy){
        if (accuracy > 100) this.accuracy = 100;
        else this.accuracy = accuracy;
    }

    public void setHp(int hp) {
        if (hp >= maxhp) { this.hp = maxhp;
        }else{ this.hp = hp;}
    }

    public void setMp(int mp) {
        if (mp >= maxmp) { this.mp = maxmp;
        }else { this.mp = mp;}
    }
}
