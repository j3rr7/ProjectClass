package rpg.week.pkg4;

public class Mage extends Hero { 
    
    public Mage(){
        super(); job = "Mage"; armor = 2; PSArea = 2;
        basicAtk = 30; magicAtk = 200; evasion = 10; accuracy = 75;
        hp = 360; maxhp = 360; mp = 120; maxmp = 120;manacost[1] = 4;
        skill[0] = "Magic Ball"; skill[1] = "Magic Boost"; manacost[0] = 4;
    }

    public void evolve(){
        if (level >= 10) {  System.out.println("Hero berevolusi menjadi sorcerer");
            job = "Sorcerer"; armor += 1; evasion = 20; accuracy = 75;
            basicAtk = (int)((double) basicAtk*1.05); magicAtk = (int) ((double) magicAtk*1.3);
            maxhp = (int)((double) maxhp*1.05); hp = maxhp; maxmp = maxmp*2; mp = maxmp;
            skill[0] = "Elemen Magic"; skill[1] = "Heal"; manacost[0] = 8; manacost[1] = 10;
        }else System.out.println("Level belum cukup");
    }
        
    public void fullBattle(Enemy enemy, boolean PStrike, int rndElemen){
        int turn = 1;
        do{
            System.out.println("----------------");
            System.out.println("Turn " + turn);
            enemy.battleStats(); System.out.println("");this.battleStats();
            System.out.println("1. Attack");
            System.out.println("2. Skill");
            System.out.println("3. Defend");
            System.out.print("Input: ");
            int input = 1;
            do{
                input = scInt.nextInt();
                if (input == 1) this.battle(enemy, input);
                else if (input == 2) this.useSkill(enemy, input, rndElemen);
                else if (input == 3) System.out.println("Player Def");
            }while((this.mp < this.manacost[0] || this.mp < this.manacost[1]) && input == 2);
            if(enemy.hp > 0){
                if (PStrike == true && turn > 2) enemy.battle(this, input);
                else if(PStrike == false) enemy.battle(this, input);
            }
            
            for (int i = 0; i < 2; i++) {
                if (enemy.turnDebuf[i] > 0) enemy.turnDebuf[i]--;
            }
            if(this.turnBuff[0] > 0) this.turnBuff[0]--;
            turn++;
            if (turn % 3 == 0) {
                System.out.println("Player +10 MP"); this.setMp(mp + 10);
            }
        }while(enemy.hp > 0 && this.hp > 0 );
        if (enemy.hp <= 0) this.setExp(this.exp + enemy.expdrop);
    }
    
    public void battle(Enemy var, int input){
        int chancePlayer = rnd.nextInt(100)+1;
        if (chancePlayer <= accuracy && (this.basicAtk - var.armor) > 0) {
            System.out.println("Player attack enemy");
            var.hp -= (this.basicAtk - var.armor);
        }else System.out.println("Player attack Miss");
    }
    
    public void useSkill(Enemy var, int input, int rndElemen){
        int pilihan = 0;
        do{
            System.out.println("Pilih Skill");
            System.out.println("1. " + this.skill[0]);
            System.out.println("2. " + this.skill[1]);
            System.out.print("Pilihan: ");
            pilihan = scInt.nextInt();
        }while (pilihan > 2 || pilihan < 0);
        
        if (mp >= manacost[pilihan-1]) {
            System.out.println("Player use " + skill[pilihan-1]);
            if (job.equals("Mage")) {
                if (pilihan == 1) var.hp -= this.magicAtk;
                else this.magicAtk += (magicAtk*0.5);
            }else if(job.equals("Sorcerer")){
                if (pilihan == 1) {
                    System.out.println("1. Fire");
                    System.out.println("2. Water");
                    System.out.println("3. Thunder");
                    System.out.println("4. Ice");
                    System.out.print("Pilihan: ");
                    int input2 = scInt.nextInt();
                    int dmg = this.magicAtk;
                    if (var.job.equals("Wild Dog") || var.job.equals("Boss")) {
                        if (input2 == 2 || input2 == 3)  dmg = (int)((double)(dmg*0.5));
                    }else { 
                        if (input2 + rndElemen == 5) dmg = (int)((double)(dmg*1.5));
                        else if (input2 + rndElemen == input2 * 2) dmg = (int)((double)(dmg*0.5));
                    }var.hp -= dmg; System.out.println("Damage yang diberikan: " + dmg);
                } else this.setHp(hp + (int)(double)(0.6 * maxhp));
            }mp -= manacost[pilihan-1];
        }else System.out.println("Mana tidak cukup");
    }
}
