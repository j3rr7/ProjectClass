package rpg.week.pkg4;

public class Enemy extends Hero {
    public Enemy(String a, int rndElemen){
        super(a);
        if (a.equals("B")) {
            job = "Boss"; armor = 25; expdrop = rnd.nextInt(21)+40; golddrop = 300;
            basicAtk = 80; magicAtk = 20; hp = 2000; maxhp = 2000;accuracy = 100;
            mp = 200; maxmp = 200; skill[0] = "Increase Attack"; manacost[0] = 10;
        }else if (a.equals("w")) {
            job = "Wild Dog"; armor = 15; expdrop = rnd.nextInt(6)+15; golddrop = 120;
            basicAtk = 32; magicAtk = 10; hp = 150; maxhp = 150;accuracy = 100;
            mp = 50; maxmp = 50; skill[0] = "Fire Torch"; manacost[0] = 40;
        } else if(a.equals("m")){
            job = elemen[rndElemen]; job += " Monster"; armor = 20; 
            expdrop = rnd.nextInt(6)+20; golddrop = 150;
            basicAtk = 7; magicAtk = 70; hp = 200; maxhp = 200;accuracy = 100;
            mp = 300; maxmp = 300; skill[0] = elemen[rndElemen]; manacost[0] = 50;
        }
    }
    
    public void battle(Warrior var, int input){
        int chanceLawan = rnd.nextInt(100)+1, chanceSkill = rnd.nextInt(100)+1; 
        if (chanceLawan-var.evasion <= accuracy || turnDebuf[1] > 0) {
            if (chanceSkill < 75 || mp < manacost[0]) {
                System.out.println("Enemy attack player");
                if ((this.basicAtk - var.armor) > 0) {
                    if(var.turnBuff[0] > 0) var.hp -= ((this.basicAtk - var.armor) * 0.05);
                    else if (input == 3) var.hp -= ((this.basicAtk - var.armor) * 0.3);
                    else var.hp -= (this.basicAtk - var.armor);
                }
            } else useSkill(var, input);
        }else System.out.println("Enemy attack Miss");
    }
    
    public void useSkill(Warrior var, int input){
        int pilihan = 0;
        if (mp >= manacost[0]) {
            System.out.println(job + " use " + skill[0]);
            if (job.equals("Boss")) { this.basicAtk += 5;
            }else {
                if(var.turnBuff[0] > 0)var.hp -= ((this.basicAtk - var.armor) * 0.05);
                else if (input == 3) var.hp -= (this.magicAtk * 0.3); 
                else var.hp -= this.magicAtk;
            }mp -= manacost[0];
        }else System.out.println("Mana tidak cukup");
    }

    public void battle(Mage var, int input){
        int chanceLawan = rnd.nextInt(100)+1, chanceSkill = rnd.nextInt(100)+1; 
        if (chanceLawan-var.evasion <= accuracy || turnDebuf[1] > 0) {
            if (chanceSkill < 75 || mp < manacost[0]) {
                System.out.println("Enemy attack player");
                if ((this.basicAtk - var.armor) > 0) {
                    if(var.turnBuff[0] > 0) var.hp -= ((this.basicAtk - var.armor) * 0.05);
                    else if (input == 3) var.hp -= ((this.basicAtk - var.armor) * 0.3);
                    else var.hp -= (this.basicAtk - var.armor);
                }
            } else useSkill(var, input);
        }else System.out.println("Enemy attack Miss");
    }
    
    public void useSkill(Mage var, int input){
        int pilihan = 0;
        if (mp >= manacost[0]) {
            System.out.println(job + " use " + skill[0]);
            if (job.equals("Boss")) { this.basicAtk += 5;
            }else {
                if(var.turnBuff[0] > 0)var.hp -= ((this.basicAtk - var.armor) * 0.05);
                else if (input == 3) var.hp -= (this.magicAtk * 0.3); 
                else var.hp -= this.magicAtk;
            }mp -= manacost[0];
        }else System.out.println("Mana tidak cukup");
    }    
    
    public void battle(Ranger var, int input){
        int chanceLawan = rnd.nextInt(100)+1, chanceSkill = rnd.nextInt(100)+1; 
        if (chanceLawan-var.evasion <= accuracy || turnDebuf[1] > 0) {
            if (chanceSkill < 75 || mp < manacost[0]) {
                System.out.println("Enemy attack player");
                if ((this.basicAtk - var.armor) > 0) {
                    if(var.turnBuff[0] > 0) var.hp -= ((this.basicAtk - var.armor) * 0.05);
                    else if (input == 3) var.hp -= ((this.basicAtk - var.armor) * 0.3);
                    else var.hp -= (this.basicAtk - var.armor);
                }
            } else useSkill(var, input);
        }else System.out.println("Enemy attack Miss");
    }
    
    public void useSkill(Ranger var, int input){
        int pilihan = 0;
        if (mp >= manacost[0]) {
            System.out.println(job + " use " + skill[0]);
            if (job.equals("Boss")) { this.basicAtk += 5;
            }else {
                if(var.turnBuff[0] > 0)var.hp -= ((this.basicAtk - var.armor) * 0.05);
                else if (input == 3) var.hp -= (this.magicAtk * 0.3); 
                else var.hp -= this.magicAtk;
            }mp -= manacost[0];
        }else System.out.println("Mana tidak cukup");
    }
}
