package rpg.week.pkg4;

import java.util.*;

public class Start {
    Warrior playerW = null; Mage playerM = null; Ranger playerR = null; Enemy enemy = null;
    
    public Start(ArrayList<Warrior> listWarrior, ArrayList<Mage> listMage, ArrayList<Ranger> listRanger,int index){
        Scanner scInt = new Scanner(System.in);
        Scanner scStr = new Scanner(System.in);
        Random rnd = new Random();
        String[][] map = new String[32][33];
        int x = 1, y = 1, indexAktif = index;
        
        boolean found = false; int ctrCari = 0;
        do{
            if (listWarrior.size() > ctrCari) {
                if(listWarrior.get(ctrCari).index == indexAktif){ playerW = listWarrior.get(ctrCari); found = true; }
            }if (listMage.size() > ctrCari) {
                if(listMage.get(ctrCari).index == indexAktif) {playerM = listMage.get(ctrCari); found = true;}
            }if (listRanger.size() > ctrCari) {
                if(listRanger.get(ctrCari).index == indexAktif) {playerR = listRanger.get(ctrCari); found = true;}
            }
            ctrCari++;
        }while(found == false);
        
        for (int i = 0; i < 32; i++) {
            for (int j = 0; j < 33; j++) {
                if (i == 0 || j == 0 || i == 31 || j == 32) {
                    map[i][j] = "#";
                }else{
                    map[i][j] = " ";
                }
            }
        }
        map[5][31] = "B"; map[16][31] = "B";map[26][31] = "B";
        map[30][5] = "B"; map[30][16] = "B"; 
        
        boolean infi = true, pindahMap = true, acakLawan = true, PStrike = false, menang = true;
        int batasBawah = 32, batasAtas = 0, batasKiri = 0 , batasKanan = 33;
        int jumlahBoss = 0, simpan_x = x, simpan_y = y, PS_x = 0, PS_y = 0;
        
        while(infi == true){
            jumlahBoss = 0; PStrike = false; map[16][19] = "H";
            for (int i = 0; i < 32; i++) {
                for (int j = 0; j < 33; j++) {
                    if (map[i][j].equals("B")) jumlahBoss++;
                }
            }
            if (playerW != null) {
                if (playerW.job.equals("Warrior")) map[y][x] = "W";
                else if (playerW.job.equals("Knight")) map[y][x] = "K";
            }else if (playerM != null) {
                if (playerM.job.equals("Mage")) map[y][x] = "M";
                else if (playerM.job.equals("Sorcerer")) map[y][x] = "S";
            }else if (playerR != null) {
                if (playerR.job.equals("Ranger")) map[y][x] = "R";
                else if (playerR.job.equals("Trooper")) map[y][x] = "T";
            }
            
            if (y < 11) {batasAtas = 0; batasBawah = 11;}
            else if (y < 21) {batasAtas = 11; batasBawah = 21;}
            else if (y < 32) { batasAtas = 21; batasBawah = 32;}
            
            if (x < 11) { batasKiri = 0; batasKanan = 11;
            }else if (x < 22) { batasKiri = 11; batasKanan = 22;
            }else if (x <33) { batasKiri = 22; batasKanan = 33;}
            
            if ((simpan_x == 10 && x == 11) || (simpan_x == 11 && x == 10) || (simpan_x == 21 && x == 22) || (simpan_x == 22 && x == 21) ||
                (simpan_y == 10 && y == 11) || (simpan_y == 11 && y == 10) || (simpan_y == 20 && y == 21) || (simpan_y == 21 && y == 20)) {
                pindahMap = true;
            }
            
            int acak_x = 0, acak_y = 0;
            if (pindahMap == true) {
                for (int i = batasAtas; i < batasBawah; i++) {
                    for (int j = batasKiri; j < batasKanan; j++) {
                        if (map[i][j].equals("w") || map[i][j].equals("m")) map[i][j] = " ";
                    }
                }
                for (int i = 0; i < 5; i++) {
                    int acak = rnd.nextInt(2)+1;
                    do{
                         acak_x = rnd.nextInt(batasKanan - batasKiri) + batasKiri;
                         acak_y = rnd.nextInt(batasBawah - batasAtas) + batasAtas;
                    } while(!map[acak_y][acak_x].equals(" "));
                    if (acak == 1) map[acak_y][acak_x] = "w";
                    else if (acak == 2) map[acak_y][acak_x] = "m";
                }
            }
            pindahMap = false; simpan_x = x; simpan_y = y; menang = true;
            for (int i = batasAtas; i < batasBawah; i++) {
                for (int j = batasKiri; j < batasKanan; j++) {
                    System.out.print(map[i][j]);
                }System.out.println("");
            }System.out.println("Ketik master untuk level + 10");
            String pilihan = "";
            System.out.print("Input: ");
            pilihan = scStr.nextLine();
            
            if (pilihan.equalsIgnoreCase("w")) {
                map[y][x] = " "; y--;
                if (map[y][x].equals("#")) y++;
            } else if (pilihan.equalsIgnoreCase("a")) {
                map[y][x] = " "; x--;
                if (map[y][x].equals("#")) x++;
            } else if (pilihan.equalsIgnoreCase("s")) {
                map[y][x] = " "; y++;
                if (map[y][x].equals("#")) y--;
            } else if (pilihan.equalsIgnoreCase("d")) {
                map[y][x] = " "; x++;
                if (map[y][x].equals("#")) x--;
            } else if (pilihan.equalsIgnoreCase("m")) {
                if (playerW != null) playerW.tambahStats();
                else if (playerM != null) playerM.tambahStats();
                else if (playerR != null) playerR.tambahStats();
            }else if(pilihan.equalsIgnoreCase("e")){
                if (playerW != null) playerW.evolve();
                else if (playerM != null) playerM.evolve();
                else if (playerR != null) playerR.evolve();
            }else if(pilihan.equalsIgnoreCase("master")){
                if (playerW != null) {playerW.level += 10; playerW.sp += 10;}
                else if (playerM != null) {playerM.level += 10;playerM.sp += 10;}
                else if (playerR != null) {playerR.level += 10;playerR.sp += 10;}
            }else if (pilihan.equalsIgnoreCase("x")) {
                for (int i = y-1; i <= y+1; i++) {
                    for (int j = x-1; j <= x+1; j++) {
                        if(i > 0 && j > 0){
                            if (map[i][j].equals("B") || map[i][j].equals("w") ||map[i][j].equals("m") ) {
                                PStrike = true; PS_y =i; PS_x = j;}
                        }
                    }
                }
                if (PStrike == false && playerW == null) {
                    int counter = 0;
                    if (playerM != null) counter = 2;
                    else if (playerR != null)counter = 3;
                    
                    for (int i = y-counter; i <= y+counter; i++) {
                        if (i > 0) {
                            if (map[i][x].equals("B") || map[i][x].equals("w") ||map[i][x].equals("m") ) {
                                PStrike = true; PS_y =i; PS_x = x;}
                        }
                    }
                    for (int j = x-counter; j <= x+counter; j++) {
                        if (j > 0) {
                            if (map[y][j].equals("B") || map[y][j].equals("w") ||map[y][j].equals("m") ) {
                                PStrike = true; PS_y =y; PS_x = j;}
                        }
                    }
                } if(PStrike == false) System.out.println("Tidak ada lawan di area pre-empitive strike");
            } 
            
            if (map[y][x].equals("B")|| map[y][x].equals("w") || map[y][x].equals("m") || PStrike == true){
                int rndElemen = rnd.nextInt(4)+1;
                if (PStrike == true) {enemy = new Enemy(map[PS_y][PS_x], rndElemen); System.out.println("Pre-empitive Strike");}
                else enemy = new Enemy(map[y][x], rndElemen);
                
                if (playerW != null) playerW.fullBattle(enemy, PStrike);
                else if (playerM != null) playerM.fullBattle(enemy, PStrike, rndElemen);
                else if (playerR != null) playerR.fullBattle(enemy, PStrike);
                
                if (enemy.hp <= 0) {
                    if (PStrike == true) map[PS_y][PS_x] = " ";
                    if (!enemy.job.equals("Boss") ) System.out.println("Player win against " + enemy.job);
                    else if(enemy.job.equals("Boss") && jumlahBoss == 1){
                        System.out.println("Player win the game"); infi = false;
                    } Hero.gold += enemy.golddrop;
                }else menang = false;
            }    
            if (pilihan.equalsIgnoreCase("g") || menang == false) {
                if (menang == false) {
                    if (Hero.jumlahHero > 0) {
                        System.out.println("Player Kalah");
                        ctrCari = 0; found = false;
                        do{
                            if (playerW != null) { 
                                if(listWarrior.get(ctrCari).index == indexAktif && playerW.hp <= 0){ 
                                    listWarrior.remove(ctrCari); found = true;}
                            }if (playerM != null ) { 
                                if(listMage.get(ctrCari).index == indexAktif && playerM.hp <= 0) {
                                    listMage.remove(ctrCari);found = true;}
                            }if (playerR != null ) {
                                if(listRanger.get(ctrCari).index == indexAktif && playerR.hp <= 0) {
                                    listRanger.remove(ctrCari); found = true;}
                            }ctrCari++;
                        }while(found == false);
                        x = simpan_x; y = simpan_y;
                        Hero.jumlahHero--;
                    }if(Hero.jumlahHero == 0) {infi = false; System.out.println("Kembali ke menu awal" + "\n");}
                }else if (pilihan.equalsIgnoreCase("g")){
                    ctrCari = 0; found = false;
                    do{
                        if (playerW != null) {
                            if(listWarrior.get(ctrCari).index == indexAktif){listWarrior.set(ctrCari, playerW);found = true;}
                        }if (playerM != null) {
                            if(listMage.get(ctrCari).index == indexAktif) {listMage.set(ctrCari, playerM); found = true;}
                        }if (playerR != null) {
                            if(listRanger.get(ctrCari).index == indexAktif) {listRanger.set(ctrCari, playerR); found = true;}
                        }ctrCari++;
                    }while(found == false);
                }
                if (Hero.jumlahHero == 1) {System.out.println("Ganti Hero");
                    if (listWarrior.size() == 1) {
                        playerW = listWarrior.get(0); playerM = null; playerR = null; indexAktif = listWarrior.get(0).index;
                    }else if (listMage.size() == 1) {
                        playerM = listMage.get(0); playerW = null; playerR = null;indexAktif = listMage.get(0).index;
                    }else if(listRanger.size() == 1){
                        playerR = listRanger.get(0); playerW = null; playerM = null;indexAktif = listRanger.get(0).index;
                    }
                }
                
                if(infi == true && Hero.jumlahHero > 1){
                    int mulai = 0;System.out.println("Ganti Hero");
                    if (playerW != null) { mulai = 1; 
                    }else if(playerM != null){ mulai = 2; 
                    }else if (playerR != null) { mulai = 0; 
                    }
                    boolean stop = false, stop1 = false;
                    int ctr = indexAktif + 1, simpan = mulai;
                    while(stop == false){
                        stop1 = false; 
                        while(stop1 == false){
                            if (ctr == Hero.jumlahHero) ctr = 0;
                            if (ctr != indexAktif && Hero.jumlahHero > 1) {
                                if (mulai%3 == 0) {
                                    for (int i = 0; i < listWarrior.size(); i++) {
                                        if (listWarrior.get(i).index == ctr) {
                                            playerW = listWarrior.get(i); indexAktif = ctr;
                                            stop1 = true; stop = true; playerM = null; playerR = null;}
                                    }
                                }else if (mulai%3 == 1) {
                                    for (int i = 0; i < listMage.size(); i++) {
                                        if (listMage.get(i).index == ctr) {
                                            playerM = listMage.get(i); indexAktif = ctr;
                                            stop1 = true; stop = true; playerW = null; playerR = null; }
                                    }
                                }else if (mulai%3 == 2){
                                    for (int i = 0; i < listRanger.size(); i++) {
                                        if (listRanger.get(i).index == ctr) {
                                            playerR = listRanger.get(i); indexAktif = ctr;
                                            stop1 = true; stop = true; playerW = null; playerM = null;}
                                    }
                                }
                            }
                            if (ctr == indexAktif) stop1 = true;
                            ctr++;
                        }mulai++;
                        if (simpan+3 == mulai) stop = true;
                    }
                }
            }    
            if (map[y][x].equals("H")) {
                if (playerW != null) {playerW.hp = playerW.maxhp; playerW.mp = playerW.maxmp;}
                else if (playerM != null) {playerM.hp = playerM.maxhp; playerM.mp = playerM.maxmp;}
                else if (playerR != null) {playerR.hp = playerR.maxhp; playerR.mp = playerR.maxmp;}
            }
        }
    }
}
