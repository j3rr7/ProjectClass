package rpg.week.pkg4;
import java.util.*;

public class RPGWeek4 {
    
    public static void main(String[] args) {
        Scanner scInt = new Scanner(System.in);
        ArrayList<Warrior> listWarrior = new ArrayList();
        ArrayList<Mage> listMage = new ArrayList();
        ArrayList<Ranger> listRanger = new ArrayList();
        boolean infi = true;
        while(infi == true){
            System.out.println("Gold: " + Hero.gold);
            System.out.println("1. Start Playing");
            System.out.println("2. Beli Hero (" + Hero.jumlahHero+ "/12)" );
            System.out.println("3. Lihat Hero");
            System.out.println("4. Exit");
            System.out.print("Pilihan: ");
            int pilihan  = scInt.nextInt();
            if (pilihan == 1) {
                if (Hero.jumlahHero > 0) {
                    int ctr1 = 0, ctr2 = 0, ctr3 = 0;
                    do{
                        int jumlah = ctr1 + ctr2 +ctr3;
                        if (listWarrior.size() > ctr1) {
                            if (listWarrior.get(ctr1).index == jumlah) {
                                listWarrior.get(ctr1).cetakList(jumlah);ctr1++;}
                        }
                        if (listMage.size() > ctr2) {
                            if (listMage.get(ctr2).index == jumlah) {
                                listMage.get(ctr2).cetakList(jumlah);ctr2++;}
                        }
                        if (listRanger.size() > ctr3) {
                            if (listRanger.get(ctr3).index == jumlah) {
                                listRanger.get(ctr3).cetakList(jumlah); ctr3++;}
                        } 
                    }while(ctr1 + ctr2 + ctr3 < Hero.jumlahHero);
                    System.out.print("Pilihan: ");
                    int input = scInt.nextInt();
                    input--;
                    Start game = new Start(listWarrior, listMage, listRanger, input);
                } else System.out.println("Belum punya hero");
            }else if (pilihan == 2) {
                System.out.println("Pilih Hero");
                System.out.println("1. Warrior (200g)");
                System.out.println("2. Mage (350g)");
                System.out.println("3. Ranger (180g)");
                System.out.print("Input: ");
                int input = scInt.nextInt();
                if (Hero.gold >= Hero.herocost[input-1] ){
                    if (Hero.jumlahHero <= 12) {
                        if (input > 0 && input < 4) {
                            if (input == 1) listWarrior.add(new Warrior());
                            else if(input == 2) listMage.add(new Mage());
                            else if(input == 3) listRanger.add(new Ranger());
                            Hero.jumlahHero++; Hero.gold -= Hero.herocost[input-1];
                            System.out.println("Hero telah ditambahkan");
                        }
                    } else System.out.println("Slot Penuh");
                } else System.out.println("Gold tak cukup");
                
            }else if (pilihan == 3) {
                System.out.println("==================");
                int ctr1 = 0, ctr2 = 0, ctr3 = 0;
                do{
                    int jumlah = ctr1 + ctr2 +ctr3;
                    if (listWarrior.size() > ctr1) {
                        if (listWarrior.get(ctr1).index == jumlah) {
                            listWarrior.get(ctr1).cetakList(jumlah);ctr1++;
                        }}
                    if (listMage.size() > ctr2) {
                        if (listMage.get(ctr2).index == jumlah) {
                            listMage.get(ctr2).cetakList(jumlah);ctr2++;
                        }}
                    if (listRanger.size() > ctr3) {
                        if (listRanger.get(ctr3).index == jumlah) {
                            listRanger.get(ctr3).cetakList(jumlah); ctr3++;
                        }} 
                }while(ctr1 + ctr2 + ctr3 < Hero.jumlahHero);
                System.out.println("==================");
            }else if (pilihan == 4) infi = false;
        }
    }
}
