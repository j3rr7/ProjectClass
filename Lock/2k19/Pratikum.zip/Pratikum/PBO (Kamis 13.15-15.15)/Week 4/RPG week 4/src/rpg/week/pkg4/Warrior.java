package rpg.week.pkg4;

public class Warrior extends Hero {
    public Warrior(){
        super(); job = "Warrior"; armor = 8; PSArea = 1;
        basicAtk = 100; magicAtk = 20; evasion = 0; accuracy = 90;
        hp = 520; maxhp = 520; mp = 30; maxmp = 30;manacost[0] = 8;
        skill[0] = "Power Break"; skill[1] = "Armor Break"; manacost[1] = 8;
    }
    
    public void evolve(){
        if (level >= 10) {System.out.println("Hero berevolusi menjadi knight");
            job = "Knight"; armor += 8; evasion = 0; accuracy = 95;
            basicAtk = (int)((double) basicAtk*5/4); magicAtk = (int) ((double) magicAtk*0.95);
            maxhp = (int)((double) maxhp*1.2); hp = maxhp; 
            skill[0] = "Power + Armor Break"; skill[1] = "Sentinel";
            manacost[0] = 12; manacost[1] = 4;
        }else System.out.println("Level belum cukup");
    }
    
    @Override
    public void fullBattle(Enemy enemy, boolean PStrike){
        int turn = 1;
        do{
            System.out.println("----------------");
            System.out.println("Turn " + turn);
            enemy.battleStats(); System.out.println("");this.battleStats();
            System.out.println("1. Attack");
            System.out.println("2. Skill");
            System.out.println("3. Defend");
            System.out.print("Input: ");
            int input = 1;
            do{
                input = scInt.nextInt();
                if (input == 1) this.battle(enemy, input);
                else if (input == 2) this.useSkill(enemy, input);
                else if (input == 3) System.out.println("Player Def");
            }while((this.mp < this.manacost[0] || this.mp < this.manacost[1]) && input == 2);
            if(enemy.hp > 0){
                if (PStrike == true && turn > 2) enemy.battle(this, input);
                else if(PStrike == false) enemy.battle(this, input);
            }
            
            for (int i = 0; i < 2; i++) {
                if (enemy.turnDebuf[i] > 0) enemy.turnDebuf[i]--;
            }
            if(this.turnBuff[0] > 0) this.turnBuff[0]--;
            turn++;
            if (turn % 3 == 0) {
                System.out.println("Player +10 MP"); this.setMp(mp + 10);
            }
        }while(enemy.hp > 0 && this.hp > 0 );
        if (enemy.hp <= 0) this.setExp(this.exp + enemy.expdrop);
    }
    
    public void battle(Enemy var, int input){
        int chancePlayer = rnd.nextInt(100)+1;
        if (chancePlayer <= accuracy && (this.basicAtk - var.armor) > 0) {
            System.out.println("Player attack enemy");
            var.hp -= (this.basicAtk - var.armor);
        }else System.out.println("Player attack Miss");
    }
    
    public void useSkill(Enemy var, int input){
        int pilihan = 0;
        do{
            System.out.println("Pilih Skill");
            System.out.println("1. " + this.skill[0]);
            System.out.println("2. " + this.skill[1]);
            System.out.print("Pilihan: ");
            pilihan = scInt.nextInt();
        }while (pilihan > 2 || pilihan < 0);
        
        if (mp >= manacost[pilihan-1]) {
            System.out.println("Player use " + skill[pilihan-1]);
            if (job.equals("Warrior")) {
                if (pilihan == 1) {
                    var.hp -= this.basicAtk; var.basicAtk *= 0.9;
                    var.magicAtk *= 0.9;
                }else {
                    var.hp -= this.basicAtk; var.armor = 0;
                }
            }else if(job.equals("Knight")){
                if (pilihan == 1) {
                    var.hp -= this.basicAtk; var.basicAtk *= 0.9;
                    var.magicAtk *= 0.9; var.armor = 0;
                }else turnBuff[0] = 1;
            }mp -= manacost[pilihan-1];
        }else System.out.println("Mana tidak cukup");
    }
}
