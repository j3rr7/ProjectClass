//Tabel Laporan, Supplier dan donatur dihapus dan entity peminjaman dan pengembalian ditambahkan

create table Kepala(
    ID_Kepala varchar2(10) primary key,
    Nama varchar2(25) constraint nn_kepala not null,
    Jenis_Kelamin varchar2(10) not null,
    Alamat varchar2(25) not null,
    TanggalLahir date not null,
    NomorTelepon varchar2(10) not null
);

create table Petugas(
    ID_Petugas varchar2(10) primary key,
    ID_Kepala varchar2(10),
    Nama varchar2(25) not null,
    Jenis_Kelamin varchar2(10) not null,
    Alamat varchar2(25) constraint nn_alamatPetugas not null,
    TanggalLahir date not null,
    NomorTelepon varchar2(10) not null,
    JadwalJaga varchar(8) not null,
    foreign key (ID_Kepala) references Kepala(ID_Kepala)
);

create table Anggota(
    ID_Anggota varchar2(10) primary key,
    NamaLengkap varchar2(25) constraint nn_namaAnggota not null,
    TanggalLahir date not null,
    Alamat varchar2(25) not null,
    NomorTelepon varchar2(10) not null,
    Pekerjaan varchar2(10) not null
);

create table Penerbit(
    Kode_Penerbit varchar2(10) primary key,
    Nama varchar2(30) constraint un_namaPenerbit unique,
    Alamat varchar2(30) not null,
    NomorTelepon varchar2(30) not null
);

create table Kategori(
    ID_Kategori varchar2(10) primary key,
    Nama varchar2(30) constraint un_namaKategori unique,
    Letak varchar2(15) constraint nn_Letak not null,
    Bahasa varchar2(10) not null
);

create table Pengarang(
    ID_Pengarang varchar2(10) primary key,
    Nama varchar2(30) constraint un_namaPengarang unique,
    Alamat varchar2(30) not null,
    NomorTelepon varchar2(10) not null
);

create table Peminjaman(
    ID_Peminjaman varchar2(10) primary key,
    TanggalPinjam date not null,
    LamaPinjam number not null,
    JumlahBuku number not null
);

create table Pengembalian(
    ID_Pengembalian varchar2(10) primary key,
    ID_Peminjaman varchar2(10),
    TanggalPengembalian date not null,
    JumlahBuku number not null,
    DendaKeterlambatan varchar2(20),
    foreign key (ID_Peminjaman) references Peminjaman(ID_Peminjaman)
);

create table Buku(
    ID_Buku varchar2(10) primary key,
    ID_Kategori varchar2(10),
    ID_Peminjaman varchar2(10),
    ID_Pengembalian varchar2(10),
    Kode_Penerbit varchar2(10),
    ID_Pengarang varchar2(10),
    Judul varchar2(20) not null,
    JumlahHalaman number not null,
    TahunTerbit varchar(4) not null,
    foreign key(ID_Kategori) references Kategori(ID_Kategori),
    foreign key (ID_Peminjaman) references Peminjaman(ID_Peminjaman),
    foreign key (ID_Pengembalian) references Pengembalian(ID_Pengembalian),
    foreign key (Kode_Penerbit) references Penerbit(Kode_Penerbit),
    foreign key (ID_Pengarang) references Pengarang(ID_Pengarang)
);

insert into Kepala values ('KPL001', 'Ratna', 'Perempuan', 'Jend Sudirman 26', to_date('02/11/1978' , 'mm/dd/yyyy'), '2506217');
insert into Kepala values ('KPL002', 'Suryadi', 'Laki-laki', 'HR Rasuna 3', to_date('04/04/1989' , 'mm/dd/yyyy'), '5203541');
insert into Kepala values ('KPL003', 'Indah', 'Perempuan', 'Ngagel Jaya Timur V', to_date('10/03/1984' , 'mm/dd/yyyy'), '5026127');
insert into Kepala values ('KPL004', 'Leony', 'Perempuan', 'D-4 Kebon Baru', to_date('10/30/1975' , 'mm/dd/yyyy'), '60621771');
insert into Kepala values ('KPL005', 'Bethari', 'Perempuan', 'Meherba Plaze 33', to_date('04/06/1977' , 'mm/dd/yyyy'), '9569971');
insert into Kepala values ('KPL006', 'Hermanto', 'Laki-laki', 'Orion 85', to_date('05/30/1976' , 'mm/dd/yyyy'), '4525462');
insert into Kepala values ('KPL007', 'Doddy', 'Laki-laki', 'Letjen Suprapto', to_date('02/05/1973' , 'mm/dd/yyyy'), '42900193');
insert into Kepala values ('KPL008', 'Liani', 'Perempuan', 'Danau Sunter 10', to_date('02/01/1979' , 'mm/dd/yyyy'), '6516126');
insert into Kepala values ('KPL009', 'Hartanti', 'Perempuan', 'Sentra Niaga 12', to_date('10/19/1978' , 'mm/dd/yyyy'), '88875075');
insert into Kepala values ('KPL010', 'Farida', 'Perempuan', 'JRasuna Said 1', to_date('02/21/1970' , 'mm/dd/yyyy'), '55754113');

insert into Petugas values('PTG001', 'KPL001', 'Leony', 'Perempuan', 'Jend Sudirman', to_date('12/24/1995' , 'mm/dd/yyyy'), '5154626', 'Senin');
insert into Petugas values('PTG004', 'KPL002', 'Cahaya', 'Perempuan', 'Brigj Sudirman 10', to_date('01/12/1998' , 'mm/dd/yyyy'), '51546321', 'Selasa');
insert into Petugas values('PTG005', 'KPL003', 'Utari', 'Perempuan', 'Raya Bekasi', to_date('03/12/1999' , 'mm/dd/yyyy'), '51765642', 'Kamis');
insert into Petugas values('PTG008', 'KPL004', 'Ratna', 'Perempuan', 'Industri Slt', to_date('03/13/1996' , 'mm/dd/yyyy'), '5151321', 'Jumat');
insert into Petugas values('PTG009', 'KPL005', 'Harta', 'Laki-laki', 'Central Java', to_date('11/05/1997' , 'mm/dd/yyyy'), '54321324', 'Kamis');
insert into Petugas values('PTG012', 'KPL006', 'Djaja', 'Laki-laki', 'Ir H Juanda', to_date('09/08/1998' , 'mm/dd/yyyy'), '87126371', 'Rabu');
insert into Petugas values('PTG013', 'KPL007', 'Slamet', 'Laki-laki', 'Shaheed T', to_date('05/26/1999' , 'mm/dd/yyyy'), '21381728', 'Sabtu');
insert into Petugas values('PTG016', 'KPL008', 'Inge', 'Perempuan', 'Buncit raya', to_date('07/02/1995' , 'mm/dd/yyyy'), '36173219', 'Selasa');
insert into Petugas values('PTG017', 'KPL009', 'Limijanti', 'Perempuan', 'Mangga Dua', to_date('10/23/1996' , 'mm/dd/yyyy'), '23217481', 'Senin');
insert into Petugas values('PTG020', 'KPL010', 'Susila', 'Laki-laki', 'Kepa Duri', to_date('11/12/1996' , 'mm/dd/yyyy'), '21371293', 'Kamis');

insert into Anggota values('ANG001', 'Wulan Ratu', to_date('12/13/1999', 'mm/dd/yyyy'), 'Rajamandala', '52900052', 'teknisi');
insert into Anggota values ('ANG002', 'Dwi Nirmala', to_date('08/09/1988', 'mm/dd/yyyy'), 'Elephant Road', '8617485', 'Arsitek');
insert into Anggota values ('ANG003', 'Sinta Sari', to_date('03/27/1989', 'mm/dd/yyyy'), 'Lingkar Mega', '57947797', 'Dokter');
insert into Anggota values ('ANG004', 'Ary Tri', to_date('12/21/1990', 'mm/dd/yyyy'), 'HR Muh', '54390245', 'musisi');
insert into Anggota values ('ANG005', 'Iman Handoko', to_date('03/25/2000', 'mm/dd/yyyy'), 'Samarinda Ilir', '240604', 'mahasiswa');

insert into Penerbit values('PNB001', 'The Critique', 'H Najihun  6', '7393685');
insert into Penerbit values('PNB002', 'PPM', 'Menteng raya 9', '2303247');
insert into Penerbit values('PNB003', 'Tanah Aksara', 'Sawo Raya 15', '4100989');
insert into Penerbit values('PNB004', 'EGC', 'Agung Timur 5', '6518178');
insert into Penerbit values('PNB005', 'Gema', 'Ir Djuanda 1', '770889');

insert into Kategori values('KTG001', 'Pelajaran', 'Rak 001-300', 'Indonesia');
insert into Kategori values('KTG002', 'Romance', 'Rak 301-380', 'Inggris');
insert into Kategori values('KTG003', 'Fantasi', 'Rak 381-430', 'Inggris');
insert into Kategori values('KTG004', 'Sci-fi' , 'Rak 431-460', 'Indonesia');
insert into Kategori values('KTG005', 'Misteri', 'Rak 461-500', 'Inggris');

insert into Pengarang values('PGR001','Farida', 'Letjen S', '5307267');
insert into Pengarang values('PGR002', 'Adi', 'Pentaran', '3142882');
insert into Pengarang values('PGR003', 'Benny', 'Bungas', '6534411');
insert into Pengarang values('PGR004', 'Ary', 'Pondok Karya', '68434434');
insert into Pengarang values('PGR005', 'Lestari', 'East side', '8151181');

insert into Peminjaman values('PMJ001',to_date('03/24/2018', 'mm/dd/yyyy'), 9, 3);
insert into Peminjaman values('PMJ002',to_date('02/25/2018', 'mm/dd/yyyy'), 5, 2);
insert into Peminjaman values('PMJ003',to_date('02/28/2018', 'mm/dd/yyyy'), 6, 1);
insert into Peminjaman values('PMJ004',to_date('02/27/2018', 'mm/dd/yyyy'), 5, 1);
insert into Peminjaman values('PMJ005',to_date('02/27/2018', 'mm/dd/yyyy'), 8, 3);
insert into Peminjaman values('PMJ006',to_date('02/26/2018', 'mm/dd/yyyy'), 4, 2);

insert into Pengembalian values('PGM001', 'PMJ001', to_date('03/02/2018', 'mm/dd/yyyy'), 3, null);
insert into Pengembalian values('PGM002', 'PMJ002', to_date('03/02/2018', 'mm/dd/yyyy'), 2, null);
insert into Pengembalian values('PGM003', 'PMJ003', to_date('04/02/2018', 'mm/dd/yyyy'), 1, '10.000');
insert into Pengembalian values('PGM004', 'PMJ004', to_date('01/02/2018', 'mm/dd/yyyy'), 1, '5.000');
insert into Pengembalian values('PGM005', 'PMJ005', to_date('02/02/2018', 'mm/dd/yyyy'), 3, null);

insert into Buku values('BK001', 'KTG001', null, null, 'PNB001', 'PGR001', 'C++', 200, '1999');
insert into Buku values('BK002', 'KTG003', 'PMJ001', 'PGM001','PNB005','PGR005', 'Homegoing', 213, '2001');
insert into Buku values('BK003', 'KTG005', null, null,'PNB003','PGR003', 'At the Cafe', 123, '2003');
insert into Buku values('BK004', 'KTG002', 'PMJ006', null,'PNB002','PGR002', 'Shirley Jack', 186, '2002');
insert into Buku values('BK005', 'KTG002', 'PMJ003', 'PGM001','PNB001', 'PGR005', 'The Seen', 245, '1998');
insert into Buku values('BK006', 'KTG003', null, null,'PNB004', 'PGR004', 'Underground', 175, '2000');
insert into Buku values('BK007', 'KTG004', null, null,'PNB002', 'PGR002', 'Strange Things', 134, '2004');
insert into Buku values('BK008', 'KTG004', 'PMJ002', null,'PNB003','PGR003', 'Imagine', 123, '2001');
insert into Buku values('BK009', 'KTG001', null, null,'PNB001','PGR001','Java', 231,'2001');
insert into Buku values('BK010', 'KTG001', null, null,'PNB002','PGR002', 'C#', 264,'2003');
insert into Buku values('BK011', 'KTG005', 'PMJ005', 'PGM005','PNB005','PGR005', 'Common', 198, '2002');
insert into Buku values('BK012', 'KTG003', 'PMJ004', 'PGM004','PNB004','PGR004', 'The Innocence', 234, '2004');

Tambah field
Alter table anggota add JenisKelamin varchar2(10);
Alter table buku add Jilid varchar(2);
Alter table pengembalian add DendaRusak varchar2(10);
Alter table anggota add email varchar2(20);

Ubah data
update Peminjaman set LamaPinjam = 7 where jumlahbuku = 3; (2 data)
update Peminjaman set jumlahbuku = 1 where lamapinjam = 4; (1 data)
update Peminjaman set LamaPinjam = 5 where ID_Peminjaman = 'PMJ002'; (1 data)
update Peminjaman set JumlahBuku = 3 where ID_Peminjaman = 'PMJ004'; (1 data)

update Pengembalian set dendarusak = '11.000' where ID_Pengembalian = 'PGM001'; (1 data)
update Pengembalian set dendarusak = '5.000' where jumlahbuku = 1; (2 data)
update Pengembalian set dendaketerlambatan = null where jumlahbuku = 1; (2 data)

Delete data
delete from petugas where Jenis_Kelamin = 'Laki-laki';(4 data)
delete from petugas where jadwaljaga = 'Jumat'; (1 data)
delete from kepala where tanggallahir <= to_date('12-30-1977', 'mm-dd-yyyy'); (5 data)