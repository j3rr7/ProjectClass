--Materi
--1
select duelist_id "ID", nama 
from duelist
where to_char(tanggal_lahir, 'YYYY') < 2001 and to_char(tanggal_lahir, 'YYYY') > 1997 and nama like '%en%'
order by nama;

--2
select card_id "Id", card_name "Nama Kartu", card_level "Level"
from card
where card_sub_type='Dragon' and card_attribute='Dark'
order by card_level, card_name;

--3
select m.kd_match "ID", d.nama "Nama 1", du.nama "Nama 2"
from match m, duelist d, locations l, duelist du
where m.location_id= l.location_id  and m.id_home=d.duelist_id and m.id_away=du.duelist_id and l.city='Los Angeles'
order by m.kd_match;

--4
select distinct m.kd_match "Id", d.nama "Nama Duelist"
from match m, duelist d, country c, locations l
where c.country_id=l.country_id and l.location_id=m.location_id and m.id_home=d.duelist_id and 
m.status='1' and c.country_name='Canada'
order by d.nama, m.kd_match;

--5
select due.nama "Pemberi", du.nama "Penerima", c.card_name "Nama Kartu"
from duelist due, duelist du, card c, d_barter d, h_barter h, rarity r
where r.rarity_id=c.rarity_id and h.kd_barter=d.kd_barter and c.card_id=d.card_id and du.duelist_id=d.duelist_id_take and due.duelist_id=d.duelist_id_give and to_char(h.tgl_barter, 'YYYY') > 2000
and r.rarity_id='Secret Rare';

--6
select distinct c.card_name "Nama Monster", c.atk "ATK", c.def "DEF", r.rarity_value "Value"
from card c, rarity r
where c.rarity_id = r.rarity_id and c.atk <= 2000 and c.atk >= 1000 and c.def >= 1000 and (c.rarity_id ='Rare' or c.rarity_id='Super Rare') and c.card_level = 4
order by r.rarity_value, c.atk, c.card_name;

--Tugas
--2 
select d.nama "NAMA", m.tgl_match "Tanggal", m.card_id "ID"
from duelist d, match m
where m.id_home=d.duelist_id and m.status='1' and d.gender = 'F' and to_char(m.tgl_match, 'yyyy') >= 2006 and to_char(m.tgl_match, 'yyyy') <= 2008
order by d.nama;

--3
select hb.tgl_barter "TANGGAL", c.card_name "NAMA KARTU", d.nama "PENGIRIM", du.nama "Penerima"
from h_barter hb, d_barter db, duelist d, duelist du, card c
where d.duelist_id = db.duelist_id_give and du.duelist_id = db.duelist_id_take and hb.kd_barter = db.kd_barter and c.card_id = db.card_id and to_char(hb.tgl_barter, 'MM') = 05
order by hb.tgl_barter, c.card_name;

--4
select distinct d.nama "NAMA", c.card_name "Kartu", co.country_name "Negara"
from duelist d, card c, country co, match m, locations l
where to_char(d.tanggal_lahir,'MM')=09 and m.location_id = l.location_id and l.country_id = co.country_id and m.id_home=d.duelist_id and m.status='1' and c.card_id = m.card_id
order by d.nama, co.country_name;

--5
select distinct d.nama "NAMA", (to_char(hb.tgl_barter,'yyyy') - to_char(d.tanggal_lahir, 'yyyy')) "UMUR", c.card_name "KARTU"
from duelist d, h_barter hb, card c, rarity r, d_barter db
where db.duelist_id_give = d.duelist_id and r.rarity_id = c.rarity_id and r.rarity_value > 10000 and (to_char(hb.tgl_barter,'yyyy') - to_char(d.tanggal_lahir, 'yyyy')) < 20 and db.card_id = c.card_id and hb.kd_barter = db.kd_barter;