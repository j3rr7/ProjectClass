--Materi
--no1
select l.city as "Kota"
from locations l
where l.location_id not in (select location_id from match)
order by 1;

--no2
select distinct card_name as "Nama Kartu"
from card 
where (atk >= (select avg(atk) from card) - 500) and (atk <= (select avg(atk) from card) + 500)
order by 1;

--no3
select d.nama, 
	case 
	when to_char(d.tanggal_lahir, 'yyyy') =(select max(to_char(tanggal_lahir, 'yyyy')) from duelist) then 'Duelist paling muda'
	when to_char(d.tanggal_lahir, 'yyyy') = (select min(to_char(tanggal_lahir, 'yyyy')) from duelist) then 'Duelist paling tua'
	else ''
	end as "Keterangan"
from duelist d
where d.duelist_id in (select id_away from match)
order by 1;

--no4
select*
from(
select distinct substr(d.nama, 1,1) || substr(d.nama, instr(d.nama, ' ')+1, 1) || (ascii(substr(d.nama, 1,1)) + ascii(substr(d.nama, instr(d.nama, ' ')+1, 1))) as "KODE_D", 
replace(replace(replace(replace(replace(d.nama,'a',''), 'i',''), 'u', ''), 'e', ''), 'o', '') as "NAMA",
to_char(m.tgl_match , 'yyyy') - to_char(d.tanggal_lahir, 'yyyy') || ' TAHUN' as "FIRST WIN AFTER",
case d.gender
when 'M' then 'MALE' 
when 'F' then 'FEMALE'
end as "JK",
case 
when to_char(d.tanggal_lahir, 'yyyy') =(select max(to_char(tanggal_lahir, 'yyyy')) from duelist) then 'TERMUDA'
when to_char(d.tanggal_lahir, 'yyyy') = (select min(to_char(tanggal_lahir, 'yyyy')) from duelist) then 'TERTUA'
else 'BUKAN KEDUANYA'
end as "STATUS",
case 
when m.status = 1 and d.duelist_id = m.id_home then 'DUEL HOME'
when m.status = 0 and d.duelist_id = m.id_away then 'DUEL AWAY'
end as "MATCH"
from duelist d, match m
where (d.duelist_id = m.id_home or d.duelist_id = m.id_away) and d.nama in (select nama
	from (
	select distinct d.nama "NAMA", to_char(m.tgl_match , 'yyyy') - to_char(d.tanggal_lahir, 'yyyy') as "UMUR"
	from match m, duelist d
	where (m.status = 1 and d.duelist_id = m.id_home) or (m.status = 0 and d.duelist_id = m.id_away)
	order by 2)
	where rownum <= 2)
order by  3)
where rownum <= 2
order by 1;
	
--Tugas
--no1
select distinct case r.region_name 
	when home then rpad(upper(home), (select length(region_name) from region where length(region_name) = (select max(length(region_name)) from region))) || ' HOME MENDAPATKAN KEUNTUNGAN ' || jumlah1
	when belumpernah then upper(belumpernah) || ' BELUM PERNAH MELAKUKAN MATCH'
	end as "Keterangan"
from (select r.region_name as "HOME", sum(ra.rarity_value) as "JUMLAH1"
	from match m, locations l, country c, region r, rarity ra , card ca
	where m.status = 1 and m.location_id = l.location_id and l.country_id = c.country_id and c.region_id = r.region_id and m.card_id = ca.card_id and ca.rarity_id = ra.rarity_id group by r.region_name) r1,
	(select r.region_name as "BELUMPERNAH"
	from region r
	where r.region_name not in(select r.region_name
	from match m, locations l, country c, region r, rarity ra
	where m.status = 0 and m.location_id = l.location_id and l.country_id = c.country_id and c.region_id = r.region_id 
	group by r.region_name)) r2, region r
where r.region_name = home or r.region_name = belumpernah
order by 1 desc;

--no2
select case 
	when instr(c.card_type, ' ') = 0 then rpad(c.card_type, (select max(instr(card_type, ' ')) from card)) || lpad('Card', (select max(instr(card_type, ' ')) from card ))
	else c.card_type
	end || ' ' || sum(r.rarity_value) as "Keterangan"
from card c, rarity r, match m
where m.card_id = c.card_id and c.rarity_id = r.rarity_id and 
	c.card_id not in (select c.card_id from card c, d_barter db where c.card_id = db.card_id)
group by c.card_type
order by 1 desc;

--no3
select rpad(d.nama, (select max(length(nama)) from duelist)) || ' ->  ' || 
	(case 
	when d.nama not in (select d.nama from duelist d, d_barter db where (db.duelist_id_give = d.duelist_id or db.duelist_id_take = d.duelist_id)) then 'TIDAK MENGALAMI PERUBAHAN DENGAN TIDAK UNTUNG/RUGI'
	else ((case
	when count(case when db.duelist_id_take = d.duelist_id then 1 end) > count(case when db.duelist_id_give = d.duelist_id then 1 end) then 'KARTU BERTAMBAH 1 DENGAN '
	when count(case when db.duelist_id_take = d.duelist_id then 1 end) < count(case when db.duelist_id_give = d.duelist_id then 1 end) then 'KARTU BERKURANG 1 DENGAN '
	when count(case when db.duelist_id_take = d.duelist_id then 1 end) = count(case when db.duelist_id_give = d.duelist_id then 1 end) then 'TIDAK MENGALAMI PERUBAHAN DENGAN '
	end)||
	(case 
	when count(case when db.duelist_id_take = d.duelist_id then 1 end) > 0 and count(case when db.duelist_id_give = d.duelist_id then 1 end) = 0 then 'KEUNTUNGAN ' || sum(case when db.duelist_id_take = d.duelist_id then r.rarity_value end)
	when count(case when db.duelist_id_take = d.duelist_id then 1 end) = 0 and count(case when db.duelist_id_give = d.duelist_id then 1 end) > 0 then 'KERUGIAN ' || sum(case when db.duelist_id_give = d.duelist_id then r.rarity_value end)
	end) ||
	(case
	when sum(case when db.duelist_id_take = d.duelist_id then r.rarity_value end) > sum(case when db.duelist_id_give = d.duelist_id then r.rarity_value end) then 'KEUNTUNGAN ' || (sum(case when db.duelist_id_take = d.duelist_id then r.rarity_value end) - sum(case when db.duelist_id_give = d.duelist_id then r.rarity_value end))
	when sum(case when db.duelist_id_take = d.duelist_id then r.rarity_value end) < sum(case when db.duelist_id_give = d.duelist_id then r.rarity_value end) then 'KERUGIAN ' || (sum(case when db.duelist_id_give = d.duelist_id then r.rarity_value end) - sum(case when db.duelist_id_take = d.duelist_id then r.rarity_value end))
	when sum(case when db.duelist_id_take = d.duelist_id then r.rarity_value end) = sum(case when db.duelist_id_give = d.duelist_id then r.rarity_value end) then 'KERUGIAN 0'
	end)
	)end) as "PERUBAHAN KARTU DAN KERUGIAN"
from duelist d, d_barter db, card c, rarity r
where c.card_id = db.card_id and r.rarity_id = c.rarity_id
group by d.nama
order by (length(d.nama)) desc, (case length(d.nama) when 16 then d.nama when 15 then d.nama end) asc, (case when length(d.nama)!= 16 then d.nama when length(d.nama)!= 15 then d.nama end) desc;

--no4
select lpad(c.card_name, (select max(length(card_name)) from card where card_id not in (select c.card_id from card c, match m where m.status = 1 and m.card_id = c.card_id))) ||
case c.atk 
	when (select atk as "MAX_ATK" from card where atk = (select max(atk) from card where card_id not in (select c.card_id from card c, match m where m.status = 1 and m.card_id = c.card_id))) then ' MAX ATK==>' || c.atk when (select atk as "MIN_ATK" from card where atk = (select min(atk) from card where card_id not in (select c.card_id from card c, match m where m.status = 1 and m.card_id = c.card_id))) then ' MIN ATK=>' || c.atk else '' end ||
case c.def 
	when (select def as "MAX_DEF" from card 
		where def = (select max(def) from card where card_id not in (select c.card_id from card c, match m where m.status = 1 and m.card_id = c.card_id))) then ' MAX DEF==>' || c.def 
	when (select def as "MIN_DEF" from card 
		where def = (select min(def) from card where card_id not in (select c.card_id from card c, match m where m.status = 1 and m.card_id = c.card_id))) then ' MIN DEF=>' || c.def else '' end ||
case c.card_level 
	when (select distinct card_level as "MAX_LVL" from card 
		where card_level = (select max(card_level) from card where card_id not in (select c.card_id from card c, match m where m.status = 1 and m.card_id = c.card_id))) then ' MAX LEVEL=>' || c.card_level 
	when (select distinct card_level as "MIN_LVL" from card 
		where card_level = (select min(card_level) from card where card_id not in (select c.card_id from card c, match m where m.status = 1 and m.card_id = c.card_id))) then ' MIN LEVEL=>' || c.card_level else '' end
as "PENGHARGAAN"
from card c
where c.card_id not in (select c.card_id from card c, match m where m.status = 1 and m.card_id = c.card_id)
order by lpad(c.card_name, (select max(length(card_name)) from card where card_id not in (select c.card_id from card c, match m where m.status = 1 and m.card_id = c.card_id))) desc;