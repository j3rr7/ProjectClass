--not in
--menampilkan player yang tidak pernah ditransfer
select*
from player
where kd_player not in (select kd_player from transfer);

--in 
--menampilkan player yang pernah ditransfer
select* 
from player
where kd_player in (select kd_player from transfer);

--where kdplayer in ('' , '')

--exists
--menampilkan team yang memiliki manager yang pernah bertanding hmatch sebagai home_away
select*
from team t
where exists (select* from manager m, hmatch h, team t where t.kd_manager = m.kd_manager and h.home_club = t.kd_team);

--not exists
--menampilkan team yang memiliki manager yang tidak pernah bertanding hmatch sebagai home_away
select*
from team t
where not exists (select* from manager m, hmatch h, team t where t.kd_manager = m.kd_manager and h.home_club = t.kd_team);

--minus
--menampilkan player yang tidak pernah mencetak goal dan tidak pernah mendapat kartu kuning
select p.kd_player, p.nama_player
from player p
minus
select p.kd_player, p.nama_player
from player p, dmatch_card dc, dmatch_goal dg
where p.kd_player = dg.kd_player and p.kd_player = dc.kd_player and dc.kartu = 'K' and dc.kd_player = dg.kd_player;

--subquery
--di select
--jumlah goal setiap pemain
select p.nama_player, (
	select count(*)
	from dmatch_goal d
	where p.kd_player = d.kd_player) as "TOTAL_GOAL"
from player p;

--di from
--2 gaji terbesar
select*
from (
	select *
	from contract
	order by gaji_pl desc)
where rownum <= 2;

--di where
--gaju terbesar ke 2 saja
select p.kd_player, p.nama_player
from player p, contract c
where p.kd_player = c.kd_player and 
c.gaji_pl = (
	select min(gaji_pl)
	from
	(select gaji_pl
	from contract
	order by gaji_pl desc)
	where rownum <= 2
);