--1 (BELUM)
create table PROMO(
	PROMOCODE VARCHAR2(5) PRIMARY KEY,
	STARTDATE DATE NOT NULL,
	ENDDATE DATE NOT NULL,
	DISCOUNT NUMBER(3) CHECK(DISCOUNT >= 1 AND DISCOUNT <= 100)
);

--2
ALTER TABLE CUSTOMER
MODIFY (ADDRESS VARCHAR(30));

--3
ALTER TABLE PROMO RENAME COLUMN ENDDATE TO FINISHDATE;

--4
INSERT INTO PROMO VALUES ('PR001', TO_DATE('01-05-2018', 'DD-MM-YYYY'), TO_DATE('31-05-2018', 'DD-MM-YYYY'), 50);

--5
SELECT CUSTCODE AS "CODE", rpad(NAME,21) "NAME", rpad(ADDRESS,17) "ADDRESS" 
FROM CUSTOMER
WHERE SUBSTR(ADDRESS, INSTR(ADDRESS, ' ')+1) = 'SURABAYA';

--6
SELECT rpad(C.NAME,19) as "Customer Name", H.TRANSCODE as "KodeTran", rpad(rpad('Rp.',4) || H.TOTAL, 11)  as "Tagihan"
FROM CUSTOMER C, HTRANS H
WHERE C.CUSTCODE = H.CUSTCODE;

--7
select rpad(case gender 
	when 'F' then 'Sdri. '
	when 'M' then 'Sdra. '
	end || initcap(name) || ' mempunyai keahlian ' ||
	case specialist
	when 'HC' then 'hair cut'
	when 'CR' then 'creambath'
	when 'SM' then 'smoothing'
	when 'BL' then 'blow'
	end, 41)
	as "Keterangan Karyawan"
from employee
order by 1;

--8
select rpad(initcap(to_char(ht.transdate , 'mon dd, yyyy')),12) "TANGGALTRANS", rpad(initcap(c.name),14) "CUSTOMER", 
rpad(case dt.servicecode
	when 'HC' then 'Hair Cut'
	when 'CR' then 'Creambath'
	when 'SM' then 'Smoothing'
	when 'BL' then 'Blow'
	end, 9) as "PERAWATAN",
	lpad(initcap(e.name), 8) as "EMPLOYEE", rpad(rpad('Rp.', 4) || dt.price || ',-',12 ) "BIAYA" 
from customer c, htrans ht, dtrans dt, employee e
where ht.transcode = dt.transcode and dt.empcode = e.empcode and ht.custcode = c.custcode
order by 2 desc, 3 asc;

--9
select rpad(rpad('Rp.', 4) || (sum(total)/1000) || '.'|| decode(mod(sum(total),1000), 0, '000') || ',-',16) "Pendapatan" 
from htrans;

--10
select upper(name) as "NAME",rpad('Rp.', 4) || lpad((price/1000),3) || '.'|| decode(mod(price,1000), 0, '000') "HARGA"
from services
order by 2;

--11
select initcap(s.name) "Perawatan", rpad(count(*) || ' orang',14) as "Jml Employee"
from services s, employee e
where e.specialist = s.servicecode
group by s.name
order by 1;

--12
select custcode "CODE", rpad(name,27) "NAME"
from customer
where custcode not in (select custcode from htrans)
order by 1 desc;

--13
select e.empcode "CODE", rpad(e.name,15) "Employee Name", lpad(count(dt.transcode) || ' times', 10) as "Serve Time"
from employee e
left join dtrans dt on dt.empcode = e.empcode
group by e.empcode, e.name
order by 2;

--14
select rpad(lower(substr(s.name,1,1)) || upper(substr(s.name,2)),12) as "Service Name"
from services s, employee e
where e.specialist = s.servicecode
having count(e.empcode) >1
group by s.name
order by 1;

--15
select rpad(initcap(c.name),30) as "Customer Name", count(dihitung) as "Jenis Service"
from customer c, (select distinct ht.custcode "CODE", dt.		servicecode "DIHITUNG"
	from dtrans dt, htrans ht where ht.transcode = dt.transcode)
where code = c.custcode
group by c.name;
