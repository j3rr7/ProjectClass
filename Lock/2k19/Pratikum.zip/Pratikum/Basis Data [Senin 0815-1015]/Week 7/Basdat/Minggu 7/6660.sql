--materi
--no1
((select m.id_home "DUELIST", d.nama "NAMA"
from match m, duelist d
where m.id_home = d.duelist_id)
union
(select m.id_away, d.nama
from match m, duelist d
where m.id_away = d.duelist_id))
intersect
((select db.duelist_id_give, d.nama
from d_barter db, duelist d
where db.duelist_id_give = d.duelist_id)
union 
(select db.duelist_id_take, d.nama
from d_barter db, duelist d
where db.duelist_id_take = d.duelist_id));

--no2
select d.nama "NAMA", sum(r.rarity_value) "Total Value"
from d_barter db, duelist d, card c, rarity r
where db.duelist_id_take = d.duelist_id and db.card_id = c.card_id and c.rarity_id = r.rarity_id
having sum(r.rarity_value) > 5000
group by d.nama;

--no3
(select card_name "Nama Kartu", atk "ATK", def "DEF"
from card 
where atk > (select avg(atk) from card) and rarity_id = 'Ultra Rare')
intersect
(select c.card_name, c.atk, c.def
from card c, d_barter db
where c.atk > (select avg(c.atk) from card c, d_barter db where c.card_id = db.card_id )and c.card_id = db.card_id and rarity_id = 'Ultra Rare');

--no4
(select d.nama "NAMA", (to_char(sysdate,'yyyy') - to_char(d.tanggal_lahir, 'yyyy'))"USIA"
from duelist d, h_barter hb, d_barter db
where (to_char(hb.tgl_barter, 'mm') >= 1 and to_char(hb.tgl_barter, 'mm') <= 3) and db.kd_barter = hb.kd_barter and (db.duelist_id_give = d.duelist_id or db.duelist_id_take = d.duelist_id)) 
intersect
(select d.nama, (to_char(sysdate,'yyyy') - to_char(d.tanggal_lahir, 'yyyy')) "USIA"
from duelist d, h_barter hb, match m, d_barter db
where (to_char(sysdate,'yyyy') - to_char(d.tanggal_lahir, 'yyyy')) = ( select min(to_char(sysdate,'yyyy') - to_char(d.tanggal_lahir, 'yyyy')) from duelist d, h_barter hb, d_barter db where (to_char(hb.tgl_barter, 'mm') >= 1 and to_char(hb.tgl_barter, 'mm') <= 3) and db.kd_barter = hb.kd_barter and (db.duelist_id_give = d.duelist_id or db.duelist_id_take = d.duelist_id)));

--Tugas
--no2
create view INSIDE_VALUE as 
select d.nama "NAMA", sum(r.rarity_value) "TOTAL VALUE"
from duelist d, d_barter db, card c, rarity r
where db.duelist_id_give = d.duelist_id and db.card_id = c.card_id and r.rarity_id = c.rarity_id
having sum(r.rarity_value) != (select min(r.rarity_value) from rarity r, d_barter db, card c where db.card_id = c.card_id and c.rarity_id = r.rarity_id) and sum(r.rarity_value) != (select max(r.rarity_value) from rarity r, d_barter db, card c where db.card_id = c.card_id and c.rarity_id = r.rarity_id)
group by d.nama
order by (case sum(r.rarity_value) when 1100 then 1 when 10100 then 2 else 3 end);

select* from inside_value;

--no3
select* from (select d.nama "NAMA", sum(r.rarity_value) "TOTAL VALUE"
from duelist d, d_barter db, card c, rarity r
where db.duelist_id_give = d.duelist_id and db.card_id = c.card_id and r.rarity_id = c.rarity_id
group by d.nama
minus 
select* from inside_value)
union all
select* from inside_value;

--no4
select d.nama "NAMA", (to_char(sysdate, 'yyyy') - to_char(d.tanggal_lahir, 'yyyy')) "USIA", length(d.nama) "CHAR" 
from duelist d, (select d.nama "NAMA", sum(r.rarity_value) "TOTAL VALUE"
	from duelist d, d_barter db, card c, rarity r
	where db.duelist_id_give = d.duelist_id and db.card_id = c.card_id and r.rarity_id = c.rarity_id
	group by d.nama
	intersect
	select* from inside_value) t
where d.nama = t.nama
order by (case 
	when mod((to_char(sysdate, 'yyyy') - to_char(d.tanggal_lahir, 'yyyy')),2) = 1 then
		case when mod((length(d.nama)),2) = 1 then 1 else 2 end
	else (case when mod((length(d.nama)),2) = 1 then 3 else 4 end) end), 2 desc;
	
--no 5
create view DAFTAR_BERI as
select d.nama "NAMA_BERI", sum(r.rarity_value) "VALUE_BERI", count(*) "JUMLAH_BERI"
from duelist d, d_barter db, card c, rarity r
where db.duelist_id_give = d.duelist_id and c.card_id = db.card_id and r.rarity_id = c.rarity_id
group by d.nama;

create view DAFTAR_DAPAT as
select d.nama "NAMA_DAPAT", sum(r.rarity_value) "VALUE_DAPAT", count(*) "JUMLAH_DAPAT"
from duelist d, d_barter db, card c, rarity r
where db.duelist_id_take = d.duelist_id and c.card_id = db.card_id and r.rarity_id = c.rarity_id
group by d.nama;

create view PROFIT as
select distinct rpad(d.nama, (select max(length(nama)) from duelist)) || 'mendapatkan ' || jumlah_dapat || ' kartu dan memberikan ' || case d.nama
	when (select* from (select nama_dapat from daftar_dapat minus select nama_beri from daftar_beri order by 1) where rownum <=1) then '0 kartu  PROFIT = ' || lpad(value_dapat,6)
	when (select* from (select nama_dapat from daftar_dapat minus select nama_beri from daftar_beri order by 1 desc) where rownum <=1) then '0 kartu  PROFIT = ' || lpad(value_dapat,6)
	else to_char(jumlah_beri) || ' kartu  PROFIT = ' || lpad(value_dapat-value_beri,6)
	end "ISI_PROFIT"
from daftar_beri, daftar_dapat, duelist d
where (d.nama = nama_dapat and d.nama = nama_beri and (value_dapat - value_beri) > 0) or (d.nama in (select nama_dapat from daftar_dapat minus select nama_beri from daftar_beri) and d.nama = nama_dapat and nama_dapat in (select nama_dapat from daftar_dapat minus select nama_beri from daftar_beri))
order by (substr(isi_profit,-5)) desc;
	
create view LOSS as 
select distinct rpad(d.nama, (select max(length(nama)) from duelist)) || case d.nama
	when (select* from (select nama_beri from daftar_beri minus select nama_dapat from daftar_dapat order by 1) where rownum <=1) then 'mendapatkan 0 kartu dan memberikan ' || jumlah_beri || ' kartu    LOSS = -' || lpad(value_beri,5)
	when (select* from (select nama_beri from daftar_beri minus select nama_dapat from daftar_dapat order by 1 desc) where rownum <=1) then 'mendapatkan 0 kartu dan memberikan ' || jumlah_beri || ' kartu    LOSS = -' || lpad(value_beri,5)
	else 'mendapatkan ' || jumlah_dapat || ' kartu dan memberikan ' || jumlah_beri ||  ' kartu    LOSS = -' || lpad(value_beri-value_dapat,5)
	end "ISI_LOSS"
from daftar_beri, daftar_dapat, duelist d
where (d.nama = nama_beri and d.nama = nama_dapat and (value_dapat - value_beri) < 0) or (d.nama in (select nama_beri from daftar_beri minus select nama_dapat from daftar_dapat) and d.nama = nama_beri and nama_beri in (select nama_beri from daftar_beri minus select nama_dapat from daftar_dapat))
order by (substr(isi_loss,-5)) desc;

select* from loss
union all
select* from profit;