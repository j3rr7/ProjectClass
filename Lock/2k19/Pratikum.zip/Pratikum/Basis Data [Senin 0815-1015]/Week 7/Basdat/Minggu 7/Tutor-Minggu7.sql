-- UNION : Mengeliminasi yang sama
-- Menampilkan Pemain yang pernah mendapat kuning dan Pemain yang pernah mencetak goal dengan cara 'L'
SELECT P.NAMA_PLAYER
FROM PLAYER P, DMATCH_CARD D
WHERE P.KD_PLAYER = D.KD_PLAYER and D.KARTU = 'K'
UNION
SELECT P.NAMA_PLAYER
FROM PLAYER P, DMATCH_GOAL D
WHERE P.KD_PLAYER = D.KD_PLAYER and D.CARA = 'L';

-- UNION ALL : Tidak mengeliminasi yang sama
-- Menampilkan Pemain yang pernah mendapat kuning dan Pemain yang pernah mencetak goal dengan cara 'L'
SELECT P.NAMA_PLAYER
FROM PLAYER P, DMATCH_CARD D
WHERE P.KD_PLAYER = D.KD_PLAYER and D.KARTU = 'K'
UNION ALL
SELECT P.NAMA_PLAYER
FROM PLAYER P, DMATCH_GOAL D
WHERE P.KD_PLAYER = D.KD_PLAYER and D.CARA = 'L';

-- INTERSECT : Kebalikan dari Minus(Minggu lalu)
-- 
SELECT P.KD_PLAYER,P.NAMA_PLAYER
FROM PLAYER P 
INTERSECT
SELECT P.KD_PLAYER,P.NAMA_PLAYER
FROM PLAYER P, DMATCH_CARD DC, DMATCH_GOAL DG
WHERE P.KD_PLAYER = DG.KD_PLAYER AND P.KD_PLAYER = DC.KD_PLAYER AND DC.KARTU = 'K' AND DC.KD_PLAYER = DG.KD_PLAYER;


-- HAVING COUNT
-- Tampilkan nama player yang pernah mencetak goal lebih dari 3
SELECT P.NAMA_PLAYER
FROM PLAYER P, DMATCH_GOAL D
WHERE P.KD_PLAYER = D.KD_PLAYER
GROUP BY D.KD_PLAYER, P.NAMA_PLAYER
HAVING COUNT(D.KD_PLAYER) > 3;

