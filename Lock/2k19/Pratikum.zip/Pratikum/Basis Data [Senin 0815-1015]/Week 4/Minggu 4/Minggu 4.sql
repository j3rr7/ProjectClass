--No 1
select 'Di ' || rpad(substr(r.region_name, 1, length(r.region_name)-1) || upper(substr(r.region_name, -1, 1)), 8,' ')  || ' Telah Terjadi ' || count(m.kd_match) || ' Match' as "Region Match"
from match m, locations l, country c, region r
where m.location_id = l.location_id 
	and l.country_id = c.country_id 
	and c.region_id = r.region_id
group by r.region_name
order by count(m.kd_match) desc;

--No 2
select rpad(upper(substr(d.nama, instr(d.nama, ' ', 1) + 1)), 9, ' ') || ' TELAH MEMBERIKAN DAN MENERIMA KARTU SEBANYAK ' || (count(db.kd_barter) ) || ' KARTU'  as "BARTER"
from duelist d, d_barter db
where d.duelist_id = db.duelist_id_give 
	or d.duelist_id = db.duelist_id_take
group by d.nama
order by (count(db.duelist_id_give) + count(db.duelist_id_take)) desc, d.nama;

--No 3 
select rpad(upper(substr(d.nama, 1, instr(d.nama, ' ', 1)-1)), 9,' ') || ' MENDAPATKAN ' || (count(db.card_id)/15) || ' KARTU ' || rpad(upper(c.rarity_id), 11, ' ') || ' DENGAN TOTAL VALUE ' || lpad(nullif(floor(count(db.card_id)/15 * r.rarity_value/1000),0) || ','|| rpad(mod((count(db.card_id)/15 * r.rarity_value),1000),3, '0'), 7) as "DUELIST GET CARD VALUE"
from duelist d, d_barter db, card c, rarity r, duelist du
where db.duelist_id_take = d.duelist_id 
	and db.card_id = c.card_id 
	and c.rarity_id = r.rarity_id
group by d.nama, c.rarity_id, r.rarity_value
order by c.rarity_id, floor(count(db.card_id)/15 * r.rarity_value/1000) desc, d.nama;


--No 4 
select rpad(substr(d.nama, 1, instr(d.nama, ' ', 1)-2) || initcap(substr(d.nama,instr(d.nama, ' ', 1)-1, (length(substr(d.nama, instr(d.nama, ' ', 1) + 1))+1))) || upper(substr(d.nama, -1,1)),15 )  || ' Telah Memenangkan kartu Bertype ' || c.card_attribute || ' Sebanyak ' || count(d.duelist_id) || ' Kali' as "LOOT DUELIST"
from duelist d, card c, match m
where ((d.duelist_id = m.id_home and m.status = 1) 
	or (d.duelist_id = m.id_away and m.status = 0)) 
	and m.card_id = c.card_id
group by c.card_attribute, d.nama
order by count(m.id_away) desc, d.nama, c.card_attribute;

--No 5
select rpad(d.nama, 16) || ' Mengalami Profit/Loss Sebesar ' ||  rpad((sum(r2.rarity_value) - sum(r.rarity_value)) || ',' , 10, '0')  as "CARD VALUE PROFIT/LOSS"
from duelist d, d_barter db,d_barter db2, card c, card c2, rarity r, rarity r2 
where d.duelist_id = db.duelist_id_take 
	and c2.card_id = db.card_id
	and r2.rarity_id = c2.rarity_id
	and d.duelist_id = db2.duelist_id_give 
	and c.card_id = db2.card_id 
	and r.rarity_id = c.rarity_id 
group by d.nama
order by (sum(r2.rarity_value) - sum(r.rarity_value)) desc;