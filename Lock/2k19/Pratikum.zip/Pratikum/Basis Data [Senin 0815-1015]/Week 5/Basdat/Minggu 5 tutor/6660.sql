--Materi
--no1
select d.nama as "Duelist", count(db.kd_barter) || ' kali' as "Jumlah Barter"
from duelist d
left join d_barter db on db.duelist_id_give = d.duelist_id
group by d.nama
order by 2 desc, 1;

--no2
select d.nama as "Nama Duelist", 'Memenangkan match sebanyak 0' || (count(m.kd_match)) as "Jumlah Menang"
from duelist d
left join match m on ((m.id_home = d.duelist_id and m.status = 1) or (m.id_away = d.duelist_id and m.status = 0))
group by d.nama
order by 2 desc, 1;

--no3
select m.kd_match as "ID MATCH", d.nama as "NAMA", d2.nama as "Nama", 
	case m.status
	when '1' then to_char(d.nama)
	when '0' then to_char(d2.nama)
	end as "Pemenang"
from match m
inner join duelist d2 on m.id_away = d2.duelist_id 
inner join duelist d on m.id_home = d.duelist_id
order by 1;

--no4
select 
	'Tanpa Level = 0' || count(case when card_level is null then 1 end) || chr(10) ||
	'Level 1-3 = 0' || count(case when card_level < 4 then 1 end) || chr(10) ||
	'Level 4-6 = 0' || count(case when card_level < 7 and card_level > 3 then 1 end ) || chr(10) || 'Level 7-10 = 0' || count(case when card_level > 6 then 1 end)
	as "Level dan banyak kartu"
from card c;

--Tugas 
--no2
select 'Duelist laki laki berjumlah ' || (count(case gender when 'M' then 1 end)) || ' sedangkan duelist wanita berjumlah ' || (count(case gender when 'F' then 1 end)) as "Jumlah Gender"
from duelist;

--no3 
select rpad(d.nama, 20) || 
	case (count(case when db.duelist_id_take = d.duelist_id then 1 end) + count(case when db.duelist_id_give = d.duelist_id then 1 end))
	when 0 then 'mendapatkan nothing karena tidak melakukan barter'
	else 'mendapatkan ' || count(case when db.duelist_id_take = d.duelist_id then 1 end) || ' dan memberikan ' || count(case when db.duelist_id_give = d.duelist_id then 1 end) || ' kartu ' ||
	lpad(case
	when count(case when db.duelist_id_take = d.duelist_id then 1 end) > 0 and count(case when db.duelist_id_give = d.duelist_id then 1 end) = 0 then 'PROFIT = ' || lpad(sum(case when db.duelist_id_take = d.duelist_id then r.rarity_value end),6)
	when count(case when db.duelist_id_take = d.duelist_id then 1 end) = 0 and count(case when db.duelist_id_give = d.duelist_id then 1 end) > 0 then 'LOSS = -' || lpad(sum(case when db.duelist_id_give = d.duelist_id then r.rarity_value end),5)
	when (sum(case when db.duelist_id_take = d.duelist_id then r.rarity_value end) - sum(case when db.duelist_id_give = d.duelist_id then r.rarity_value end)) >= 0 then 'PROFIT = ' || lpad(sum(case when db.duelist_id_take = d.duelist_id then r.rarity_value end) - sum(case when db.duelist_id_give = d.duelist_id then r.rarity_value end),6)
	else 'LOSS = -' || lpad((sum(case when db.duelist_id_take = d.duelist_id then r.rarity_value end) - sum(case when db.duelist_id_give = d.duelist_id then r.rarity_value end))*-1,5)
	end , 16)
	end as "Summary Barter"
from duelist d
left join d_barter db on (db.duelist_id_give = d.duelist_id or db.duelist_id_take = d.duelist_id)
left join card c on c.card_id = db.card_id
left join rarity r on r.rarity_id = c.rarity_id
group by d.nama
order by 1;

--no4 
select lpad(d.nama, 20) || 
	case count(c.card_id)
	when 0 then ' tidak get'
	else ' get ' ||
		case c.card_sub_type
		when 'Normal' then rpad(substr(c.card_type,1, (length(c.card_type)-1))|| upper(substr(c.card_type,-1,1)),6) || '    CarD'
		else substr(c.card_type, 1, instr(c.card_type, ' ')-2) || initcap(substr(c.card_type, instr(c.card_type, ' ')-1,8)) || upper(substr(c.card_type,-1,1))
		end
		||' sebanyak ' || count(m.kd_match) || ' TOTAL VALUE ' || 
		lpad(case 
		when sum(rarity_value) >= 1000 then floor(sum(rarity_value) / 1000) || ',' || 
			case 
			when mod(sum(rarity_value),1000) >= 100 then rpad(mod(sum(rarity_value),1000),3, '0')
			else rpad(lpad(mod(sum(rarity_value),1000),3,'0'),3,'0')
			end
		else lpad(sum(r.rarity_value),7)
		end , 8)
	end as "Get Kartu"
from duelist d
left join match m on (m.id_home = d.duelist_id and m.status = '1') or (m.id_away = d.duelist_id and m.status = '0')
left join card c on c.card_id = m.card_id
left join rarity r on r.rarity_id = c.rarity_id
group by d.nama, c.card_type,
	case c.card_sub_type
		when 'Normal' then rpad(substr(c.card_type,1, (length(c.card_type)-1))|| upper(substr(c.card_type,-1,1)),6) || '    CarD'
		else substr(c.card_type, 1, instr(c.card_type, ' ')-2) || initcap(substr(c.card_type, instr(c.card_type, ' ')-1,8)) || upper(substr(c.card_type,-1,1))
	end
order by d.nama desc, 
	(case c.card_sub_type
	when 'Normal' then rpad(substr(c.card_type,1, (length(c.card_type)-1))|| upper(substr(c.card_type,-1,1)),6) || '    CarD'
	else substr(c.card_type, 1, instr(c.card_type, ' ')-2) || initcap(substr(c.card_type, instr(c.card_type, ' ')-1,8)) || upper(substr(c.card_type,-1,1))
	end);

--no5
select'Kartu bertype ' ||
	case c.card_sub_type
		when 'Normal' then rpad(substr(c.card_type,1, (length(c.card_type)-1))|| upper(substr(c.card_type,-1,1)),6) || '    CarD'
		else substr(c.card_type, 1, instr(c.card_type, ' ')-2) || initcap(substr(c.card_type, instr(c.card_type, ' ')-1,8)) || upper(substr(c.card_type,-1,1))
	end ||
	case 
	when m.status = '1' then ' dimenangi home sebanyak ' || count(m.card_id) || ' dengan value ' ||
	lpad(case
	when floor(sum(r.rarity_value)/1000) > 0 then floor(sum(r.rarity_value)/1000) || ',' || lpad(rpad(mod(sum(r.rarity_value), 1000),3, '0'), 3, '0')
	else to_char(sum(r.rarity_value))
	end, 7)
	when m.status = '0' then ' dimenangi away sebanyak ' || count(m.card_id) || ' dengan value ' || 
	lpad(case
	when floor(sum(r.rarity_value)/1000) > 0 then floor(sum(r.rarity_value)/1000) || ',' || lpad(rpad(mod(sum(r.rarity_value), 1000),3, '0'), 3, '0')
	else to_char(sum(r.rarity_value))
	end, 7)
	else ' belum di match sebanyak ' || count(c.card_id)
	end as "Card In Match"
from card c
left join match m on (m.card_id = c.card_id and m.status = '1') or (m.card_id = c.card_id and m.status = '0')
left join rarity r on r.rarity_id = c.rarity_id
left join rarity r2 on r2.rarity_id = c.rarity_id
group by  m.status, c.card_type,
	case c.card_sub_type
		when 'Normal' then rpad(substr(c.card_type,1, (length(c.card_type)-1))|| upper(substr(c.card_type,-1,1)),6) || '    CarD'
		else substr(c.card_type, 1, instr(c.card_type, ' ')-2) || initcap(substr(c.card_type, instr(c.card_type, ' ')-1,8)) || upper(substr(c.card_type,-1,1))
	end 
order by c.card_type, 1;