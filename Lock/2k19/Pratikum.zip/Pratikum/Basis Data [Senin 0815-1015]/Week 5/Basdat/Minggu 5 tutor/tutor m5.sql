--Menampilkan klub dan managernya (manager tidak memiliki klub tidak ditampilkan)
SELECT T.NAMA_TEAM AS "Nama Tim",M.NAMA_MANAGER AS "Nama Manager"
FROM TEAM T
LEFT JOIN MANAGER M ON M.KD_MANAGER = T.KD_MANAGER;

--Menampilkan manager dan klubnya termasuk yang tidak ada klub 
SELECT T.NAMA_TEAM AS "Nama Tim",M.NAMA_MANAGER AS "Nama Manager"
FROM TEAM T
RIGHT JOIN MANAGER M ON M.KD_MANAGER = T.KD_MANAGER;

--Menampilkan nama pemain,klub pemain,dan gaji
SELECT P.NAMA_PLAYER,T.NAMA_TEAM,C.GAJI_PL
FROM CONTRACT C
JOIN TEAM T ON T.KD_TEAM = C.KD_TEAM
JOIN PLAYER P ON P.KD_PLAYER = C.KD_PLAYER
ORDER BY 2,3 DESC;

--Menampilkan nama player dan keterangan posisi
SELECT NAMA_PLAYER,CASE POSISI WHEN 'GK' THEN 'Kiper' WHEN 'DF' THEN 'Bek' WHEN 'MF' THEN 'Gelandang' WHEN 'ST' THEN 'Striker' ELSE 'tidak ada' END AS "Keterangan"
FROM PLAYER 
ORDER BY 1;