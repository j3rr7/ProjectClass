--1--
select h.id_nota,'RP'||lpad(h.total_bersih,11,' ')||',00' "TOTAL BERSIH", nvl(m.nama_member,'-') "NAMA MEMBER", p.nama_pegawai, nvl(e.nama_event,'-') "EVENT"
from hjual h
left join member m on m.id_member = h.id_member
left join pegawai p on p.id_pegawai = h.id_pegawai
left join event_potongan e on e.id_event = h.id_event
order by h.total_bersih desc;

--2--
select p.nama_pegawai "NAMA PEGAWAI", nvl(pe.nama_pegawai,to_char('ini manager')) "NAMA MANAGER"
from pegawai p
left join pegawai pe on p.id_manager = pe.id_pegawai 
order by nvl(pe.nama_pegawai,'ini manager') desc;

--3--
select m.nama_member, nvl(to_char(h.total_bersih),'Tidak pernah bertransaksi'), to_char(h.tanggal_transaksi,'YYYY-MM-DD')
from hjual h
right join member m on h.id_member = m.id_member
order by h.total_bersih;


--SOAL 3E--
select distinct m.nama_menu "NAMA_MENU",d.jumlah "JUMLAH TERJUAL"
from bahan b,resep r
inner join menu m on m.id_menu = r.id_menu
left join djual d on d.id_menu = r.id_menu
where r.id_bahan = 'BA018' 
group by m.nama_menu,r.id_menu,d.jumlah
order by 2 desc, m.nama_menu;

--SOAL 4--
select distinct m.nama_menu "NAMA_MENU", sum(r.jumlah*b.harga_bahan) "MODAL"
from menu m
inner join resep r on r.id_menu=m.id_menu
inner join djual d on d.id_menu=m.id_menu
inner join hjual h on h.id_nota = d.id_nota
inner join bahan b on b.id_bahan=r.id_bahan
where to_char(h.tanggal_transaksi,'dd-mm-yyyy')<'29-mar-2018' and to_char(h.tanggal_transaksi,'dd-mm-yyyy')>'18-apr-2018'
group by m.nama_menu,r.id_menu;