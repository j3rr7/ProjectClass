#include <iostream>
#include <string>
#include <conio.h>
#include <vector>
#include <windows.h>
#include <cstdlib>
#include <time.h>


using namespace std;

int main()
{
    int max_score = 0;

    string nama[5] = {"------","------","------","------","------"};

    int chance[2] = {1,0}; //random chance

    int gerakan[3] = {-1,0,1}; // random gerakan musuh

    char main_lagi = 'Y'; //ngasih retry

    srand(time(NULL));

    char keyboard = 'd'; //jalannya uler

    string map1[20][40]; // lebar map1

    string map2[20][80]; // lebar map2

//===================
// Deklarasi posisi awal snake
    int snakex[500]; // batas panjang snake
    int snakey[500];

    int panjang = 2; //deklarasi panjang snake

    snakex[0] = 8; // kepala
    snakey[0] = 15;

    snakex[1] = 7; // buntut
    snakey[1] = 15;
//===================
    int powerL_x;
    int powerL_y = rand() % 19 + 1;

    bool powerL = false ; //powerup L

    //koordinat powerup
    if (powerL==true){
        powerL_x = rand() % 79 + 1;
    }
    else if (powerL==false){
        powerL_x = rand() % 39 + 1;
    }
    //koordinat powerup

    int score = 0;
    int highscore[5] = {0,0,0,0,0};

bool gameover = false;


//============================DEKLARASI VEKTOR MAKANAN=========================
    vector<int>random_posx_makanan;
    vector<int>random_posy_makanan;
    for (int i = 0 ; i < 5 ; i++){
        int randomy =1+rand()%18;
        int randomx;
        if (powerL==false){
            randomx =1+rand()%38;
        }
        else if (powerL==true){
            randomx =1+rand()%78;
        }
        random_posx_makanan.push_back(randomx); // masuk ke vektor x
        random_posy_makanan.push_back(randomy); // masuk ke vektor y
        //cout << random_posx_makanan[i] << " ";
        //cout << random_posy_makanan[i] << " ";
    }
//=====================================================================
    while (main_lagi == 'Y'&&gameover==false||main_lagi == 'y'&&gameover==false){
            if (powerL==true){
                map2[powerL_y][powerL_x] = ' ';
                map1[powerL_y][powerL_x] = ' ';
            }
        //==============GERAKAN SNAKE===============
        if (kbhit()){
            keyboard = getch();
        }
        if (keyboard == 'w' ||keyboard == 'W'){
            snakey[0]--;
        }
        if (keyboard == 's' ||keyboard == 'S'){
            snakey[0]++;
        }
        if (keyboard == 'a' ||keyboard == 'A'){
            snakex[0]--;
        }
        if (keyboard == 'd' ||keyboard == 'D'){
            snakex[0]++;
        }
        if (keyboard == '0'){
            gameover = true;
        }
        //=========================================
        if (powerL==false){
            //=============INISIALISASI MAP================
            for (int i = 0 ;i<20;i++){
                for (int j=0;j<40;j++){
                    if (i==0||i==19){
                        map1[i][j] = "-";
                    }
                    else if (j==0||j==39){
                        map1[i][j] = "|";
                    }
                    else {
                        map1[i][j] = " ";
                    }
                }
            }
            //=============INISIALISASI MAP================

            //BADAN IKUT KEPALA
            for (int l = panjang;l>0;l--){
                snakex[l]=snakex[l-1];
                snakey[l]=snakey[l-1];
            }
            //BADAN IKUT KEPALA
            //ngasih badan

            for (int m=0;m<=panjang;m++){
                map1[snakey[0]][snakex[0]] = "*";
                if(m!=0){
                    map1[snakey[m]][snakex[m]] = "%";
                }
            }
            //ngasih badan
            //ketemu makanan?
            for (int u=0;u<5;u++){
                if (map1[snakey[0]][snakex[0]]==map1[random_posy_makanan[u]][random_posx_makanan[u]]){
                    panjang++;
                    random_posx_makanan[u] = 1+rand()%38;
                    random_posy_makanan[u] = 1+rand()%18;
                    score = score + 1;
                }
            }
            //ketemu makanan?
            map1[powerL_y][powerL_x] = 'L';
            if (map1[snakey[0]][snakex[0]]==map1[powerL_y][powerL_x]){
                map1[powerL_y][powerL_x] = ' ';
                powerL = true ;
            }




            //=============PRINT MAP================
            for (int i=0;i<20;i++){
                for (int j=0;j<40;j++){
                //========INISIALISASI MAKANAN=======
                    for (int k=0;k<5;k++){
                        if (i==random_posy_makanan[k]&&j==random_posx_makanan[k]){
                                map1[i][j] = 'o';
                            }
                        }
                //========INISIALISASI MAKANAN=======
                    cout << map1[i][j];
                }
                cout << endl;
            }
            //=============PRINT MAP================
            //pengecekan nabrak tembok
            if (snakex[0]==0||snakex[0]==39||snakey[0]==0||snakey[0]==19){
                main_lagi = 'n';
            }
            //pengecekan nabrak tembok
        }



        else if (powerL==true){
            //=============INISIALISASI MAP================
            for (int i = 0 ;i<20;i++){
                for (int j=0;j<80;j++){
                    if (i==0||i==19){
                        map2[i][j] = "-";
                    }
                    else if (j==0||j==79){
                        map2[i][j] = "|";
                    }
                    else {
                        map2[i][j] = " ";
                    }
                }
            }
            //=============INISIALISASI MAP================

            //BADAN IKUT KEPALA
            for (int l = panjang;l>0;l--){
                snakex[l]=snakex[l-1];
                snakey[l]=snakey[l-1];
            }
            //BADAN IKUT KEPALA
            //ngasih badan

            for (int m=0;m<=panjang;m++){
                map2[snakey[0]][snakex[0]] = "*";
                if(m!=0){
                    map2[snakey[m]][snakex[m]] = "%";
                }
            }
            //ngasih badan
            //ketemu makanan?
            for (int u=0;u<5;u++){
                if (map2[snakey[0]][snakex[0]]==map2[random_posy_makanan[u]][random_posx_makanan[u]]){
                    panjang++;
                    random_posx_makanan[u] = 1+rand()%38;
                    random_posy_makanan[u] = 1+rand()%18;
                    score = score + 1;
                }
            }
            //ketemu makanan?
            map2[powerL_y][powerL_x] = 'L';
            if (map2[snakey[0]][snakex[0]]==map2[powerL_y][powerL_x]){
                powerL = true ;
            }




            //=============PRINT MAP================
            for (int i=0;i<20;i++){
                for (int j=0;j<80;j++){
                //========INISIALISASI MAKANAN=======
                    for (int k=0;k<5;k++){
                        if (i==random_posy_makanan[k]&&j==random_posx_makanan[k]){
                                map2[i][j] = 'o';
                            }
                        }
                //========INISIALISASI MAKANAN=======
                    cout << map2[i][j];
                }
                cout << endl;
            }
            //=============PRINT MAP================
            //pengecekan nabrak tembok
            if (snakex[0]==0||snakex[0]==39||snakey[0]==0||snakey[0]==19){
                main_lagi = 'n';
            }
            //pengecekan nabrak tembok
        }
















Sleep(100);
system("cls");
    }

    cout << "GAMEOVER!!!" <<endl;
    cout << "Panjang maksimal : " << panjang<<endl;
    cout << "Score : " << score<<endl;

    cout << "1. " << nama[0] <<" - "<< highscore[0] << endl;
    cout << "2. " << nama[1] <<" - "<< highscore[1] << endl;
    cout << "3. " << nama[2] <<" - "<< highscore[2] << endl;
    cout << "4. " << nama[3] <<" - "<< highscore[3] << endl;
    cout << "5. " << nama[4] <<" - "<< highscore[4] << endl;

    cout << "Main lagi ? (y/n)"<<endl;
    cin >> main_lagi;

    return 0;
}



//while (true){
//
//
//
//    if (l==false){
//        for (int i = 0 ; i < 20; i++){
//            for (int j = 0;j < 40; j++){
//                if (i==0||i==19){
//                    map1[i][j] = '-';
//                }
//                else if (j==0||j==39){
//                    map1[i][j] = '|';
//                }
//                else {
//                    map1[i][j] = ' ';
//                }
//                for (int k = 0 ;k<5;k++){
//                    if (i==random_posy_makanan[k]&&j==random_posx_makanan[k]){
//                        map1[i][j] = '0';
//                    }
//                }
//                cout << map1[i][j];
//            }
//            cout << "\n";
//        }
//    }
//    else if (l==true){
//        for (int i = 0 ; i < 20; i++){
//            for (int j = 0;j < 80; j++){
//                if (i==0||i==19){
//                    map2[i][j] = '-';
//                }
//                else if (j==0||j==79){
//                    map2[i][j] = '|';
//                }
//                else {
//                    map2[i][j] = ' ';
//                }
//                for (int k = 0 ;k<5;k++){
//                    if (i==random_posy_makanan[k]&&j==random_posx_makanan[k]){
//                        map1[i][j] = '0';
//                    }
//                }
//                cout << map2[i][j];
//            }
//            cout << "\n";
//        }
//    }
//
//    if (kbhit()){
//        keyboard = getch();
//        if (keyboard == 'w'||keyboard == 'W'){
//            l = !l;
//        }
//        else if (keyboard == 's'||keyboard == 'S'){
//
//        }
//        else if (keyboard == 'a'||keyboard == 'A'){
//
//        }
//        else if (keyboard == 'd'||keyboard == 'D'){
//
//        }
//        else if (keyboard == ' '){}
//        else if (keyboard == '0'){}
//    }
//Sleep(100);
//system("cls");
//}
