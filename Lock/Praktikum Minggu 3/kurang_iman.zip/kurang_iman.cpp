#include <iostream>
#include <cstdlib>
#include <time.h>
#include <string>
using namespace std;

bool user1 = true;
bool iman = true;
int angka1;
bool menu = 1;
int menu2 = 0;
int i, j, k;
int pilih;
int total;
int ai = 0;
int player1;
int hasil, hasil2 = 0, hasilai = 0;
int player2;
int sump1 = 0, sump2 = 0;
int temp;
char over;

int main()
{
	srand(time(NULL));
	while (menu == true) {
		cout << "Masukkan angka awal : " << endl;
		cin >> angka1;
		if (angka1 <= 0) {
			cout << "Masukkan angka awal : " << endl;
			cin >> angka1;
		}
		else if (angka1 > 0) {
			for (i = 1; i <= angka1; i++) {
				if (i == 1 && angka1 > 0 && angka1 < 10) {
					cout << "|_____" << "0" << angka1 << "_____|" << endl;
				}
				else if (i != 1) {
					cout << "|____________|" << endl;
				}
				else {
					cout << "|_____" << angka1 << "_____|" << endl;
				}
			}
		}
		cout << "Masukan pilihan menu : " << endl;
		pilih = 0;
		while (pilih == 0) {
			cout << "1. VS AI" << endl;
			cout << "2. VS PLAYER" << endl;
			cin >> pilih;
			if (pilih > 2) {
				pilih = 0;
			}
		}
		//=======================================================================================================================================================================
		while (pilih == 1) {
			

			while (user1 == true) {
				cout << "Player 1 : " << endl;
				cin >> player1;
				if (player1 == 1 || player1 == 3 || player1 == 4) {
					user1 = false;
					iman = true;
					hasil2 += player1;
					hasil = angka1 - hasil2 - ai;
					//cout << "hasil2 : " << hasil2 << endl;
					if (hasil > 0) {
						for (i = 1; i <= angka1 - hasil; i++) {
							cout << "|            |" << endl;
						}
						for (i = 1; i <= hasil; i++) {
							if (i == 1) {
								if (hasil >= 10) {
									cout << "|_____" << hasil << "_____|" << endl;
								}
								else {
									cout << "|_____" << "0" << hasil << "_____|" << endl;
								}
							}
							else {
								cout << "|____________|" << endl;
							}
						}
					}
					else {
						user1 = true;
						iman = true;
					}
				}
				else {
					user1 = true;
					
				}
				if (hasil == 0) {
					user1 = false;
					iman = false;
					cout << "Player1 Menang";
					pilih = 999;
				}
			}

			//==============================================================================
				while (iman == true) {
					ai = rand() % 5 + 1;
					if (ai == 1 || ai == 3 || ai == 4) {
						iman = false;
						user1 = true;
						cout << "AI : " << ai << endl;
						hasilai += ai;
						total = hasil - hasilai;
						for (i = 1; i <= angka1 - total; i++) {
							cout << "|            |" << endl;
						}
						for (i = 1; i <= total; i++) {
							if (i == 1) {
								if (total >= 10) {
									cout << "|_____" << total << "_____|" << endl;
								}
								else {
									cout << "|_____" << "0" << total << "_____|" << endl;
								}
							}
							else {
								cout << "|____________|" << endl;
							}
						}
					}
					else {
						iman = true;
					}
					if (total == 0) {
						user1 = false;
						iman = false;
						cout << "AI MENANG" << endl;
						pilih = 999;
					}
					if (total < 0) {
						iman = false;
					}
				}

		}
		//=======================================================================================================================================================================
		while (pilih == 2) {
			cout << "user1 turun : ";
			cin >> player1;
			if (player1 == 1 || player1 == 3 || player1 == 4) {
				sump1 += player1;
				hasil = angka1 - (sump1 + sump2);
				temp = sump1 + sump2;
			}
			else {
				sump1 = sump1;
				hasil = angka1 - (sump1 + sump2);
				temp = sump1 + sump2;
			}

			if (player1 == 1 && hasil > 0 || player1 == 3 && hasil > 0 || player1 == 4 && hasil > 0) {
				for (i = 1; i <= temp; i++) {
					cout << "|            |" << endl;
				}
				for (i = 1; i <= hasil; i++) {
					if (i == 1) {
						if (hasil > 10) {
							cout << "|_____" << hasil << "_____|" << endl;
						}
						else {
							cout << "|_____" << "0" << hasil << "_____|" << endl;
						}
					}
					else if (i == hasil) {
						cout << "|____________|" << endl;
					}
					else {
						cout << "|____________|" << endl;
					}
				}
			}
			if (hasil == 0) {
				cout << "Player1 menang" << endl;
				pilih = 999;
			}

			cout << "user2 turun : ";
			cin >> player2;

			if (player2 == 1 && hasil > 0 || player2 == 3 && hasil > 0 || player2 == 4 && hasil > 0) {
				sump2 += player2;
				hasil = angka1 - (sump1 + sump2);
				temp = sump1 + sump2;
			}
			else {
				sump2 = sump2;
				hasil = angka1 - (sump1 + sump2);
				temp = sump1 + sump2;
			}

			if (player2 == 1 || player2 == 3 || player2 == 4) {
				for (i = 1; i <= temp; i++) {
					cout << "|            |" << endl;
				}
				for (i = 1; i <= hasil; i++) {
					if (i == 1) {
						if (hasil > 10) {
							cout << "|_____" << hasil << "_____|" << endl;
						}
						else {
							cout << "|_____" << "0" << hasil << "_____|" << endl;
						}
					}
					else if (i == hasil) {
						cout << "|____________|" << endl;
					}
					else {
						cout << "|____________|" << endl;
					}
				}
			}

			if (hasil == 0) {
				cout << "Player2 menang" << endl;
				pilih = 999;
			}

		}
		while (pilih = 999) {
			cout << "Game Over. Want to play again ? (y/n)";
			cin >> over;

			if (over == 'y') {
				user1 = true;
				iman = true;
				menu = true;
				return main();
			}
			else if (over == 'n') {
				cout << "See ya next time";
				return 0;
			}
		}
		return 0;
	}
}
