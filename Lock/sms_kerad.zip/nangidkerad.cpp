#include <iostream>
#include <windows.h>
#include <time.h>
#include <cstdlib>

using namespace std;

struct HaPe
{
    string nama[3];
    string sms[5];
    int notlpn[3];
    int pulsa[3];
};

void Login(int &menulogin,string &username,HaPe user[], int &notlp)
{
    cout << "1. nama"<<endl;
    cout << "2. notlp"<<endl;
    cin >> menulogin;
    if (menulogin==1)
    {
        //cin.ignore();
        cin >> username;
    }
    else if (menulogin==2)
    {
        //cin.ignore();
        cin >> notlp;
    }
}


void Registrasi(HaPe user[],int &MenuRegis, string &username, int &counter, int &pulsa,int &notlp)
{
    cout << "1. masukkan nama"<<endl;
    cout << "2. masukkan no tlp"<<endl;
    cout << "3. masukkan jumlah pulsa"<<endl;
    cin >> MenuRegis;
    if (MenuRegis == 1)
    {
        //cin.ignore();
        cin >> username;
        user[counter].nama[counter] = username;
    }
    else if (MenuRegis==3)
    {
        //cin.ignore();
        cin >> pulsa;
        user[counter].pulsa[counter] = pulsa;
    }
    else if (MenuRegis==2)
    {
        //cin.ignore();
        cin >> notlp;
        user[counter].notlpn[counter] = notlp;
    }
    counter++;
}


void SMS()
{
    cout << "Maap kak iman saya goyah :v"<<endl;
}
void Telp()
{
    cout << "Sudah lelah dengan semuanya :v"<<endl;
}
void IsiPulsa()
{
    cout << "ikhlas dah berapa aja :v"<<endl;
}
void BacaSMS()
{
    cout << "Berserah kepada yang Maha Kuasa :'v"<<endl;
}

void Masuk()
{
    int pilih;
    system("CLS");
    do {
        cout << "WELCOME: "<<user[counter].nama<<endl;
        cout << "No Hp : "<<user[counter].nohp<<endl;
        cout << "Pulsa: Rp."<<user[counter].pulsa<<endl;
        cout << "1.SMS"<<endl;
        cout << "2.Telp"<<endl;
        cout << "3.Isi pulsa"<<endl;
        cout << "4.Lihat sms"<<endl;
        cout << "5.Logout"<<endl;
        cout << "Pilih menu: ";
        cin >> pilih;

        if (pilih==1){
            SMS();
        } else if (pilih==2){
            Telp();
        } else if (pilih==3){
            IsiPulsa();
        } else if (pilih==4){
            BacaSMS();
        }
    } while (pilih!=5);
    cout << "\nAnda log out\n";
}







int main()
{
    bool menu;
    int pilihan;
    HaPe user[3];
    int menuRegis;
    int menuLogIn;
    string username;
    int counter=0;
    int pulsa = 0,notlp = 0;

    do
    {
        cout << "1. Login " << endl;
        cout << "2. Register "<<endl;
        cin >> pilihan;

        if (pilihan==1)
        {
            Login(menuLogIn,username,user,notlp);
            for (int i=0;i<3;i++)
            {
                if (username == user[i].nama[i]&&notlp == user[i].notlpn[i])
                {
                    cout << "\nUser Logged in\n";
                    Masuk();
                }
                else {
                    cout << "\nLogin Galal\n";
                }
            }
        }
        else if (pilihan==2)
        {
            Registrasi(user,menuRegis,username,counter,pulsa,notlp);
        }
        if (counter == 3)
        {
            cout << "\nRegistrasi sudah penuh\n";
        }
    }while(menu);

    return 0;
}
