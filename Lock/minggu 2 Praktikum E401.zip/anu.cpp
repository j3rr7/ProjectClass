#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	cout << "x1 : ";
	int x1;
	cin >> x1;
	cout << "y1 : ";
	int y1;
	cin >> y1;

	cout << "x2 : ";
	int x2;
	cin >> x2;
	cout << "y2 : ";
	int y2;
	cin >> y2;

	cout << "x3 : ";
	int x3;
	cin >> x3;
	cout << "y3 : ";
	int y3;
	cin >> y3;

	cout << "x4 = ";
	int x4;
	cin >> x4;
	cout << "y4 = ";
	int y4;
	cin >> y4;

	double a, b, c, d, diagonal1, diagonal2, l;

	a = sqrt(pow(y2 - y1, 2) + pow(x2 - x1, 2)); //a-b

	b = sqrt(pow(y3 - y2, 2) + pow(x3 - x2, 2)); //b-c

	c = sqrt(pow(y4 - y3, 2) + pow(x4 - x3, 2)); //c-d

	d = sqrt(pow(y1 - y4, 2) + pow(x1 - x4, 2)); //d-a

	diagonal1 = sqrt(pow(x3 - x1, 2) + pow(y3 - y1, 2)); //ga tau :'v
	diagonal2 = sqrt(pow(y4 - y2, 2) + pow(x4 - x2, 2)); //ga tau :v
	double diagonallayang1 = sqrt(pow(y4 - y2, 2) + pow(x4 - x2, 2));
	double diagonallayang2 = sqrt(pow(y3 - y1, 2) + pow(x3 - x1, 2));
	double diagonallayang3 = sqrt(pow(y2 - y4, 2) + pow(x2 - x4, 2));
	double diagonallayang4 = sqrt(pow(y3 - y1, 2) + pow(x3 - x1, 2));
	//cout << diagonal1 << endl << diagonal2;
	if (a == b && a == c && a == d && b == c && b == d && c == d && diagonal1 == diagonal2)
	{
		cout << "Bentuk : Persegi" << endl;
		l = pow(a, 2);
		cout << "Luas : " << l;
	}
	else if (a == c && b == d && a != b && c != d && diagonal1 == diagonal2) {
		cout << "Bentuk : Persegi Panjang" << endl;
		l = a * b;
		cout << "Luas : " << l;
	}
	else if (a == c && b == d && a != b && c != d && x2 != x1 && x4 != x3) {
		cout << "Bentuk : Jajar Genjang" << endl;
		double aa = sqrt(pow(x2 - x1, 2));
		double temp = a;
		l = temp * aa;
		cout << "Luas : " << l;
	}
	else if (a == c && a != b && c != d && diagonal1 == diagonal2 || d == b && a != c && a != b && c != d && diagonal1 == diagonal2) {
		cout << "Bentuk : Trapesium Sama Kaki";
		if (a < c) {
			int aa = (c - a)*0.5;
			float bb = sqrt(pow(aa, 2));
			float tinggi = sqrt(pow(b, 2) - pow(bb, 2));
			l = ((a + c)*tinggi)*0.5;
		}
		else {
			int aa = (d - b)*0.5;
			float bb = sqrt(pow(aa, 2));
			float tinggi = sqrt(pow(a, 2) - pow(bb, 2));
			l = ((d + b)*tinggi)*0.5;
		}
		cout << endl << "Luas : " << l;
	}
	else if (a==b&&c==d&&a!=d&&b!=c&&diagonallayang1!=diagonallayang2||d==a&&c==b&&a!=b&&d!=c&&diagonallayang3!=diagonallayang4) {
		cout << "Bentuk : Layang layang";
		if (a==b&&c==d&&a!=d&&b!=c&&diagonallayang1!=diagonallayang2){
            l = (diagonallayang1*diagonallayang2)*0.5;
		}
		else {
            l = (diagonallayang3*diagonallayang4)*0.5;
		}
        cout << endl << "Luas : " << l;
	}
	else {
        cout << endl << "Bangun : Tidak terdefinisi";
        cout << endl << "Luas : -";
	}
	return 0;
}
