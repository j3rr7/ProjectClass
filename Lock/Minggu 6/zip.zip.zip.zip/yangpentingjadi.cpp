#include <iostream>
#include <windows.h>
#include <conio.h>
#include <ctime>
#include <cstdlib>
#include <vector>

using namespace std;

void init_map(string Map[25][25])
{
    for (int i=0;i<22;i++)
    {
        for (int j=0;j<22;j++)
        {
            if (i==21&&j==0)
            {
                Map[i][j]="+";
            }
            else if (i==0&&j==21)
            {
                Map[i][j]="+";
            }
            else if (i==21&&j==21)
            {
                Map[i][j]="+";
            }
            else if (i==0&&j==0)
            {
                Map[i][j]="+";
            }
            else if (i==0||i==21)
            {
                if (j<21)
                {
                    Map[i][j]="-";
                }
                else
                {
                    Map[i][j]=" ";
                }
            }
            else if(j==0||j==21)
            {
                Map[i][j]="|";
            }
            else
            {
                Map[i][j]=" ";
            }
        }
    }
}

void gerak(string Map[25][25], int &playerx, int &playery, char &kbh, char &player)
{
        if(kbhit())
        {
            kbh=getch();
            if(kbh=='w' && playery>1)
            {
                playery--;
                player='^';
            }
            else if(kbh=='s' && playery<20)
            {
                playery++;
                player='v';
            }
            else if(kbh=='a' && playerx>1)
            {
                playerx--;
                player='<';
            }
            else if(kbh=='d'&& playerx<20)
            {
                playerx++;
                player='>';
            }
        }
}
void Random(int randomx[],int randomy[])
{
    for (int i=0;i<15;i++)
    {
        randomx[i] = 1 + rand()%18;
        randomy[i] = 1 + rand()%18;
    }

}

void cetak_map(string Map[25][25],int playery , int playerx,char player,int uang,int gold,int silver, int copper,int floor,int x[],int y[])
{
    for (int i=0;i<25;i++)
    {
        for (int j=0;j<25;j++)
        {
            cout << Map[i][j];
            if (Map[i][j]==Map[playery][playerx])
            {
                Map[playery][playerx] = player;
            }
            else if(i==1 && j==22)
            {
                cout << floor << "F";
            }
            else if(i==2 && j==22)
            {
                cout << "Koordinat Gold : ";
            }
            else if(i==3 && j==22)
            {
                cout << x[0] <<","<< y[0];
            }
            else if(i==4 && j==22)
            {
                cout << "Koordinat Silver : ";
            }
            else if(i==5 && j==22)
            {
                cout << x[1] <<","<< y[1]<< " ; "<< x[2] <<"," << y[2]<< " ; "<< x[3] <<","<< y[3];
            }
            else if(i==6 && j==22)
            {
                cout << "Koordinat Copper : ";
            }
            else if(i==7 && j==22)
            {
                cout << x[4] <<","<< y[4]<< " ; "<< x[5] <<"," << y[5]<< " ; "<< x[6] <<","<< y[6]<<" ; " <<  x[7] <<","<< y[7]<< " ; "<< x[8] <<"," << y[8]<< " ; "<< x[9] <<","<< y[9]<<" ; "<<  x[10] <<","<< y[10]<< " ; "<< x[11] <<"," << y[11]<< " ; "<< x[12] <<","<< y[12]<< " ; "<< x[13] <<","<< y[13];
            }
            else if(i==8 && j==22)
            {
                cout << "Koordinat Tangga : ";
            }
            else if(i==9 && j==22)
            {
                cout << x[14]<<","<<y[14];
            }
        }
        cout << "\n";
    }
    cout << "\nUang yang di dapat : " << uang<< " G";
    cout << "\nGold yang di dapat : " << gold << " buah";
    cout << "\nSilver yang di dapat : " << silver << " buah";
    cout << "\nCopper yang di dapat : " << copper << " buah";
}

void gali_tanah(string Map[25][25],char &kbh,int playerx,int playery,char player,int x[],int y[],int &uang,int &gold, int &silver,int &copper)
{
//    if(kbhit())
//    {
//        kbh=getch();
//        if (kbh==' ')
//        {
//            if (player == '^')
//            {
//                Map[playery+1][playerx] = "x";
//            }
//            if (player=='v')
//            {
//                Map[playery-1][playerx] = "x";
//            }
//            if (player=='>')
//            {
//                Map[playery][playerx+1] = "x";
//            }
//            if (player=='<')
//            {
//                Map[playery][playerx-1] = "x";
//            }
//        }
//    }
    if(kbh==' ')
    {
        if(player=='^')
        {
            Map[playery-1][playerx]="x";
            if (Map[playery-1][playerx]==Map[y[0]][x[0]])
            {
                gold +=1;

            }
            if (Map[playery-1][playerx]==Map[y[1]][x[1]]||Map[playery-1][playerx]==Map[y[2]][x[2]]||Map[playery-1][playerx]==Map[y[3]][x[3]])
            {
                silver +=1;

            }
            if (Map[playery-1][playerx]==Map[y[4]][x[4]]||Map[playery-1][playerx]==Map[y[5]][x[5]]||Map[playery-1][playerx]==Map[y[6]][x[6]]||Map[playery-1][playerx]==Map[y[7]][x[7]]||Map[playery-1][playerx]==Map[y[7]][x[7]]||Map[playery-1][playerx]==Map[y[8]][x[8]]||Map[playery-1][playerx]==Map[y[9]][x[9]]||Map[playery-1][playerx]==Map[y[10]][x[10]]||Map[playery-1][playerx]==Map[y[11]][x[11]]||Map[playery-1][playerx]==Map[y[12]][x[12]]||Map[playery-1][playerx]==Map[y[13]][x[13]])
            {
                copper +=1;

            }
        }
    }
    if(kbh==' ')
    {
        if(player=='v')
        {
            Map[playery+1][playerx]="x";
            if (Map[playery-1][playerx]==Map[y[0]][x[0]])
            {
                gold +=1;

            }
            if (Map[playery-1][playerx]==Map[y[1]][x[1]]||Map[playery-1][playerx]==Map[y[2]][x[2]]||Map[playery-1][playerx]==Map[y[3]][x[3]])
            {
                silver +=1;

            }
            if (Map[playery-1][playerx]==Map[y[4]][x[4]]||Map[playery-1][playerx]==Map[y[5]][x[5]]||Map[playery-1][playerx]==Map[y[6]][x[6]]||Map[playery-1][playerx]==Map[y[7]][x[7]]||Map[playery-1][playerx]==Map[y[7]][x[7]]||Map[playery-1][playerx]==Map[y[8]][x[8]]||Map[playery-1][playerx]==Map[y[9]][x[9]]||Map[playery-1][playerx]==Map[y[10]][x[10]]||Map[playery-1][playerx]==Map[y[11]][x[11]]||Map[playery-1][playerx]==Map[y[12]][x[12]]||Map[playery-1][playerx]==Map[y[13]][x[13]])
            {
                copper +=1;

            }
        }
    }
    if(kbh==' ')
    {
        if(player=='>')
            Map[playery][playerx+1]="x";
            if (Map[playery-1][playerx]==Map[y[0]][x[0]])
            {
                gold +=1;

            }
            if (Map[playery-1][playerx]==Map[y[1]][x[1]]||Map[playery-1][playerx]==Map[y[2]][x[2]]||Map[playery-1][playerx]==Map[y[3]][x[3]])
            {
                silver +=1;

            }
            if (Map[playery-1][playerx]==Map[y[4]][x[4]]||Map[playery-1][playerx]==Map[y[5]][x[5]]||Map[playery-1][playerx]==Map[y[6]][x[6]]||Map[playery-1][playerx]==Map[y[7]][x[7]]||Map[playery-1][playerx]==Map[y[7]][x[7]]||Map[playery-1][playerx]==Map[y[8]][x[8]]||Map[playery-1][playerx]==Map[y[9]][x[9]]||Map[playery-1][playerx]==Map[y[10]][x[10]]||Map[playery-1][playerx]==Map[y[11]][x[11]]||Map[playery-1][playerx]==Map[y[12]][x[12]]||Map[playery-1][playerx]==Map[y[13]][x[13]])
            {
                copper +=1;

            }
    }
    if(kbh==' ')
    {
        if(player=='<')
        {
            Map[playery][playerx-1]="x";
            if (Map[playery-1][playerx]==Map[y[0]][x[0]])
            {
                gold +=1;

            }
            if (Map[playery-1][playerx]==Map[y[1]][x[1]]||Map[playery-1][playerx]==Map[y[2]][x[2]]||Map[playery-1][playerx]==Map[y[3]][x[3]])
            {
                silver +=1;

            }
            if (Map[playery-1][playerx]==Map[y[4]][x[4]]||Map[playery-1][playerx]==Map[y[5]][x[5]]||Map[playery-1][playerx]==Map[y[6]][x[6]]||Map[playery-1][playerx]==Map[y[7]][x[7]]||Map[playery-1][playerx]==Map[y[7]][x[7]]||Map[playery-1][playerx]==Map[y[8]][x[8]]||Map[playery-1][playerx]==Map[y[9]][x[9]]||Map[playery-1][playerx]==Map[y[10]][x[10]]||Map[playery-1][playerx]==Map[y[11]][x[11]]||Map[playery-1][playerx]==Map[y[12]][x[12]]||Map[playery-1][playerx]==Map[y[13]][x[13]])
            {
                copper +=1;

            }
        }
    }
}

void init_tangga()
{

}

int main()
{
    srand(time(NULL));
    int uang=0,gold=0,silver=0,copper=0;
    int randomx[15],randomy[15];
    int floor = 1;
    char kbh;
    char naik='n';
    char player = '^';
    int playery=15,playerx=6;
    string arr[25][25];
    char pilihan='y';
    if (floor != 1)
    {
        arr[playery][playerx]=="t";
    }
    while (pilihan == 'y')
    {
    arr[playery][playerx]=="t";
    Random(randomx,randomy);
    init_tangga();
    do
    {
        init_map(arr);
        gerak(arr,playerx,playery,kbh,player);
        gali_tanah(arr,kbh,playerx,playery,player,randomx,randomy,uang,gold,silver,copper);
        cetak_map(arr,playery,playerx,player,uang,gold,silver,copper,floor,randomx,randomy);
        if (kbh==' ')
        {
            if (player=='^')
            {
                if (arr[playery+1][playerx]==arr[randomx[14]][randomy[14]])
                {
                    arr[playery+1][playerx]="o";
                }
            }
            else if (player=='v'){
                if (arr[playery-1][playerx]==arr[randomx[14]][randomy[14]])
                {
                    arr[playery-1][playerx]="o";
                }
            }
            else if (player=='>'){
                if (arr[playery][playerx+1]==arr[randomx[14]][randomy[14]])
                {
                    arr[playery][playerx+1]="o";
                }
            }
            else if (player=='<'){
                if (arr[playery][playerx-1]==arr[randomx[14]][randomy[14]])
                {
                    arr[playery][playerx-1]="o";
                }
            }
            if(arr[playery][playerx]=="o")
            {
                cout << "Yakin mw turun ? (y/n) ";
                cin >> pilihan;
                if (pilihan=='y')
                {
                    floor +=1;
                    pilihan = 'y';
                }
            }
        }
        Sleep(100);
        system("cls");
    } while (naik != 'y');
    }


    return 0;
}
