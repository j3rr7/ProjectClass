/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpgsederhana;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author adgry
 */
public class RpgSederhana {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        boolean battlemode = false; //default false 
        boolean gameover = false; //default false
        Scanner sc = new Scanner(System.in); // scanner
        Character Map[][] = new Character[12][12]; //init char map
        int HP = 100,MP = 100,ATK = 20,DEF = 10,Exp = 0,Lvl = 1, gold = 0;  //init player
        int maxHP = 100, maxMP = 100; //init max value player
        int enHP=200,enATK=40,enDEF=35; //status enemy
        int enHPc=80,enATKc=15,enDEFc=5;
        int itemHP=0,itemMP=0,itemSHP=0,itemSMP=0; //item player

        int pos_x = (int)(Math.random() * 10) + 1, pos_y = (int)(Math.random() * 10) + 1; //random player osition
        
        Random randomNum = new Random(); // init randomnum object
        int randomEnemyCount = 2 + randomNum.nextInt(3); //random between 2 and 4
        
        
//        for (int i = 0; i < randomEnemyCount; i++) {
//            if(chance[randomNum.nextInt(10)] == 1)
//                System.out.println(r[1]);
//            else
//                System.out.println(r[0]);
//        }
        Character[] r = new Character[randomEnemyCount];
        int[] chance = {0,0,0,0,0,0,0,1,1,1};
        int[] posX = new int[randomEnemyCount];
        int[] posY = new int[randomEnemyCount];
        for (int i = 0; i < randomEnemyCount; i++) {
            do
            {
                posX[i] = 1+randomNum.nextInt(10);
                posY[i] = 1+randomNum.nextInt(10);
            }while(posX[i] == pos_x || posY[i] == pos_y);
            if (chance[randomNum.nextInt(10)] == 1)
            {
                r[i] = 'M';
            }
            else
            {
                r[i] = 'm';
            }
        }

        
        UpdateMap(Map, pos_x, pos_y,posX,posY,randomEnemyCount,r);
        while (!gameover)
        {
            if(Exp % 100 == 0)
            {
                Lvl += 1;
                    float c_u =(float)Lvl*(ATK + (ATK * 0.2f));
                    float c_z =(float)Lvl*(DEF + (DEF * 0.2f));
                    ATK = (int) c_u;
                    DEF = (int) c_z;
                    float m_h = (float)Lvl*(HP + (HP * 0.1f));
                    float m_p = (float)Lvl*(MP + (MP * 0.1f));
                    maxHP = (int) m_h;
                    maxMP = (int) m_p;
                    HP = maxHP;
                    MP = maxMP;
            }
            if(HP <= 0)
            {
            gameover = true;
            }
            if (enHP <= 0 || enHPc <=0)
            {
                battlemode = true;
            }
            battlemode = false;
            for (int i = 0; i < 12; i++)
            {
                for (int j = 0; j < 12; j++) 
                {
                    System.out.print(Map[i][j]);
                }
                System.out.println();
            }
            Player(HP,MP,Exp,Lvl,gold,maxHP,maxMP);
            MainMenu();
            String st = sc.next();
            char gerak = st.charAt(0);
            if (gerak == 'w' && pos_y > 1)
            {
                while(Map[pos_y-1][pos_x]=='M' && !battlemode)
                {
                    int turn = 1;int enchance = 0;
                    float atksementara = (float)(ATK+(ATK * 0.4));
                    int counter_atk = ATK;
                    int smth = (int) atksementara;
                    System.out.println("Player");
                    System.out.println("HP : " + HP + "/" + maxHP);
                    System.out.println("MP : " + MP + "/" + maxMP);
                    System.out.println("---------------");
                    BattleModeBoss(enHP);
                    int pilih = sc.nextInt();

                    if(pilih == 1)
                    {
                    if(HP <= 0)
                    {
                        gameover = true;
                    }
                    if (enHP <= 0)
                    {
                        battlemode = true;
                    }                        
                        turn = 1;
                        if(enchance > 0)
                        {
                            ATK = smth;
                        }
                        else
                        {
                            ATK = counter_atk;
                        }
                        while (turn != 3)
                        {
                            if(turn == 1)
                            {
                                int ctr = ATK - enDEF;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Player attacked enemy, enemy suffered " + ctr +" damage");
                                enHP -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                            if(turn == 2)
                            {
                                int ctr = enATK - DEF;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Enemy attacked player, player suffered "+ ctr +" damage");
                                HP -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                        }
                    }
                    else if (pilih == 2)
                    {
                        if(MP >0)
                        {
                            MP -= 20;
                            enchance = 3;
                        }
                    }
                    else if (pilih == 3)
                    {
                        battlemode = true;
                    }
                }
                while(Map[pos_y-1][pos_x]=='m' && !battlemode)
                {
                    int turn = 1;int enchance = 0;
                    float atksementara = (float)(ATK+(ATK * 0.4));
                    int counter_atk = ATK;
                    int smth = (int) atksementara;
                    System.out.println("Player");
                    System.out.println("HP : " + HP + "/" + maxHP);
                    System.out.println("MP : " + MP + "/" + maxMP);
                    System.out.println("---------------");
                    BattleModeCommon(enHPc);
                    int pilih = sc.nextInt();

                    if(pilih == 1)
                    {
                    if(HP <= 0)
                    {
                        gameover = true;
                    }
                    if (enHPc <= 0)
                    {
                        battlemode = true;
                    }                        
                        turn = 1;
                        if(enchance > 0)
                        {
                            ATK = smth;
                        }
                        else
                        {
                            ATK = counter_atk;
                        }
                        while (turn != 3)
                        {
                            if(turn == 1)
                            {
                                int ctr = ATK - enDEFc;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Player attacked enemy, enemy suffered " + ctr +" damage");
                                enHP -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                            if(turn == 2)
                            {
                                int ctr = enATKc - DEF;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Enemy attacked player, player suffered "+ ctr +" damage");
                                HP -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                        }
                    }
                    else if (pilih == 2)
                    {
                        if(MP >0)
                        {
                            MP -= 20;
                            enchance = 3;
                        }
                    }
                    else if (pilih == 3)
                    {
                        battlemode = true;
                    }
                }
                pos_y -= 1;
            }
            else if (gerak == 's' && pos_y < 10)
            {
                while(Map[pos_y+1][pos_x]=='M' && !battlemode)
                {
                    int turn = 1;int enchance = 0;
                    float atksementara = (float)(ATK+(ATK * 0.4));
                    int counter_atk = ATK;
                    int smth = (int) atksementara;
                    System.out.println("Player");
                    System.out.println("HP : " + HP + "/" + maxHP);
                    System.out.println("MP : " + MP + "/" + maxMP);
                    System.out.println("---------------");
                    BattleModeBoss(enHP);
                    int pilih = sc.nextInt();

                    if(pilih == 1)
                    {
                    if(HP <= 0)
                    {
                        gameover = true;
                    }
                    if (enHP <= 0)
                    {
                        battlemode = true;
                    }                        
                        turn = 1;
                        if(enchance > 0)
                        {
                            ATK = smth;
                        }
                        else
                        {
                            ATK = counter_atk;
                        }
                        while (turn != 3)
                        {
                            if(turn == 1)
                            {
                                int ctr = ATK - enDEF;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Player attacked enemy, enemy suffered " + ctr +" damage");
                                enHP -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                            if(turn == 2)
                            {
                                int ctr = enATK - DEF;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Enemy attacked player, player suffered "+ ctr +" damage");
                                HP -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                        }
                    }
                    else if (pilih == 2)
                    {
                        if(MP >0)
                        {
                            MP -= 20;
                            enchance = 3;
                        }
                    }
                    else if (pilih == 3)
                    {
                        battlemode = true;
                    }
                }
                while(Map[pos_y+1][pos_x]=='m' && !battlemode)
                {
                    int turn = 1;int enchance = 0;
                    float atksementara = (float)(ATK+(ATK * 0.4));
                    int counter_atk = ATK;
                    int smth = (int) atksementara;
                    System.out.println("Player");
                    System.out.println("HP : " + HP + "/" + maxHP);
                    System.out.println("MP : " + MP + "/" + maxMP);
                    System.out.println("---------------");
                    BattleModeCommon(enHPc);
                    int pilih = sc.nextInt();

                    if(pilih == 1)
                    {
                    if(HP <= 0)
                    {
                        gameover = true;
                    }
                    if (enHPc <= 0)
                    {
                        battlemode = true;
                    }                        
                        turn = 1;
                        if(enchance > 0)
                        {
                            ATK = smth;
                        }
                        else
                        {
                            ATK = counter_atk;
                        }
                        while (turn != 3)
                        {
                            if(turn == 1)
                            {
                                int ctr = ATK - enDEFc;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Player attacked enemy, enemy suffered " + ctr +" damage");
                                enHPc -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                            if(turn == 2)
                            {
                                int ctr = enATKc - DEF;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Enemy attacked player, player suffered "+ ctr +" damage");
                                HP -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                        }
                    }
                    else if (pilih == 2)
                    {
                        if(MP >0)
                        {
                            MP -= 20;
                            enchance = 3;
                        }
                    }
                    else if (pilih == 3)
                    {
                        battlemode = true;
                    }
                }                
                pos_y += 1;
            }
            else if (gerak == 'a' && pos_x > 1)
            {
                while(Map[pos_y][pos_x-1]=='M' && !battlemode)
                {
                    int turn = 1;int enchance = 0;
                    float atksementara = (float)(ATK+(ATK * 0.4));
                    int counter_atk = ATK;
                    int smth = (int) atksementara;
                    System.out.println("Player");
                    System.out.println("HP : " + HP + "/" + maxHP);
                    System.out.println("MP : " + MP + "/" + maxMP);
                    System.out.println("---------------");
                    BattleModeBoss(enHP);
                    int pilih = sc.nextInt();

                    if(pilih == 1)
                    {
                    if(HP <= 0)
                    {
                        gameover = true;
                    }
                    if (enHP <= 0)
                    {
                        battlemode = true;
                    }                        
                        turn = 1;
                        if(enchance > 0)
                        {
                            ATK = smth;
                        }
                        else
                        {
                            ATK = counter_atk;
                        }
                        while (turn != 3)
                        {
                            if(turn == 1)
                            {
                                int ctr = ATK - enDEF;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Player attacked enemy, enemy suffered " + ctr +" damage");
                                enHP -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                            if(turn == 2)
                            {
                                int ctr = enATK - DEF;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Enemy attacked player, player suffered "+ ctr +" damage");
                                HP -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                        }
                    }
                    else if (pilih == 2)
                    {
                        if(MP >0)
                        {
                            MP -= 20;
                            enchance = 3;
                        }
                    }
                    else if (pilih == 3)
                    {
                        battlemode = true;
                    }
                }
                while(Map[pos_y][pos_x-1]=='m' && !battlemode)
                {
                    int turn = 1;int enchance = 0;
                    float atksementara = (float)(ATK+(ATK * 0.4));
                    int counter_atk = ATK;
                    int smth = (int) atksementara;
                    System.out.println("Player");
                    System.out.println("HP : " + HP + "/" + maxHP);
                    System.out.println("MP : " + MP + "/" + maxMP);
                    System.out.println("---------------");
                    BattleModeCommon(enHPc);
                    int pilih = sc.nextInt();

                    if(pilih == 1)
                    {
                    if(HP <= 0)
                    {
                        gameover = true;
                    }
                    if (enHPc <= 0)
                    {
                        battlemode = true;
                    }                        
                        turn = 1;
                        if(enchance > 0)
                        {
                            ATK = smth;
                        }
                        else
                        {
                            ATK = counter_atk;
                        }
                        while (turn != 3)
                        {
                            if(turn == 1)
                            {
                                int ctr = ATK - enDEFc;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Player attacked enemy, enemy suffered " + ctr +" damage");
                                enHPc -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                            if(turn == 2)
                            {
                                int ctr = enATKc - DEF;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Enemy attacked player, player suffered "+ ctr +" damage");
                                HP -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                        }
                    }
                    else if (pilih == 2)
                    {
                        if(MP >0)
                        {
                            MP -= 20;
                            enchance = 3;
                        }
                    }
                    else if (pilih == 3)
                    {
                        battlemode = true;
                    }
                }                
                pos_x -= 1;
            }
            else if (gerak == 'd' && pos_x < 10)
            {
                while(Map[pos_y][pos_x+1]=='M'&&!battlemode)
                {
                    int turn = 1;int enchance = 0;
                    float atksementara = (float)(ATK+(ATK * 0.4));
                    int counter_atk = ATK;
                    int smth = (int) atksementara;
                    System.out.println("Player");
                    System.out.println("HP : " + HP + "/" + maxHP);
                    System.out.println("MP : " + MP + "/" + maxMP);
                    System.out.println("---------------");
                    BattleModeBoss(enHP);
                    int pilih = sc.nextInt();

                    if(pilih == 1)
                    {
                    if(HP <= 0)
                    {
                        gameover = true;
                    }
                    if (enHP <= 0)
                    {
                        battlemode = true;
                    }                        
                        turn = 1;
                        if(enchance > 0)
                        {
                            ATK = smth;
                        }
                        else
                        {
                            ATK = counter_atk;
                        }
                        while (turn != 3)
                        {
                            if(turn == 1)
                            {
                                int ctr = ATK - enDEF;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Player attacked enemy, enemy suffered " + ctr +" damage");
                                enHP -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                            if(turn == 2)
                            {
                                int ctr = enATK - DEF;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Enemy attacked player, player suffered "+ ctr +" damage");
                                HP -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                        }
                    }
                    else if (pilih == 2)
                    {
                        if(MP >0)
                        {
                            MP -= 20;
                            enchance = 3;
                        }
                    }
                    else if (pilih == 3)
                    {
                        battlemode = true;
                    }
                }
                while(Map[pos_y][pos_x+1]=='m'&&!battlemode)
                {
                    int turn = 1;int enchance = 0;
                    float atksementara = (float)(ATK+(ATK * 0.4));
                    int counter_atk = ATK;
                    int smth = (int) atksementara;
                    System.out.println("Player");
                    System.out.println("HP : " + HP + "/" + maxHP);
                    System.out.println("MP : " + MP + "/" + maxMP);
                    System.out.println("---------------");
                    BattleModeCommon(enHPc);
                    int pilih = sc.nextInt();

                    if(pilih == 1)
                    {
                    if(HP <= 0)
                    {
                        gameover = true;
                    }
                    if (enHPc <= 0)
                    {
                        battlemode = true;
                    }                        
                        turn = 1;
                        if(enchance > 0)
                        {
                            ATK = smth;
                        }
                        else
                        {
                            ATK = counter_atk;
                        }
                        while (turn != 3)
                        {
                            if(turn == 1)
                            {
                                int ctr = ATK - enDEFc;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Player attacked enemy, enemy suffered " + ctr +" damage");
                                enHPc -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                            if(turn == 2)
                            {
                                int ctr = enATKc - DEF;
                                if(ctr<0)
                                    ctr = 0;
                                System.out.println("Enemy attacked player, player suffered "+ ctr +" damage");
                                HP -= ctr;
                                turn += 1;
                                enchance -= 1;
                            }
                        }
                    }
                    else if (pilih == 2)
                    {
                        if(MP >0)
                        {
                            MP -= 20;
                            enchance = 3;
                        }
                    }
                    else if (pilih == 3)
                    {
                        battlemode = true;
                    }
                }                
                pos_x += 1;
            }
            else if (gerak == '1')
            {
                ItemShop();
                int item = sc.nextInt();
                if (item == 1 && gold >= 100)
                {
                    gold -= 100;
                    itemHP += 1;
                }
                else if (item == 2 && gold >= 200)
                {
                    gold -= 200;
                    itemSHP += 1;
                }
                else if (item == 3 && gold >= 250)
                {
                    gold -= 250;
                    itemMP += 1;
                }
                else if (item == 4 && gold >= 350)
                {
                    gold -= 350;
                    itemSMP += 1;
                }
                else
                {
                    System.out.println("Gold Kurang");
                }
            }
            else if (gerak == '2')
            {
                System.out.println("1. Health Potion = " + itemHP);
                System.out.println("2. Super Health Potion = " + itemSHP);
                System.out.println("3. Mana Potion = " + itemMP);
                System.out.println("4. Super Mana Potion = " + itemSMP);
                int useitem = sc.nextInt();
                if(useitem == 1 && itemHP > 0)
                {
                    itemHP -= 1;
                    HP += 50;
                    if(HP > maxHP)
                        HP = maxHP;
                }
                else if (useitem == 2 && itemSHP > 0)
                {
                    itemSHP -= 1;
                    HP = maxHP;
                }
                else if (useitem == 3 && itemMP > 0)
                {
                    itemMP -= 1;
                    MP += 50;
                    if(MP > maxMP)
                        MP = maxMP;
                }
                else if (useitem == 4 && itemSMP > 0)
                {
                    itemSMP -= 1;
                    MP = maxMP;
                }
            }
            else if (gerak == '3')
            {
                Cheat();
                int cheat = sc.nextInt();
                if(cheat == 1)
                {
                    gold += 99999;
                    HP -= 5;
                    MP -= 5;
                }    
                else if (cheat == 2)
                {
                    System.out.println("Level : ");
                    int lvl = sc.nextInt();
                    Lvl = lvl;
                    //int ctra =(Exp / 100);
                    float c_a =(float)lvl*(ATK + (ATK * 0.2f));
                    float c_d =(float)lvl*(DEF + (DEF * 0.2f));
                    ATK = (int) c_a;
                    DEF = (int) c_d;
                    float m_h = (float)lvl*(HP + (HP * 0.1f));
                    float m_p = (float)lvl*(MP + (MP * 0.1f));
                    maxHP = (int) m_h;
                    maxMP = (int) m_p;
                    HP = maxHP;
                    MP = maxMP;
                }
            }
            else if (gerak == '4')
                gameover = !gameover;
            
            UpdateMap(Map, pos_x, pos_y,posX,posY,randomEnemyCount,r);
        }
    }
    
    //Function
    static void UpdateMap(Character[][] Map, int pos_x, int pos_y,int[] posX, int[] posY , int random,Character[] p)
    {
        
        for (int i = 0; i < 12; i++)
        {
            for (int j = 0; j < 12; j++) 
            {
                if(i==0|| j==0||i==11||j==11)
                {
                    char border = '#';
                    Map[i][j] = border;
                }
                else if (i==pos_y&&j==pos_x)
                {
                    Map[i][j] = 'P';
                }
                else
                {
                    Map[i][j] = ' ';
                }
            }
        }
        for (int i = 0; i < random; i++) {
            for (int j = 0; j < random; j++) {
                Map[posY[i]][posX[i]] = p[i];
            }
        }
    }
    static void Player(int HP, int MP,int EXP,int LVL,int gold, int maxHP, int maxMP)
    {
        System.out.println("Player");
        System.out.println("HP : " + HP + "/" + maxHP);
        System.out.println("MP : " + MP + "/" + maxMP);
        System.out.println("Total XP : " + EXP);
        System.out.println("Level : " + LVL);
        System.out.println("Gold : " + gold);
    }
    static void BattleModeCommon(int enHP)
    {
        int maxHP = enHP;
        System.out.println("Enemy (Common)");
        System.out.println("HP : "+ enHP + "/" + maxHP);
        System.out.println("Game menu : ");
        System.out.println("1. Attack");
        System.out.println("2. Enchance Attack (costs 20 MP)");
        System.out.println("3. Flee");
        System.out.print("Your Choice : ");
    }
    static void BattleModeBoss(int enHP)
    {
        int maxHP = enHP;
        System.out.println("Enemy (Boss)");
        System.out.println("HP : "+ enHP + "/" + maxHP);        
        System.out.println("Game menu : ");
        System.out.println("1. Attack");
        System.out.println("2. Enchance Attack (costs 20 MP)");
        System.out.println("3. Flee");
        System.out.print("Your Choice : ");
    }    
    static void MainMenu()
    {
        System.out.println("Main menu : \n1. Item shop\n2. Inventory\n3. Cheat\n4. Exit\nChoose : ");
    }
    static void ItemShop()
    {
        System.out.println("ITEM SHOP");
        System.out.println("1. Health Potion       | $100 | +50 HP");
        System.out.println("2. Super Health Potion | $200 | HP full");
        System.out.println("3. Mana Potion         | $250 | +50 MP");
        System.out.println("4. Super Mana Potion   | $350 | MP full");
    }
    static void Cheat()
    {
        System.out.println("1. Cheat Gold");
        System.out.println("2. Cheat Level");
    }
}
