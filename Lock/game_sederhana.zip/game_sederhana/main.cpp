#include <iostream>
#include <windows.h>
#include <sstream>
#include <fstream>
#include <conio.h>
using namespace std;

void Beli_Ayam(int &gold, int &j_ayam, int jumlah)
{
	cout << "Masukkan Jumlah Ayam : \n";
	cin >> jumlah;
	if (gold > 200 && gold - (200 * jumlah) > 0)
	{
		gold = gold - (200 * jumlah);
		j_ayam += jumlah;
	}
	else
	{
		cout << "Harga beli ayam  : 200/ekor" << endl;
		cout << "Harga beli sapi : 400/ekor" << endl;
		getch();
		system("cls");
	}
}

void Beli_Sapi(int &gold, int &j_sapi, int jumlah)
{
	cout << "Masukkan Jumlah Sapi : \n";
	cin >> jumlah;
	if (gold > 400 && gold - (400 * jumlah) > 0)
	{
		gold = gold - (400 * jumlah);
		j_sapi += jumlah;
	}
	else
	{
		cout << "Harga beli ayam  : 200/ekor" << endl;
		cout << "Harga beli sapi : 400/ekor" << endl;
		getch();
		system("cls");
	}
}

void Jual_Ayam(int &gold, int &j_ayam, int jumlah)
{
	cout << "Masukkan Jumlah Ayam : \n";
	cin >> jumlah;
	if (jumlah > j_ayam)
	{
		cout << "Jumlah tidak sesuai/melebihi" << endl;
	}
	else
	{
		j_ayam -= jumlah;
		gold = gold + (jumlah * 200);
	}
}

void Jual_Sapi(int &gold, int &j_sapi, int jumlah)
{
	cout << "Masukkan Jumlah Sapi : \n";
	cin >> jumlah;
	if (jumlah > j_sapi)
	{
		cout << "Jumlah tidak sesuai/melebihi" << endl;
	}
	else
	{
		j_sapi -= jumlah;
		gold = gold + (jumlah * 400);
	}
}

void Ganti_Hari(int &hari, int &j_ayam, int &j_sapi)
{
	hari += 1;
	j_ayam = j_ayam + (j_ayam / 2);
	j_sapi = j_sapi + (j_sapi / 2);
	system("cls");
}

void LOAD(int &gold,int &hari,int &j_ayam,int &j_sapi)
{
    ifstream FILE("DATA.txt");
    string GOLD,HARI,J_AYAM,J_SAPI;
    if (FILE.is_open())
    {
        getline(FILE,GOLD);
        getline(FILE,HARI);
        getline(FILE,J_AYAM);
        getline(FILE,J_SAPI);

        stringstream sa,sb,sc,sd;
        sa.str(GOLD);
        sb.str(HARI);
        sc.str(J_AYAM);
        sd.str(J_SAPI);
        sa >> gold;
        sb >> hari;
        sc >> j_ayam;
        sd >> j_sapi;
        FILE.close();
    }
    else
    {
        gold = 500;
        hari = 0;
        j_ayam = 0;
        j_sapi = 0;
        FILE.close();
    }

}


int main()
{
	int gold, hari, j_sapi, j_ayam;
	LOAD(gold,hari,j_ayam,j_sapi);
	int jumlah;
	int menu_utama;
	do
	{
		cout << "Gold" << " : " << gold << endl;
		cout << "Hari" << " : " << hari << endl;
		cout << "Jumlah Sapi" << " : " << j_sapi << endl;
		cout << "Jumlah Ayam" << " : " << j_ayam << endl;
		cout << "1. Beli Ayam" << endl;
		cout << "2. Beli Sapi" << endl;
		cout << "3. Jual Ayam" << endl;
		cout << "4. Jual Sapi" << endl;
		cout << "5. Ganti Hari" << endl;
		cout << "6. Save Game & Exit" << endl;
		cin >> menu_utama;

		if (menu_utama == 1)
		{
			Beli_Ayam(gold, j_ayam, jumlah);
		}
		else if (menu_utama == 2)
		{
			Beli_Sapi(gold, j_sapi, jumlah);
		}
		else if (menu_utama == 3)
		{
			Jual_Ayam(gold, j_ayam, jumlah);
		}
		else if (menu_utama == 4)
		{
			Jual_Sapi(gold, j_ayam, jumlah);
		}
		else if (menu_utama == 5)
		{
			Ganti_Hari(hari, j_ayam, j_sapi);
		}
	} while (menu_utama != 6);
        ofstream SAVE("DATA.txt");
        if (SAVE.is_open())
        {
            SAVE << gold << endl;
            SAVE << hari << endl;
            SAVE << j_ayam << endl;
            SAVE << j_sapi << endl;
            SAVE.close();
        }
	return 0;
}
