#include <iostream>
#include <math.h>
#include <cstdlib>
#include <time.h>
#include <conio.h>
#include <Windows.h>

using namespace std;

int main()
{
	char t;
	int i, j;
	bool gameover = false;
	bool powerup = false;
	char ball = 'o';
	int ballx=20, bally=17;
	int hprin1 = 3, hprin2 = 4, hprin3 = 5;
	char papan = '_';
	int papanx1=5,papanx2=10;
	bool ataskanan = true, bawahkanan = 0, ataskiri = 0, bawahkiri = 0;

	while (!gameover) {
		if (ataskanan == true) {
			bally--;
			ballx++;
			if (bally == 2 && ballx > 0) {
				ataskanan = false;
				bawahkanan = true;
			}
			else if (ballx == 39 && bally > 0) {
				ataskanan = false;
				ataskiri = true;
			}
			else if (hprin1>0){
                if ((bally==4||ballx==3)&&ballx==5){
                    ataskanan = false;
                    ataskiri = true;
                }
                else if ((bally==4||ballx==3)&&(ballx==6||ballx==7)){
                    ataskanan = false;
                    bawahkanan = true;
                }
			}
		}
		else if (bawahkanan == true) {
			ballx++;
			bally++;
			if (ballx == 39 && bally > 0) {
				bawahkanan = false;
				bawahkiri = true;
			}
			else if (ballx > 0 && bally == 19) {
				bawahkanan = false;
				ataskanan = true;
			}
		}
		else if (ataskiri == true) {
			bally--;
			ballx--;
			if (ballx==2&&bally>0) {
				ataskiri = false;
				ataskanan = true;
			}
			else if (ballx > 0 && bally == 2) {
				ataskiri = false;
				bawahkiri = true;
			}
		}
		else if (bawahkiri == true) {
			bally++;
			ballx--;
			if (bally > 0 && ballx == 2) {
				bawahkiri = false;
				bawahkanan = true;
			}
			else if (bally == 19 && ballx > 0) {
				bawahkiri = false;
				ataskiri = true;
			}
		}
//=================================================================================
		if (hprin1>0&&hprin2>0&&hprin3>0&&powerup==false){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==3&&(j==36||j==37)||i==4&&(j==36||j==37)){
                        cout << "p";
					}
					else if (i==3&&(j==5||j==6||j==7||j==8)||i==4&&(j==5||j==6||j==7||j==8)){
                        cout << "1";
					}
					else if (i==4&&(j==30||j==31||j==32||j==33)||i==7&&(j==30||j==31||j==32||j==33)||i==5&&(j==31||j==32)||i==6&&(j==31||j==32)){
                        cout << "3";
					}
					else if (i==6&&j==10||i==10&&j==10||i==7&&(j==9||j==10||j==11)||i==9&&(j==9||j==10||j==11)||i==8&&(j==8||j==9||j==10||j==11||j==12)){
                        cout << "2";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}
		else if (hprin1<=0&&hprin2>0&&hprin3>0&&powerup==false){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==3&&(j==36||j==37)||i==4&&(j==36||j==37)){
                        cout << "p";
					}
					else if (i==4&&(j==30||j==31||j==32||j==33)||i==7&&(j==30||j==31||j==32||j==33)||i==5&&(j==31||j==32)||i==6&&(j==31||j==32)){
                        cout << "3";
					}
					else if (i==6&&j==10||i==10&&j==10||i==7&&(j==9||j==10||j==11)||i==9&&(j==9||j==10||j==11)||i==8&&(j==8||j==9||j==10||j==11||j==12)){
                        cout << "2";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}
		else if (hprin1>0&&hprin2<=0&&hprin3>0&&powerup==false){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==3&&(j==36||j==37)||i==4&&(j==36||j==37)){
                        cout << "p";
					}
					else if (i==3&&(j==5||j==6||j==7||j==8)||i==4&&(j==5||j==6||j==7||j==8)){
                        cout << "1";
					}
					else if (i==4&&(j==30||j==31||j==32||j==33)||i==7&&(j==30||j==31||j==32||j==33)||i==5&&(j==31||j==32)||i==6&&(j==31||j==32)){
                        cout << "3";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}
		else if (hprin1>0&&hprin2>0&&hprin3<=0&&powerup==false){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==3&&(j==36||j==37)||i==4&&(j==36||j==37)){
                        cout << "p";
					}
					else if (i==3&&(j==5||j==6||j==7||j==8)||i==4&&(j==5||j==6||j==7||j==8)){
                        cout << "1";
					}
					else if (i==6&&j==10||i==10&&j==10||i==7&&(j==9||j==10||j==11)||i==9&&(j==9||j==10||j==11)||i==8&&(j==8||j==9||j==10||j==11||j==12)){
                        cout << "2";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}
		else if (hprin1<=0&&hprin2<=0&&hprin3>0&&powerup==false){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==3&&(j==36||j==37)||i==4&&(j==36||j==37)){
                        cout << "p";
					}
					else if (i==4&&(j==30||j==31||j==32||j==33)||i==7&&(j==30||j==31||j==32||j==33)||i==5&&(j==31||j==32)||i==6&&(j==31||j==32)){
                        cout << "3";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}
		else if (hprin1>0&&hprin2<=0&&hprin3<=0&&powerup==false){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==3&&(j==36||j==37)||i==4&&(j==36||j==37)){
                        cout << "p";
					}
					else if (i==3&&(j==5||j==6||j==7||j==8)||i==4&&(j==5||j==6||j==7||j==8)){
                        cout << "1";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}
		else if (hprin1<=0&&hprin2>0&&hprin3<=0&&powerup==false){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==3&&(j==36||j==37)||i==4&&(j==36||j==37)){
                        cout << "p";
					}
					else if (i==6&&j==10||i==10&&j==10||i==7&&(j==9||j==10||j==11)||i==9&&(j==9||j==10||j==11)||i==8&&(j==8||j==9||j==10||j==11||j==12)){
                        cout << "2";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}


		if (hprin1>0&&hprin2>0&&hprin3>0&&powerup==true){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==3&&(j==5||j==6||j==7||j==8)||i==4&&(j==5||j==6||j==7||j==8)){
                        cout << "1";
					}
					else if (i==4&&(j==30||j==31||j==32||j==33)||i==7&&(j==30||j==31||j==32||j==33)||i==5&&(j==31||j==32)||i==6&&(j==31||j==32)){
                        cout << "3";
					}
					else if (i==6&&j==10||i==10&&j==10||i==7&&(j==9||j==10||j==11)||i==9&&(j==9||j==10||j==11)||i==8&&(j==8||j==9||j==10||j==11||j==12)){
                        cout << "2";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}
		else if (hprin1<=0&&hprin2>0&&hprin3>0&&powerup==true){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==4&&(j==30||j==31||j==32||j==33)||i==7&&(j==30||j==31||j==32||j==33)||i==5&&(j==31||j==32)||i==6&&(j==31||j==32)){
                        cout << "3";
					}
					else if (i==6&&j==10||i==10&&j==10||i==7&&(j==9||j==10||j==11)||i==9&&(j==9||j==10||j==11)||i==8&&(j==8||j==9||j==10||j==11||j==12)){
                        cout << "2";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}
		else if (hprin1>0&&hprin2<=0&&hprin3>0&&powerup==true){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==3&&(j==5||j==6||j==7||j==8)||i==4&&(j==5||j==6||j==7||j==8)){
                        cout << "1";
					}
					else if (i==4&&(j==30||j==31||j==32||j==33)||i==7&&(j==30||j==31||j==32||j==33)||i==5&&(j==31||j==32)||i==6&&(j==31||j==32)){
                        cout << "3";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}
		else if (hprin1>0&&hprin2>0&&hprin3<=0&&powerup==true){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==3&&(j==5||j==6||j==7||j==8)||i==4&&(j==5||j==6||j==7||j==8)){
                        cout << "1";
					}
					else if (i==6&&j==10||i==10&&j==10||i==7&&(j==9||j==10||j==11)||i==9&&(j==9||j==10||j==11)||i==8&&(j==8||j==9||j==10||j==11||j==12)){
                        cout << "2";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}
		else if (hprin1<=0&&hprin2<=0&&hprin3>0&&powerup==true){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==4&&(j==30||j==31||j==32||j==33)||i==7&&(j==30||j==31||j==32||j==33)||i==5&&(j==31||j==32)||i==6&&(j==31||j==32)){
                        cout << "3";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}
		else if (hprin1>0&&hprin2<=0&&hprin3<=0&&powerup==true){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==3&&(j==5||j==6||j==7||j==8)||i==4&&(j==5||j==6||j==7||j==8)){
                        cout << "1";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}
		else if (hprin1<=0&&hprin2>0&&hprin3<=0&&powerup==true){
            			for (i = 1; i <= 20; i++) {
				for (j = 1; j <= 40; j++) {
					//cout << " j" << j;
					if (i == bally && j == ballx) {
						cout << ball;
					}
					else if (i==6&&j==10||i==10&&j==10||i==7&&(j==9||j==10||j==11)||i==9&&(j==9||j==10||j==11)||i==8&&(j==8||j==9||j==10||j==11||j==12)){
                        cout << "2";
					}
					else if (i == 1 || i == 20 || j == 1 || j == 40) {
						cout << "#";
					}
					else {
						cout << " ";
					}

				}
				cout << "\n";
			}
		}
		else if (hprin1==0&&hprin2==0&&hprin3==0){
            gameover = true;
		}


//=================================================================================
		cout << "Hp Rintangan1 : " << hprin1 << endl;
		cout << "Hp Rintangan2 : " << hprin2 << endl;
		cout << "Hp Rintangan3 : " << hprin3 << endl;
		if ((ballx==36||ballx==37)&&(bally==3||bally==4)){
            powerup = true;
		}
		if (_kbhit()) {
			t = _getch();
			if (t == '0') {
				gameover = true;
			}
			else if (t == '1') {
				hprin1--;
			}
			else if (t == '2') {
				hprin2--;
			}
			else if (t == '3') {
				hprin3--;
			}
			else if (t == 'w') {
			}
			else if (t == 'a') {
			}
			else if (t == 's') {
			}
			else if (t == 'd') {
			}
		}
		Sleep(300);
		system("cls");
	}

    system("cls");
    cout << "\n\n\n\n               GAME OVER ";
    Sleep(3000);
	return 0;
}


/*Objek 1
for (i=1;i<=2;i++){
		cout << "1";
		for (j=1;j<=3;j++){
			cout << "1";
		}
		cout << "\n";
	}
*/
/*Objek 2
	int row,colom,space;
	for (row=1;row<=3;row++){
		for(space=1;space<=3-row;space++){
			cout << " ";
		}
		for(colom=1;colom<=(2*row)-1;colom++){
			cout << "2";
		}
		cout << "\n";
	}
	for (row=2;row>=1;row--){
		for(space=1;space<=3-row;space++){
			cout << " ";
		}
		for(colom=1;colom<=(2*row)-1;colom++){
			cout << "2";
		}
		cout << "\n";
	}
*/
/*Objek 3

*/
/*if (_kbhit()) {
	in = _getch();
	if (in == 'w') {
		cout << "W";
	}
	else if (in == 'a') {
		cout << "A";
	}
	else if (in == 's') {
		cout << "S";
	}
	else if (in == 'd') {
		cout << "D";
	}
	else {
		cout << " ";
	}
}*/
//			for (i = 1; i <= 20; i++) {
//				for (j = 1; j <= 40; j++) {
//					//cout << " j" << j;
//					if (i == bally && j == ballx) {
//						cout << ball;
//					}
//					else if (i==3&&(j==36||j==37)||i==4&&(j==36||j==37)){
//                        cout << "p";
//					}
//					else if (i==3&&(j==5||j==6||j==7||j==8)||i==4&&(j==5||j==6||j==7||j==8)){
//                        cout << "1";
//					}
//					else if (i==4&&(j==30||j==31||j==32||j==33)||i==7&&(j==30||j==31||j==32||j==33)||i==5&&(j==31||j==32)||i==6&&(j==31||j==32)){
//                        cout << "3";
//					}
//					else if (i==6&&j==10||i==10&&j==10||i==7&&(j==9||j==10||j==11)||i==9&&(j==9||j==10||j==11)||i==8&&(j==8||j==9||j==10||j==11||j==12)){
//                        cout << "2";
//					}
//					else if (i == 1 || i == 20 || j == 1 || j == 40) {
//						cout << "#";
//					}
//					else {
//						cout << " ";
//					}
//
//				}
//				cout << "\n";
//			}
