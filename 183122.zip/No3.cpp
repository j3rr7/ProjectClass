#include <iostream>

using namespace std;

int main()
{
    cout << "Masukkan 3 digit angka input: " << endl;
    int input;
    cin >> input;

    int a,b,c;
    a = input/100;
    b = input%100/10;
    c = input%10;

    cout << "Masukkan Jawaban Angka: " << endl;
    int jawaban;
    cin >> jawaban;

    int d,e,f;
    d = jawaban/100;
    e = jawaban%100/10;
    f = jawaban%10;

    int salah = 0;

    if (d==a&&e!=b&&f!=c||e==b&&d!=a&&f!=c||f==c&&d!=a&&e!=b){
        cout<<"1 angka sama"<<endl;
    }
    else if (d==a&&e==b&&c!=f||d==a&&e!=b&&c==f||d!=a&&e==b&&c==f){
        cout<< "2 angka sama"<<endl;
    }
    else if (d!=a&&e!=b&&c!=f||d!=a&&e!=b&&c!=f||d!=a&&e!=b&&c!=f){
        cout << "Tidak ada yang sama";
    }
    else {
        cout << "Selamat anda menebak angka dengan benar";
    }

    cout << "Masukkan Jawaban Anda: " << endl;
    int jawaban2;
    cin >> jawaban2;

    if (jawaban2/100==a&&jawaban2%100/10!=b&&jawaban2%10!=c){
        cout<<"1 angka sama"<<endl;
    }
    else if ((jawaban2/100)==a&&(jawaban2%100/10)==b&&(jawaban2%10)!=c||(jawaban2/100)==a&&(jawaban2%100/10)!=b&&(jawaban2%10)==c){
        cout<< "2 angka sama"<<endl;
    }
    else if (jawaban2/100!=a&&jawaban2%100/10!=b&&c!=jawaban2%10||jawaban2/100!=a&&jawaban2%100/10!=b&&c!=jawaban2%10||jawaban2/100!=a&&jawaban2%100/10!=b&&c!=jawaban2%10){
        cout << "Tidak ada yang sama";
    }
    else {
        cout << "Selamat anda menebak angka dengan benar";
    }

    cout << "Masukkan Jawaban Anda: "<< endl;
    int jawaban3;
    cin >> jawaban3;

    if (jawaban3/100==a&&jawaban3%100/10!=b&&jawaban3%10!=c){
        cout<<"1 angka sama"<<endl;
    }
    else if (jawaban3/100==a&&jawaban3%100/10==b&&jawaban3%10!=c||jawaban3/100==a&&jawaban2%100/10!=b&&jawaban2%10==c){
        cout<< "2 angka sama"<<endl;
    }
    else if (jawaban3/100!=a&&jawaban3%100/10!=b&&c!=jawaban3%10||jawaban3/100!=a&&jawaban3%100/10!=b&&c!=jawaban3%10||jawaban3/100!=a&&jawaban3%100/10!=b&&c!=jawaban3%10){
        cout << "Tidak ada yang sama";
    }
    else {
        cout << "Selamat anda menebak angka dengan benar";
    }

    cout << "Masukkan Jawaban Anda: " << endl;
    int jawaban4;
    cin >> jawaban4;

    if (jawaban4/100==a&&jawaban4%100/10!=b&&jawaban4%10!=c){
        cout<<"1 angka sama"<<endl;
    }
    else if (jawaban4/100==a&&jawaban4%100/10==b&&jawaban4%10!=c||jawaban4/100==a&&jawaban4%100/10!=b&&jawaban4%10==c){
        cout<< "2 angka sama"<<endl;
    }
    else if (jawaban4/100!=a&&jawaban4%100/10!=b&&c!=jawaban4%10||jawaban4/100!=a&&jawaban4%100/10!=b&&c!=jawaban4%10||jawaban4/100!=a&&jawaban4%100/10!=b&&c!=jawaban4%10){
        cout << "Tidak ada yang sama";
    }
    else {
        cout << "Selamat anda menebak angka dengan benar";
    }

    cout <<"\n\n"<< "Maap kesempatan habis"<<endl;
    return 0;
}
