#include <iostream>

using namespace std;

int main()
{
    cout << "Masukkan 3 digit angka input: "<<endl;
    int input;
    cin >> input;

    int a,b,c;
    a = input/100;
    b = input%100/10;
    c = input%10;

    cout << "Angka ratusan: " << a<<"\n";
    cout << "Angka puluhan: " << b<<"\n";
    cout << "Angka satuan: " << c<<"\n";
    if (input > 999||input < 100){
        cout<< "Input lu salah gaes coba pake 3 digit angka :V " << endl;
        return main();
    }
    else if (a==b&&b==c){
        cout<<"\n\n"<<"Hasil \n";
        cout <<a<<b<<c<<endl;
    }
    else if (a!=b&&b!=c&&a!=c){
        cout<<"\n"<<"Hasil \n";
        cout <<a<<b<<c<<endl;
        cout <<a<<c<<b<<endl;
        cout <<b<<a<<c<<endl;
        cout <<b<<c<<a<<endl;
        cout <<c<<a<<b<<endl;
        cout <<c<<b<<a<<endl;
    }
    else if (a!=b&&b==c&&c!=a){
        cout <<"\n";
        cout <<b<<a<<c<<endl;
        cout <<b<<c<<a<<endl;
        }
    else if (a==b&&b!=c&&c!=a){
        cout << "\n";
        cout <<a<<c<<b<<endl;
        cout <<c<<b<<a<<endl;
    }
    else {
        cout << "\n";
        cout << "saya kurang iman :V" << endl;
    }
    return 0;
}
