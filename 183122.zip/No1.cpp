#include <iostream>

using namespace std;

int main()
{
    cout << "P1: " << endl;
    char input1;
    cin >> input1;
    cout << "P2: " << endl;
    char input2;
    cin >> input2;

    if (input1 == 'G' && input2 == 'K' || input1 == 'B' && input2 == 'K' || input1 == 'B' && input2 == 'G'|| input1 == 'B' && input2 == 'K'){
        cout << "P1 Menang";
    }
    else if (input1 == 'K' && input2 == 'G' || input1 == 'K' && input2 == 'B' || input1 == 'G' && input2 == 'B'|| input1 == 'K' && input2 == 'B' ){
        cout << "P2 Menang";
    }
    else if (input1 == 'K' && input2 == 'K' || input1 == 'B' && input2 == 'B' || input1 == 'G' && input2 == 'G'){
        cout << "Seri";
    }
    else if (input1 != 'K' || input2 != 'G' || input1 != 'B' || input2 != 'K' || input1 != 'G' || input2 != 'B'){
        cout << "Input salah";
    }
    return 0;
}
