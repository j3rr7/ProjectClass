#include <iostream>

using namespace std;

int main()
{
    cout << "Input Angka Pertama: ";
    int angka1;
    cin >> angka1;
    cout << "Input Angka Kedua : ";
    int angka2;
    cin >> angka2;
    cout << "Input Angka Ketiga : ";
    bool angka3;
    cin >> angka3;

    int a,b,c,d,e,f,g,h,i,j;
    a = angka1/10000;
    b = angka1/1000%10;
    c = angka1/100%10;
    d = angka1/10%10;
    e = angka1%10;
    f = angka2/10000;
    g = angka2/1000%10;
    h = angka2/100%10;
    i = angka2/10%10;
    j = angka2%10;

    int hasil_balik1 = e*1000+d*100+b*10+a;
    int hasil_balik2 = j*1000+i*100+g*10+f;
    int hitung = (2 * angka3)-1;

    int hasil = hasil_balik1 + hasil_balik2*hitung;


    cout << "Tanpa Tengah Pertama : " <<a<<b<<d<<e<<endl;
    cout << "Tanpa Tengah Kedua : " <<f<<g<<i<<j<<endl;
    cout << "Hasil Balik 1 : " <<hasil_balik1<<endl;
    cout << "Hasil Balik 2 : " <<hasil_balik2<<endl;
    cout << "Hasil Akhir : "<< hasil <<endl;
    return 0;
}
