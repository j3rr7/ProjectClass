#include <iostream>
using namespace std;

int main()
{
    int menu = 0;
    int pilih;
    while ( menu == 0 ){
        cout<<"***************************************\n";
        cout<<"                 WELCOME!              \n";
        cout<<"***************************************\n";
        cout<<"|-----------------|--------------------|"<<endl;
        cout<<"|      CODE       |        USE         |"<<endl;
        cout<<"|-----------------|--------------------|"<<endl;
        cout<<"|1. No1           | Goto Program 1     |"<<endl;
        cout<<"|2. No2           | Goto Program 2     |"<<endl;
        cout<<"|3. T1            | Goto Program 3     |"<<endl;
        cout<<"|4. EXIT          |========EXIT========|"<<endl;
        cout<<"|-----------------|--------------------|"<<endl;
        cout<<"Enter your choice : ";
        cin>>pilih;
        if (pilih == 1){
            int jawaban,tebakan;
            cout << "Kunci jawaban: ";
            cin >> jawaban;
            int jawabana=jawaban/100;
            int jawabanb=jawaban/10%10;
            int jawabanc=jawaban%10;
            int skor;
            while (jawaban!=tebakan){
                skor=0;
                cout << "Masukkan angka: ";
                cin >> tebakan;
                int tebakana=tebakan/100;
                int tebakanb=tebakan/10%10;
                int tebakanc=tebakan%10;
                if(jawabana==tebakana){
                    skor++;
                    if (jawabanb==tebakanb){
                        skor++;
                    }
                    if (jawabanc==tebakanc){
                        skor++;
                    }
                cout << skor <<"angka sama"<<endl;
                }
                else if (jawabanb==tebakanb){
                    skor++;
                    if (jawabanc==tebakanc){
                        skor++;
                    }
                    cout << skor<<"angka sama" << endl;
                }
                else if (jawabanc==tebakanc){
                skor++;
                cout << skor<<"angka sama"<<endl;
                }

                else if (skor==3){
                cout << "You win"<<endl;
                    }
                else {
                cout << skor<<"angka sama" <<endl;
                }
            skor=0;
            menu=0;
            }
        }
        else if (pilih == 2){
                float input;
                float total=0;
                float temp=0;
                float maxi=0;
                float mini=2000000000;
                while (input!=0){
                    cout << "Masukkan angka: ";
                    cin >> input;
                    total = total+input;
                    temp++;
                    if (input>maxi){
                        maxi=input;
                    }
                    if (input<=mini){
                        if (input!=0){
                            mini=input;
                        }
                    }
                }
                float avg = (total/(temp-1));
                int sum = total;
                cout << "Rata-rata : "<<avg<<endl;
                cout << "Sum: "<<sum<<endl;
                cout << "Min: "<<mini<<endl;
                cout << "Max: "<<maxi<<endl;
                menu =0;
        }
        else if (pilih == 3){
            cout << "Masukkan Input1 : ";
            int input1;
            cin >> input1;
            cout << "Masukkan Input2 : ";
            int input2;
            cin >> input2;

            int temp;
            while (input2>input1){
                int hasil = input2&input1;
                temp = input1;
                int c  = temp%hasil;
                cout << c;
                return 0;
            }

            while (input1>input2){
                int hasil = input1&input2;
                cout << hasil;
                return 0;
            }
        }
        else if (pilih == 4){
            cout << "EXIT..."<<endl;
            return 0;
        }
        else {
            cout << "Pilihan ga valid"<<endl;
            break;
        }
	}
    return 0;
}
