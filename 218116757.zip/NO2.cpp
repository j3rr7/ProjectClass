float input;
                float total=0;
                float temp=0;
                float maxi=0;
                float mini=2000000000;
                while (input!=0){
                    cout << "Masukkan angka: ";
                    cin >> input;
                    total = total+input;
                    temp++;
                    if (input>maxi){
                        maxi=input;
                    }
                    if (input<=mini){
                        if (input!=0){
                            mini=input;
                        }
                    }
                }
                float avg = (total/(temp-1));
                int sum = total;
                cout << "Rata-rata : "<<avg<<endl;
                cout << "Sum: "<<sum<<endl;
                cout << "Min: "<<mini<<endl;
                cout << "Max: "<<maxi<<endl;