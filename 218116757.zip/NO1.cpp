int jawaban,tebakan;
            cout << "Kunci jawaban: ";
            cin >> jawaban;
            int jawabana=jawaban/100;
            int jawabanb=jawaban/10%10;
            int jawabanc=jawaban%10;
            int skor;
            while (jawaban!=tebakan){
                skor=0;
                cout << "Masukkan angka: ";
                cin >> tebakan;
                int tebakana=tebakan/100;
                int tebakanb=tebakan/10%10;
                int tebakanc=tebakan%10;
                if(jawabana==tebakana){
                    skor++;
                    if (jawabanb==tebakanb){
                        skor++;
                    }
                    if (jawabanc==tebakanc){
                        skor++;
                    }
                cout << skor <<"angka sama"<<endl;
                }
                else if (jawabanb==tebakanb){
                    skor++;
                    if (jawabanc==tebakanc){
                        skor++;
                    }
                    cout << skor<<"angka sama" << endl;
                }
                else if (jawabanc==tebakanc){
                skor++;
                cout << skor<<"angka sama"<<endl;
                }

                else if (skor==3){
                cout << "You win"<<endl;
                    }
                else {
                cout << skor<<"angka sama" <<endl;
                }